package SchoolAdmin;

import javax.swing.JPanel;


import org.jfree.ui.RefineryUtilities;

import OurMessage.Message;
import OurMessage.QTypes;
import chat.Client;

import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.HashMap;
import java.awt.event.ActionEvent;

public class ReportHisto extends JPanel {


	private final JButton Different_Classes = new JButton("Different Classes");
	public ReportHisto(){
		setBounds(180, 0, 429, 327);

		setLayout(null);
		Different_Classes.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				String Q=new String ("SELECT class_id,course_id,teacher_id FROM class_schedule WHERE sem_id ="+Client.opnedsem+";#SELECT class_id,student_id FROM class_students WHERE sem_id="+Client.opnedsem+";#SELECT id_student,grade,course,id_assigment FROM assigment_grades WHERE sem_id="+Client.opnedsem+";");	
				Message msg = new Message(Q,QTypes.getgrades);
				Client.client.handleMessageFromClientUI(msg);
		}
		});
		
		Different_Classes.setBounds(131, 63, 156, 23);
		add(Different_Classes);
		
	}
	

}

