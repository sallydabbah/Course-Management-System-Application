package SchoolAdmin;

import javax.swing.JPanel;
import javax.swing.table.TableModel;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.category.DefaultCategoryDataset;

import Entities.ClassRoomStudent;
import Entities.ClassRoomTeacher;
import Entities.StudentGrade;
import User.HomeUI;
import chat.Client;

import java.awt.Color;
import java.util.ArrayList;
import java.awt.BorderLayout;
import javax.swing.JLabel;
import javax.swing.JComboBox;
import javax.swing.ComboBoxModel;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.ActionEvent;
import javax.swing.JSeparator;

public class ChartsPresentationUI extends JPanel {
	private ArrayList<ClassRoomStudent> students;
	private ArrayList<ClassRoomTeacher> teachers;
	private ArrayList<StudentGrade> grades;
	private JComboBox cmbteacher=new JComboBox();
	private JComboBox cmbcourses=new JComboBox();
	private JComboBox cmbcourse2 = new JComboBox();
	private JComboBox cmbclass = new JComboBox();
	private JComboBox cmbclass2 = new JComboBox();
	/**
	 * Create the panel.
	 */
	public ChartsPresentationUI() {
		((SchoolHomeAdminGUI)((HomeUI)Client.clientGUI).innerpanel).page=3;
		setLayout(null);
		setBounds(180,0,700,572);
		JPanel panel = new JPanel();
		panel.setBackground(new Color(192, 192, 192));
		panel.setBounds(10, 11, 680, 377);
		add(panel);
		panel.setLayout(new BorderLayout(0, 0));
		
		cmbteacher.setBounds(91, 422, 129, 20);
		add(cmbteacher);
		cmbcourses.setBounds(310, 423, 129, 20);
		add(cmbcourses);
		
		JButton btnShowGraph = new JButton("Show Graph");
		btnShowGraph.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				int teachID=Integer.parseInt(cmbteacher.getSelectedItem().toString());
				String course=cmbcourses.getSelectedItem().toString();
				ArrayList<ClassRoomTeacher> classes=new ArrayList<ClassRoomTeacher>(teachers.size());
				ArrayList<ClassRoomStudent> student_class=new ArrayList<ClassRoomStudent>(students.size());
				ArrayList<StudentGrade> grade_students=new ArrayList<StudentGrade>(grades.size());
				ArrayList<StudentGrade> Averagegrade_students=new ArrayList<StudentGrade>(grades.size());

				for(ClassRoomTeacher crt:teachers){
					if(crt.getTeacher_id()==teachID && crt.getCourse_id().equals(course))
						classes.add(crt);
				}
				for(ClassRoomTeacher crt:classes){
					for(ClassRoomStudent crs:students){
						if(crs.getClass_id().equals(crt.getClass_id()))
							student_class.add(crs);
					}
				}
				for(ClassRoomStudent crs:student_class){
					for(StudentGrade sg:grades)
						if(crs.getStudentID()==sg.getStudent_id() && sg.getCourse().equals(course))
							grade_students.add(sg);
					
				}
				for(int i=0;i<grade_students.size();i++){
					int stud=grade_students.get(i).getStudent_id();
					float sum=0;
					int counter=0;
					while((grade_students.get(i).getStudent_id()==stud) && (i<grade_students.size())){
						sum+=grade_students.get(i).getGrade();
						i++;
						counter++;
						if(i>=grade_students.size())break;
					}
					Averagegrade_students.add(new StudentGrade(stud,sum/counter,course,0));
					i--;
				}
				ArrayList<Float> class_average=new ArrayList<Float>();
				ArrayList<String> stud_class=new ArrayList<String>();
				for(int i=0;i<student_class.size();i++){
					String classID=student_class.get(i).getClass_id();
					float sum=0;
					int counter=0;
					while(student_class.get(i).getClass_id().equals(classID)&&i<student_class.size()){
						sum+=Averagegrade_students.get(i).getGrade();
						i++;
						counter++;
						if(i>=student_class.size())break;
					}
					stud_class.add(classID);
					class_average.add(sum/counter);
					i--;
				}
				DefaultCategoryDataset dataset=new DefaultCategoryDataset();
				for(int i=0;i<stud_class.size();i++)
					dataset.setValue(class_average.get(i), "%", stud_class.get(i));
				JFreeChart chart = ChartFactory.createBarChart3D("Teacher-Course Chart", "", "", dataset,PlotOrientation.HORIZONTAL,false,false,false);
				CategoryPlot catPlot=chart.getCategoryPlot();
				catPlot.setRangeMinorGridlinePaint(Color.BLACK);
				ChartPanel chartPanel= new ChartPanel(chart);
				panel.removeAll();
				panel.add(chartPanel,BorderLayout.CENTER);
				panel.validate();
			}
		});
		btnShowGraph.setBounds(449, 422, 104, 23);
		add(btnShowGraph);
		
		JLabel lblTeacherId = new JLabel("Teacher ID:");
		lblTeacherId.setBounds(20, 425, 73, 14);
		add(lblTeacherId);
		
		JLabel lblCourseId = new JLabel("Course ID:");
		lblCourseId.setBounds(245, 425, 70, 14);
		add(lblCourseId);
		
		
		cmbclass.setBounds(91, 484, 129, 20);
		add(cmbclass);
		
		JLabel lblClassId = new JLabel("Class ID:");
		lblClassId.setBounds(20, 487, 73, 14);
		add(lblClassId);
		
		JLabel lblcourse2 = new JLabel("Course ID:");
		lblcourse2.setBounds(245, 487, 70, 14);
		add(lblcourse2);
		
		
		cmbcourse2.setBounds(310, 485, 129, 20);
		add(cmbcourse2);
		
		JButton btnclasscate = new JButton("Show Graph");
		btnclasscate.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				ArrayList<Integer> class_student=new ArrayList<Integer>();
				ArrayList<StudentGrade> student_grades=new ArrayList<StudentGrade>();
				ArrayList<Float> Averagegrade_students=new ArrayList<Float>();
				String classID=cmbclass.getSelectedItem().toString();
				for(ClassRoomStudent crt:students){//getting class students
					if(crt.getClass_id().equals(classID))
						class_student.add(crt.getStudentID());
				}
				for(int student:class_student){
					for(StudentGrade sg:grades){
						if(sg.getStudent_id()==student)
							student_grades.add(sg);
					}
				}
				String course=cmbcourses.getSelectedItem().toString();
				for(int i=0;i<student_grades.size();i++){
					int stud=student_grades.get(i).getStudent_id();
					float sum=0;
					int counter=0;
					while((student_grades.get(i).getStudent_id()==stud) && (i<student_grades.size())){
						sum+=student_grades.get(i).getGrade();
						i++;
						counter++;
						if(i>=student_grades.size())break;
					}
					Averagegrade_students.add(sum/counter);
					i--;
				}
				DefaultCategoryDataset dataset=new DefaultCategoryDataset();
				for(int i=0;i<class_student.size();i++)
					dataset.setValue(Averagegrade_students.get(i), "%", class_student.get(i));
				JFreeChart chart = ChartFactory.createBarChart3D("Teacher-Course Chart", "", "", dataset,PlotOrientation.HORIZONTAL,false,false,false);
				CategoryPlot catPlot=chart.getCategoryPlot();
				catPlot.setRangeMinorGridlinePaint(Color.BLACK);
				ChartPanel chartPanel= new ChartPanel(chart);
				panel.removeAll();
				panel.add(chartPanel,BorderLayout.CENTER);
				panel.validate();
			}
		});
		btnclasscate.setBounds(449, 483, 104, 23);
		add(btnclasscate);
		
		
		cmbclass2.setBounds(88, 539, 129, 20);
		add(cmbclass2);
		
		JLabel lblClassId_1 = new JLabel("Class ID:");
		lblClassId_1.setBounds(20, 542, 70, 14);
		add(lblClassId_1);
		
		JButton button = new JButton("Show Graph");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				ArrayList<Integer> class_student=new ArrayList<Integer>();
				ArrayList<Integer> done_teachers=new ArrayList<Integer>();
				ArrayList<StudentGrade> student_grades=new ArrayList<StudentGrade>();
				ArrayList<StudentGrade> coursestudent_grades=new ArrayList<StudentGrade>();
				ArrayList<ClassRoomTeacher> class_teachers=new ArrayList<ClassRoomTeacher>();
				ArrayList<ClassRoomTeacher> course_teachers=new ArrayList<ClassRoomTeacher>();
				ArrayList<Float> Averagegrade_students=new ArrayList<Float>();
				ArrayList<Float> Averagegrade_teacher=new ArrayList<Float>();
				ArrayList<Integer> Average_teacher=new ArrayList<Integer>();

				String classID=cmbclass.getSelectedItem().toString();
				for(ClassRoomStudent crt:students){//getting class students
					if(crt.getClass_id().equals(classID))
						class_student.add(crt.getStudentID());
				}
				for(ClassRoomTeacher crt:teachers)
					if(crt.getClass_id().equals(classID))
						class_teachers.add(crt);
				for(int i=0;i<class_teachers.size();i++){
					int teach=class_teachers.get(i).getTeacher_id();
					if(!done_teachers.contains(teach)){
						for(int j=i;j<class_teachers.size();j++){
							if(class_teachers.get(j).getTeacher_id()==teach)
								course_teachers.add(class_teachers.get(j));
						}
					done_teachers.add(teach);
					}
				}
				for(int student:class_student){//All Class Grades
					for(StudentGrade sg:grades){
						if(sg.getStudent_id()==student)
							student_grades.add(sg);
					}
				}
				for(ClassRoomTeacher crt:course_teachers){//All Class Grades course
					for(StudentGrade sg:student_grades){
						if(crt.getCourse_id().equals(sg.getCourse()))
							coursestudent_grades.add(sg);
					}
				}
				for(int i=0;i<coursestudent_grades.size();i++){
					String stud=coursestudent_grades.get(i).getCourse();
					float sum=0;
					int counter=0;
					while((coursestudent_grades.get(i).getCourse().equals(stud)) && (i<coursestudent_grades.size())){
						sum+=coursestudent_grades.get(i).getGrade();
						i++;
						counter++;
						if(i>=coursestudent_grades.size())break;
					}
					Averagegrade_students.add(sum/counter);
					i--;
				}
				for(int i=0;i<course_teachers.size();i++){
					int stud=course_teachers.get(i).getTeacher_id();
					float sum=0;
					int counter=0;
					while((course_teachers.get(i).getTeacher_id()==stud) && (i<course_teachers.size())){
						sum+=Averagegrade_students.get(i);
						i++;
						counter++;
						if(i>=course_teachers.size())break;
					}
					Average_teacher.add(stud);
					Averagegrade_teacher.add(sum/counter);
					i--;
				}
				DefaultCategoryDataset dataset=new DefaultCategoryDataset();
				for(int i=0;i<Averagegrade_students.size();i++)
					dataset.setValue(Averagegrade_students.get(i), "%", Average_teacher.get(i));
				JFreeChart chart = ChartFactory.createBarChart3D("Teacher-Course Chart", "", "", dataset,PlotOrientation.HORIZONTAL,false,false,false);
				CategoryPlot catPlot=chart.getCategoryPlot();
				catPlot.setRangeMinorGridlinePaint(Color.BLACK);
				ChartPanel chartPanel= new ChartPanel(chart);
				panel.removeAll();
				panel.add(chartPanel,BorderLayout.CENTER);
				panel.validate();
				
			}
		});
		button.setBounds(449, 538, 104, 23);
		add(button);
		
		JLabel lblClassDiffrentTeachers = new JLabel("Class Diffrent Teachers Graph:");
		lblClassDiffrentTeachers.setBounds(20, 517, 200, 14);
		add(lblClassDiffrentTeachers);
		
		JSeparator separator = new JSeparator();
		separator.setBounds(15, 511, 675, 2);
		add(separator);
		
		JLabel lblClassDiffrentStudentsgraph = new JLabel("Class Diffrent Students Graph:");
		lblClassDiffrentStudentsgraph.setBounds(20, 462, 200, 14);
		add(lblClassDiffrentStudentsgraph);
		
		JSeparator separator_1 = new JSeparator();
		separator_1.setBounds(10, 453, 675, 2);
		add(separator_1);
		
		JLabel lblTeacherDiffrentCourses = new JLabel("Teacher Diffrent Courses Graph:");
		lblTeacherDiffrentCourses.setBounds(20, 399, 200, 14);
		add(lblTeacherDiffrentCourses);
		
		
		

	}
	public void setStudents(TableModel student){
		ArrayList<ClassRoomStudent> Newstudents=new ArrayList<ClassRoomStudent>(student.getRowCount());
		for(int i=0;i<student.getRowCount();i++)//setting classes list
			Newstudents.add(new ClassRoomStudent(student.getValueAt(i,0).toString(),Integer.parseInt(student.getValueAt(i, 1).toString())));
		this.students=Newstudents;
	}
	public void setTeachers(TableModel teacher){
		ArrayList<ClassRoomTeacher> Newteachers=new ArrayList<ClassRoomTeacher>(teacher.getRowCount());
		for(int i=0;i<teacher.getRowCount();i++)//setting classes list
			Newteachers.add(new ClassRoomTeacher(teacher.getValueAt(i,0).toString(),teacher.getValueAt(i,1).toString(),Integer.parseInt(teacher.getValueAt(i, 2).toString())));
		this.teachers=Newteachers;
	}
	public void setGrades(TableModel grade){
		ArrayList<StudentGrade> Newgrades=new ArrayList<StudentGrade>(grade.getRowCount());
		for(int i=0;i<grade.getRowCount();i++)//setting classes list
			Newgrades.add(new StudentGrade(Integer.parseInt(grade.getValueAt(i, 0).toString()),Float.parseFloat(grade.getValueAt(i,1).toString()),grade.getValueAt(i,2).toString(),Integer.parseInt(grade.getValueAt(i, 3).toString())));
		this.grades=Newgrades;
	}
	
	public void setClassTeacherCMB(){
		DefaultComboBoxModel model=new DefaultComboBoxModel();
		for(ClassRoomStudent crt:students){
			if(model.getIndexOf(crt.getClass_id())==-1)
				model.addElement(crt.getClass_id());
		}
		cmbclass2.setModel(model);
		cmbclass2.setSelectedIndex(0);
	}
 	public void setClassCMB(){
		DefaultComboBoxModel model=new DefaultComboBoxModel();
		for(ClassRoomStudent crt:students){
			if(model.getIndexOf(crt.getClass_id())==-1)
				model.addElement(crt.getClass_id());
		}
		cmbclass.setModel(model);
		cmbclass.setSelectedIndex(0);
		cmbclass.addItemListener(new ItemListener(){
			@Override
			public void itemStateChanged(ItemEvent e) {
				if(e.getStateChange() == ItemEvent.SELECTED){
					  DefaultComboBoxModel model2=new DefaultComboBoxModel();
	                 String classID=cmbclass.getSelectedItem().toString();
	                  cmbcourse2.removeAllItems();
	                  for(ClassRoomTeacher crt:teachers){
	                	  if(crt.getClass_id().equals(classID) && model2.getIndexOf(crt.getCourse_id())==-1)
	                		  model2.addElement(crt.getCourse_id());
	                  }
	                  cmbcourse2.setModel(model2);
	            }  
				
			}
        });
		
	}
	public void setClassCoursesCMB(){
		 DefaultComboBoxModel model2=new DefaultComboBoxModel();
         String classID=cmbclass.getSelectedItem().toString();
          cmbcourse2.removeAllItems();
          for(ClassRoomTeacher crt:teachers){
        	  if(crt.getClass_id().equals(classID) && model2.getIndexOf(crt.getCourse_id())==-1)
        		  model2.addElement(crt.getCourse_id());
          }
          cmbcourse2.setModel(model2);
	}
	public void setTeacherCMB(){
		DefaultComboBoxModel model=new DefaultComboBoxModel();
		
		for(ClassRoomTeacher crt:teachers){
			if(model.getIndexOf(crt.getTeacher_id())==-1)
				model.addElement(crt.getTeacher_id());
				
		}
		cmbteacher.setModel(model);
		cmbteacher.setSelectedIndex(0);
		cmbteacher.addItemListener(new ItemListener(){
			@Override
			public void itemStateChanged(ItemEvent e) {
				if(e.getStateChange() == ItemEvent.SELECTED){
					  DefaultComboBoxModel model2=new DefaultComboBoxModel();
	                  int teacher=Integer.parseInt(cmbteacher.getSelectedItem().toString());
	                  cmbcourses.removeAllItems();
	                  for(ClassRoomTeacher crt:teachers){
	                	  if(crt.getTeacher_id()==teacher && model2.getIndexOf(crt.getCourse_id())==-1)
	                		  model2.addElement(crt.getCourse_id());
	                  }
	                  cmbcourses.setModel(model2);
	            }  
				
			}
        });
	}
	public void setCourseCMB(){
		DefaultComboBoxModel model=new DefaultComboBoxModel();
		int teacher=Integer.parseInt(cmbteacher.getSelectedItem().toString());
		for(ClassRoomTeacher crt:teachers){
			if(crt.getTeacher_id()==teacher && model.getIndexOf(crt.getTeacher_id())==-1)
				  model.addElement(crt.getCourse_id());
        }
        cmbcourses.setModel(model);
	}
}
