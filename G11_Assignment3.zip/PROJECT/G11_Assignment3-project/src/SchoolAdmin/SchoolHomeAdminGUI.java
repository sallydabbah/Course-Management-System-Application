package SchoolAdmin;

import javax.swing.JPanel;

import OurMessage.Message;
import OurMessage.QTypes;
import Student.HomeStudent;
import Student.ViewReportGui;
import User.HomeUI;
import chat.Client;

import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class SchoolHomeAdminGUI extends JPanel {
	
	public int page;
	public int flag;
	public JPanel menu_panel;
	public JPanel tmp_panel = new JPanel();
	public JButton button;
	public JButton button_1;
	public JButton button_2;
	private JButton StaticInfo;
	//protected RequestPanel tmp_panel;

	public SchoolHomeAdminGUI() {
		
		setLayout(null);
		setBounds(0, 0, 571, 327);
		 menu_panel = new JPanel();
		menu_panel.setBounds(0, 0, 180, 324);
		add(menu_panel);
		menu_panel.setLayout(null);
		
		
		
		
		tmp_panel.setBounds(180, 0, 391, 324);
		add(tmp_panel);
		tmp_panel.setLayout(null);
		
		
		
		
		 button = new JButton("Blocking Requests");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				setflag(1);
				Client.client.handleMessageFromClientUI(new Message("SELECT * FROM request_block WHERE approve ='NYD';",QTypes.getblockrequests));
				
			}
		});
		
		
		
		button.setBounds(10, 57, 166, 23);
		menu_panel.add(button);
		
		 button_1 = new JButton("Registration Requests");
		 button_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				setflag(2);
				Client.client.handleMessageFromClientUI(new Message("SELECT * FROM requests WHERE aprove ='NYD' AND status=0;",QTypes.getReq));

				
			}
		});
		button_1.setBounds(10, 91, 166, 23);
		menu_panel.add(button_1);
		
	 button_2 = new JButton("Changing Teacher Request");
		button_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				setflag(3);
				Client.client.handleMessageFromClientUI(new Message("SELECT * FROM teacher_requests WHERE aprove ='NYD' AND status=0;",QTypes.getReqTeacher));
			}
		});
		button_2.setBounds(10, 125, 166, 23);
		menu_panel.add(button_2);
		
		StaticInfo = new JButton("Static Info");
		StaticInfo.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
		
				String Q=new String ("SELECT class_id,course_id,teacher_id FROM class_schedule WHERE sem_id ="+Client.opnedsem+";#SELECT class_id,student_id FROM class_students WHERE sem_id="+Client.opnedsem+";#SELECT id_student,grade,course,id_assigment FROM assigment_grades WHERE sem_id="+Client.opnedsem+";");	
				Message msg = new Message(Q,QTypes.getgrades);
				Client.client.handleMessageFromClientUI(msg);
				//((SchoolHomeAdminGUI)((HomeUI)Client.clientGUI).innerpanel).remove(tmp_panel);
				//((SchoolHomeAdminGUI)((HomeUI)Client.clientGUI).innerpanel).ChangeJPanel(new ReportHisto()); 
				//((HomeUI)Client.clientGUI).resizeHome();
				
			}
		});
		
		StaticInfo.setBounds(10, 159, 166, 23);
		menu_panel.add(StaticInfo);

	}
	public void ChangeJPanel(JPanel panel){
		((HomeUI)Client.clientGUI).innerpanel.remove(((SchoolHomeAdminGUI)((HomeUI)Client.clientGUI).innerpanel).tmp_panel);
		((SchoolHomeAdminGUI)((HomeUI)Client.clientGUI).innerpanel).tmp_panel=panel;
		((HomeUI)Client.clientGUI).innerpanel.add(((SchoolHomeAdminGUI)((HomeUI)Client.clientGUI).innerpanel).tmp_panel);
		menuResize();
	}
	
	
	public void menuResize(){
		int y_offset=48;
		int x_offset=177;
		int y0=((HomeUI)Client.clientGUI).innerpanel.getHeight();
		int x=((SchoolHomeAdminGUI)((HomeUI)Client.clientGUI).innerpanel).tmp_panel.getWidth();
		int y=((SchoolHomeAdminGUI)((HomeUI)Client.clientGUI).innerpanel).tmp_panel.getHeight();
		int home_x=Client.clientGUI.getX();
		int home_y=Client.clientGUI.getY();
		int dif_width=(x_offset+x)-(((HomeUI)Client.clientGUI).getbtnX()+30);
		if(page==3){y=y0=592;}
		if(page==2){y=y0=350;}
		((HomeUI)Client.clientGUI).innerpanel.setBounds(0,y_offset , x_offset+x, y_offset+(y>y0?y:y0));
		((HomeUI)Client.clientGUI).contentPane.setBounds(0, 0, x_offset+x, y_offset+(y>y0?y:y0));
		((HomeUI)Client.clientGUI).setBounds(home_x, home_y, x_offset+x, y_offset+(y>y0?y:y0));
		((HomeUI)Client.clientGUI).setNewBounds(dif_width-10);
		((HomeUI)Client.clientGUI).repaint();
	}
	
	
	public void setflag(int f)
	{	
		this.flag=f;
	}
	
	public int getflag()
	{
		return this.flag;
	}
}




