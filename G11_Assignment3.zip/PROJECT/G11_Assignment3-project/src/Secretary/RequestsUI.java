package Secretary;

import javax.swing.JPanel;
import javax.swing.SwingConstants;

import OurMessage.Message;
import OurMessage.QTypes;
import chat.Client;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import java.awt.Color;

public class RequestsUI extends JPanel {
	private final JButton btnmove = new JButton("");
	private final JButton btnblock = new JButton("");
	private final JButton btnCan = new JButton("");
	/**
	 * Create the panel.
	 */
	public RequestsUI() {
		setBackground(Color.WHITE);
		((SecretaryHomeUI)Client.userMenu).page=2;
		setBounds(177, 0, 520, 380);
		setLayout(null);
		//Move Class
		JLabel iconLabelMove = new JLabel(new ImageIcon("img\\Secretary\\RequestUI\\Html-tags-icon.png"));
		JLabel clickMeMove = new JLabel("Move Class Request", SwingConstants.CENTER);
		btnmove.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Client.client.handleMessageFromClientUI(new Message("SELECT idStudent,idClass,aprove FROM requests WHERE aprove!='NYD' AND sem_id="+Client.opnedsem+" AND status=0;",QTypes.getrequests));
			}
		});
		btnmove.setLayout(new BorderLayout());
		btnmove.add(iconLabelMove, BorderLayout.WEST);
		btnmove.add(clickMeMove, BorderLayout.CENTER);
		//btnmove.setOpaque(false);
		btnmove.setContentAreaFilled(false);
		btnmove.setBorderPainted(false);
		btnmove.setBounds(197, 102,  190, 45);
		add(btnmove);
		//Block Parent
		JLabel iconLabelBlock = new JLabel(new ImageIcon("img\\Secretary\\RequestUI\\Rss-icon.png"));
		JLabel clickMeBlock = new JLabel("Block Parent!", SwingConstants.CENTER);
		btnblock.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Client.client.handleMessageFromClientUI(new Message("SELECT id_student,id_parent,approve FROM request_block WHERE approve!='NYD' AND sem_id="+Client.opnedsem+" AND status=0;",QTypes.getblockrequest));
			}
		});
		btnblock.setLayout(new BorderLayout());
		btnblock.add(iconLabelBlock, BorderLayout.WEST);
		btnblock.add(clickMeBlock, BorderLayout.CENTER);
		//btnblock.setOpaque(false);
		btnblock.setContentAreaFilled(false);
		btnblock.setBorderPainted(false);
		btnblock.setBounds(197, 158,  190, 45);
		add(btnblock);
		//Cancel
		JLabel iconLabelCan = new JLabel(new ImageIcon("img\\Secretary\\CreateSemesterUI\\Button-2-stop-icon.png"));
		JLabel clickMeCan = new JLabel("Cancel", SwingConstants.CENTER);
		btnCan.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				((SecretaryHomeUI)Client.userMenu).ChangeJPanel(new HomeSelectUI());
				((SecretaryHomeUI)Client.userMenu).setbuttons(5);
			}
		});
		btnCan.setLayout(new BorderLayout());
		btnCan.add(iconLabelCan, BorderLayout.WEST);
		btnCan.add(clickMeCan, BorderLayout.CENTER);
		//btnCan.setOpaque(false);
		btnCan.setContentAreaFilled(false);
		btnCan.setBorderPainted(false);
		btnCan.setBounds(197, 214, 190, 45);
		add(btnCan);
	}

}
