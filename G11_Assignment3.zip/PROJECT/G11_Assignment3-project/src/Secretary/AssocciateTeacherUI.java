package Secretary;

import java.awt.BorderLayout;
import java.awt.Color;

import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.ListSelectionModel;
import javax.swing.SwingConstants;
import javax.swing.border.MatteBorder;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.DefaultTableModel;

import Entities.ClassRoomSchdule;
import Entities.ClassRoomStudent;
import Entities.Course;
import Entities.StudentName;
import Entities.TeachUnit;
import Entities.TeacherHours;
import Entities.TeacherName;
import Entities.TeacherTU;
import OurMessage.Message;
import OurMessage.QTypes;
import chat.Client;

import javax.swing.Icon;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.util.ArrayList;
import javax.swing.JButton;

public class AssocciateTeacherUI extends JPanel {
	public ArrayList<ClassRoomSchdule> classeschdule;
	public ArrayList<TeacherName> teahcerlist;
	public ArrayList<TeachUnit> TUlist;
	public ArrayList<Course> courseslist;
	public ArrayList<TeacherHours> teacherhourlist;
	public ArrayList<TeacherTU> teacherTUlist;

	private final JTable tblCourses;
	private final JTable tblClass;
	private final JTable tblTeacher;
	private final JTable tblTU;
	private final JLabel imgcourse = new JLabel(new ImageIcon("img\\Secretary\\AssocciateTeacherUI\\curlyBrace.png"));
	private final JLabel imgclass = new JLabel(new ImageIcon("img\\Secretary\\AssocciateTeacherUI\\curlyBrace.png"));
	private final JLabel imgteacher = new JLabel(new ImageIcon("img\\Secretary\\AssocciateTeacherUI\\curlyBrace.png"));
	private final JLabel imgTU = new JLabel(new ImageIcon("img\\Secretary\\AssocciateTeacherUI\\curlyBrace.png"));
	private final JLabel iconclass = new JLabel(new ImageIcon("img\\Secretary\\AssocciateTeacherUI\\Networking-icon.png"));
	private final JLabel lblclass = new JLabel("Class");
	private final JLabel iconTU = new JLabel(new ImageIcon("img\\Secretary\\AssocciateTeacherUI\\Files-2-icon.png"));
	private final JLabel lblTU = new JLabel("Teach Unit");
	private final JLabel iconcourse = new JLabel(new ImageIcon("img\\Secretary\\AssocciateTeacherUI\\Files-icon.png"));
	private final JLabel lblcourse = new JLabel("Course");
	private final JLabel iconteacher = new JLabel(new ImageIcon("img\\Secretary\\AssocciateTeacherUI\\Briefcase-icon.png"));
	private final JLabel lblteacher = new JLabel("Teacher");
	private final JLabel lblsuc = new JLabel("");
	private final JButton btnAddTeacher = new JButton("");
	private final JButton btnCan=new JButton("");
	private final JLabel lblcl = new JLabel("");
	private final JLabel lblteach = new JLabel("");
	private final JLabel lblcou = new JLabel("");
	private final JLabel lbltea = new JLabel("");

	/**
	 * Create the panel.
	 * Jpanel for assocciating courses and teacher to classes.
	 */
	public AssocciateTeacherUI() {
		setBounds(177,0,728,446);
		setLayout(null);
		((SecretaryHomeUI)Client.userMenu).page=5;

		//button Add

		JLabel iconLabeladd = new JLabel(new ImageIcon("img\\Secretary\\AssocciatingClassUI\\Basket-icon.png"));
		JLabel clickMeadd = new JLabel("Add", SwingConstants.CENTER);
		btnAddTeacher.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				lblcl.setVisible(false);
				lblteach.setVisible(false);
				lblcou.setVisible(false);
				lbltea.setVisible(false);
				if(tblClass.getSelectedRow()==-1)
				{
					lblcl.setText("*Select First");
					lblcl.setForeground(Color.RED);
					lblcl.setVisible(true);
					
				}else{
					if(tblTU.getSelectedRow()==-1)
					{
						lblteach.setText("*Select First");
						lblteach.setForeground(Color.RED);
						lblteach.setVisible(true);
					}else{
						if(tblCourses.getSelectedRow()==-1)
						{
							lblcou.setText("*Select First");
							lblcou.setForeground(Color.RED);
							lblcou.setVisible(true);
						}else{
							if(tblTeacher.getSelectedRow()==-1)
							{
								lbltea.setText("*Select First");
								lbltea.setForeground(Color.RED);
								lbltea.setVisible(true);
							}else{
								Client.client.handleMessageFromClientUI(new Message("INSERT INTO class_schedule VALUES ('"+tblClass.getValueAt(tblClass.getSelectedRow(), 0).toString()
										+"','"+tblCourses.getValueAt(tblCourses.getSelectedRow(), 0).toString()+"',"+tblTeacher.getValueAt(tblTeacher.getSelectedRow(), 0)+","+Client.opnedsem+");",QTypes.insertnewteacher));
							}
						}
					}
				}
				
			}
		});
		
		btnAddTeacher.setLayout(new BorderLayout());
		btnAddTeacher.add(iconLabeladd, BorderLayout.WEST);
		btnAddTeacher.add(clickMeadd, BorderLayout.CENTER);
		btnAddTeacher.setOpaque(false);
		btnAddTeacher.setContentAreaFilled(false);
		btnAddTeacher.setBorderPainted(false);
		btnAddTeacher.setBounds(42, 384, 137, 45);
		btnAddTeacher.setEnabled(true);
		add(btnAddTeacher);
		//button Cancel
		JLabel iconLabelCan = new JLabel(new ImageIcon("img\\Secretary\\CreateSemesterUI\\Button-2-stop-icon.png"));
		JLabel clickMeCan = new JLabel("Cancel", SwingConstants.CENTER);
		btnCan.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				((SecretaryHomeUI)Client.userMenu).ChangeJPanel(new HomeSelectUI());
				((SecretaryHomeUI)Client.userMenu).setbuttons(5);
			}
		});
		btnCan.setLayout(new BorderLayout());
		btnCan.add(iconLabelCan, BorderLayout.WEST);
		btnCan.add(clickMeCan, BorderLayout.CENTER);
		btnCan.setOpaque(false);
		btnCan.setContentAreaFilled(false);
		btnCan.setBorderPainted(false);
		btnCan.setBounds(536, 384, 137, 45);
		add(btnCan);
		//============================
		imgcourse.setBounds(499,64,87,26);
		add(imgcourse);
		imgclass.setBounds(42,64,87,26);
		add(imgclass);
		imgteacher.setBounds(319,64,87,26);
		add(imgteacher);
		imgTU.setBounds(139,64,87,26);
		add(imgTU);
		//Classes Table
		tblClass = new JTable(){public boolean isCellEditable(int row,int column){Object o = getValueAt(row,column);if(o!=null) return false;return true;}}; 
		tblClass.setBorder(new MatteBorder(1, 1, 1, 1, Color.BLACK));
		tblClass.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
		tblClass.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		Object[][] tableItems=new Object[60][1];
		char grade='A';
		int number=1;
		for(int i=0;i<60;i++){
			tableItems[i][0]=new String(grade+"/"+number);
			if(number!=5){
				number++;
			}
			else{
				number=1;
				grade++;
			}
		}
		tblClass.setModel(new DefaultTableModel(tableItems,new String[] {""}));
		tblClass.getSelectionModel().addListSelectionListener(new ListSelectionListener() {
		   
			@Override
			public void valueChanged(ListSelectionEvent e) {
				// TODO Auto-generated method stub
				tblTU.setEnabled(true);
				tblCourses.setModel(new DefaultTableModel(new String[] {"",""}, 0));
				tblCourses.setEnabled(false);
				tblTeacher.setModel(new DefaultTableModel(new String[] {"",""}, 0));
				tblTeacher.setEnabled(false);
				//getStudentsforClass();
			}
		});
		JScrollPane classpane=new JScrollPane(tblClass, JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED, JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
		classpane.setBounds(42, 88, 87, 250);
		add(classpane);
		//Teaching Unit Table
		tblTU= new JTable(){public boolean isCellEditable(int row,int column){Object o = getValueAt(row,column);if(o!=null) return false;return true;}};
		tblTU.getSelectionModel().addListSelectionListener(new ListSelectionListener() {
			   
			@Override
			public void valueChanged(ListSelectionEvent e) {
				// TODO Auto-generated method stub
				if(tblTU.getSelectedRow()!=-1){
					getCoursesforClass(tblClass.getValueAt(tblClass.getSelectedRow(), 0).toString(),tblTU.getValueAt(tblTU.getSelectedRow(), 0).toString());
					tblCourses.setEnabled(true);
					tblTeacher.setModel(new DefaultTableModel(new String[] {"",""}, 0));
					tblTeacher.setEnabled(false);
				}
				//getStudentsforClass();
			}
		});
		tblTU.setBorder(new MatteBorder(1, 1, 1, 1, Color.BLACK));
		tblTU.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		tblTU.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
		tblTU.setEnabled(false);
		JScrollPane TUpane=new JScrollPane(tblTU, JScrollPane.VERTICAL_SCROLLBAR_NEVER, JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
		TUpane.setBounds(139, 88, 170, 250);
		add(TUpane);
		//Courses Table
		tblCourses= new JTable(){public boolean isCellEditable(int row,int column){Object o = getValueAt(row,column);if(o!=null) return false;return true;}};
		tblCourses.getSelectionModel().addListSelectionListener(new ListSelectionListener() {
			   
			@Override
			public void valueChanged(ListSelectionEvent e) {
				// TODO Auto-generated method stub
				if(tblCourses.getSelectedRow()!=-1){
					//getCoursesforClass(tblClass.getValueAt(tblClass.getSelectedRow(), 0).toString(),tblTU.getValueAt(tblTU.getSelectedRow(), 0).toString());	
					 getteachers(tblTU.getValueAt(tblTU.getSelectedRow(), 0).toString(),tblCourses.getValueAt(tblCourses.getSelectedRow(), 0).toString());
						tblTeacher.setEnabled(true);

				}
			}
		});
		tblCourses.setBorder(new MatteBorder(1, 1, 1, 1, Color.BLACK));
		tblCourses.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		tblCourses.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
		tblCourses.setEnabled(false);
		JScrollPane Coursepane=new JScrollPane(tblCourses, JScrollPane.VERTICAL_SCROLLBAR_NEVER, JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
		Coursepane.setBounds(319, 88, 170, 250);
		add(Coursepane);
		//Courses Table
		tblTeacher= new JTable(){public boolean isCellEditable(int row,int column){Object o = getValueAt(row,column);if(o!=null) return false;return true;}};
		tblTeacher.setBorder(new MatteBorder(1, 1, 1, 1, Color.BLACK));
		tblTeacher.setSelectionMode(ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);
		tblTeacher.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
		tblTeacher.setEnabled(false);
		tblTeacher.getSelectionModel().addListSelectionListener(new ListSelectionListener() {
			   
			@Override
			public void valueChanged(ListSelectionEvent e) {
				// TODO Auto-generated method stub
				if(tblCourses.getSelectedRow()!=-1){
					btnAddTeacher.setEnabled(true);

				}
			}
		});
		JScrollPane jsteach=new JScrollPane(tblTeacher, JScrollPane.VERTICAL_SCROLLBAR_NEVER, JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
		jsteach.setBounds(499, 88, 170, 250);
		add(jsteach);
		iconclass.setBounds(47, 33, 30, 30);
		
		add(iconclass);
		lblclass.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblclass.setBounds(79, 44, 50, 14);
		
		add(lblclass);
		iconTU.setBounds(171, 33, 30, 30);
		
		add(iconTU);
		lblTU.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblTU.setBounds(211, 44, 67, 14);
		
		add(lblTU);
		iconcourse.setBounds(345, 33, 30, 30);
		
		add(iconcourse);
		lblcourse.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblcourse.setBounds(377, 44, 50, 14);
		
		add(lblcourse);
		iconteacher.setBounds(499, 33, 30, 30);
		
		add(iconteacher);
		lblteacher.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblteacher.setBounds(536, 44, 50, 14);
		
		add(lblteacher);
		lblsuc.setBounds(102, 19, 484, 14);
		
		add(lblsuc);
		lblcl.setBounds(42, 344, 87, 14);
		
		add(lblcl);
		lblteach.setBounds(139, 344, 170, 14);
		
		add(lblteach);
		lblcou.setBounds(319, 344, 170, 14);
		
		add(lblcou);
		lbltea.setBounds(499, 344, 170, 14);
		
		add(lbltea);
	
		
	}
	/**
	 * Displays a text after a successful insertion to table(DB).
	 */
	public void addedsuccessfully(){
		lblsuc.setText("*Succesfully Added Course!Reload Page to add more!");
		lblsuc.setForeground(Color.GREEN);
		lblsuc.setVisible(true);
		tblClass.setEnabled(false);
		tblTU.setEnabled(false);
		tblCourses.setEnabled(false);
		tblTeacher.setEnabled(false);
	}
	/**
	 * Displays a text after an unsuccessful insertion to table(DB).
	 */
	public void addedUnsuccessfully(){
		lblsuc.setText("*Unsuccesfully Added Course!Reload Page to add more!");
		lblsuc.setForeground(Color.RED);
		lblsuc.setVisible(true);
		tblClass.setEnabled(false);
		tblTU.setEnabled(false);
		tblCourses.setEnabled(false);
		tblTeacher.setEnabled(false);
	}
	/**
	 * Displays a text if There is no Current Semester.
	 */
	public void noCurrentSemesterTime(){
		lblsuc.setText("*An Error Accuried while adding to DB!");
		lblsuc.setForeground(Color.RED);
		//tblTU.setEnabled(true);
		//tblCourses.setModel(new DefaultTableModel(new String[] {"",""}, 0));
		tblClass.setEnabled(false);
		tblTU.setEnabled(false);
		tblCourses.setEnabled(false);
		//tblTeacher.setModel(new DefaultTableModel(new String[] {"",""}, 0));
		tblTeacher.setEnabled(false);
	}
	/**
	 * Enters Teaching Units values to table (Data which we got for the DataBase).
	 */
	public void getTUlist(){
		DefaultTableModel tableModel = new DefaultTableModel(new String[] {"",""}, 0);
		tblTU.setModel(tableModel);
		for(TeachUnit tu:TUlist){
			Object[] data={tu.getTeachUnit_ID(),tu.getTeachUnit_Name()};
			tableModel.addRow(data);
		}
	}
	/**
	 * Enters teachers values to table (Data which we got for the DataBase).
	 */
	public void getteachers(String TU,String cc){
		ArrayList<TeacherName> TeacherTUYList=new ArrayList<TeacherName>();
		ArrayList<TeacherHours> TeacherhourYList=new ArrayList<TeacherHours>();
		DefaultTableModel tableModel = new DefaultTableModel(new String[] {"",""}, 0);
		tblTeacher.setModel(tableModel);
		for(TeacherTU tu:teacherTUlist){//Teacher which belongs to this TU
			if(tu.getTu().equals(TU))
			{
				for(TeacherName tn:teahcerlist){
					if(tn.getId()==tu.getId())
						TeacherTUYList.add(tn);
				}
				for(TeacherHours th:teacherhourlist){
					if(th.getId()==tu.getId())
						TeacherhourYList.add(th);
				}
				
			}
		}
		Course c=null;
		for(Course k:courseslist){
			if(k.getCourse_ID().equals(cc))
				c=k;
		}
		for(int i=0;i<TeacherhourYList.size();i++){
			if(TeacherhourYList.get(i).getCurrenthours()+c.getCourseStudyHours()<=TeacherhourYList.get(i).getMaxhours()){
				Object[] data={TeacherTUYList.get(i).getId(),TeacherTUYList.get(i).getName()};
				tableModel.addRow(data);
			}
		}
		
	}
	/**
	 * Enters Courses values to table (Data which we got for the DataBase).
	 */
	public void getCoursesforClass(String class_id,String TU_id){
		ArrayList<Course> courseNlist=new ArrayList<Course>();
		ArrayList<ClassRoomSchdule> classNlist=new ArrayList<ClassRoomSchdule>();
		DefaultTableModel tableModel = new DefaultTableModel(new String[] {"",""}, 0);
		tblCourses.setModel(tableModel);
		//PRECOURSES CHECK
		
		for(Course c:courseslist){//Teaching unit Classes
			if(c.getTeachUnit_ID().equals(TU_id))
				courseNlist.add(c);
		}
		for(ClassRoomSchdule css:classeschdule){//Class Courses
			if(css.getClass_id().equals(class_id) && Client.opnedsem.equals(css.getSem_id()))
				classNlist.add(css);
		}
		boolean flag;
		for(Course c:courseNlist){//Courses which is not in class
			flag=true;
			for(ClassRoomSchdule cs:classNlist){
				if(c.getCourse_ID().equals(cs.getCourse()))
					flag=false;
			}
			if(flag)
			{
				Object[] data={c.getCourse_ID(),c.getCourse_Name()};
				tableModel.addRow(data);
			}
			
		}
		
	}
}
