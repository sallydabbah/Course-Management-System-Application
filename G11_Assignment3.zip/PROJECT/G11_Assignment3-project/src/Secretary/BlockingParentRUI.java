package Secretary;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTable;
import javax.swing.ListSelectionModel;
import javax.swing.SwingConstants;
import javax.swing.border.MatteBorder;

import OurMessage.Message;
import OurMessage.QTypes;
import chat.Client;

public class BlockingParentRUI extends JPanel {
	public final JTable tblRequest;
	private final JButton btnupdate = new JButton("");
	private final JButton btnCan = new JButton("");
	private final JLabel lblstudent = new JLabel("Student");
	private final JLabel lblparent = new JLabel("Parent");
	private final JLabel lblApprove = new JLabel("Approve");
	private final JLabel imgstu = new JLabel(new ImageIcon("img\\Secretary\\ExceptionStudentsUI\\Addressbook-3-icon.png"));
	private final JLabel imgcla = new JLabel(new ImageIcon("img\\Secretary\\ExceptionStudentsUI\\Bank-icon.png"));	
	private final JLabel imgapp = new JLabel(new ImageIcon("img\\Secretary\\ExceptionStudentsUI\\Bulb-icon.png"));	
	private final JLabel lblsuc = new JLabel("");
	/**
	 * Create the panel.
	 * Updating DB after school administrator decision.
	 */
	public BlockingParentRUI() {
		((SecretaryHomeUI)Client.userMenu).page=6;
		setBackground(Color.WHITE);
		setBounds(177, 0, 487, 350);
		setLayout(null);
		//Setting Table to not editable
		tblRequest = new JTable(){  
		       public boolean isCellEditable(int row,int column){  
		           Object o = getValueAt(row,column);  
		           if(o!=null) return false;  
		           return true;  
		         }  
		       }; 
		tblRequest.setBorder(new MatteBorder(1, 1, 1, 1, Color.BLACK));
		tblRequest.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		tblRequest.setBounds(10, 31, 467, 205);
		add(tblRequest);
		//Button Update System & send message to Student
		JLabel iconLabelupdate = new JLabel(new ImageIcon("img\\Secretary\\ExceptionStudentsUI\\Arrow-download-2-icon.png"));
		JLabel clickMeupdate = new JLabel("Update DB", SwingConstants.CENTER);
		btnupdate.setEnabled(true);
		btnupdate.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				lblsuc.setVisible(false);
				if(tblRequest.getSelectedRow()!=-1){
					if(!(tblRequest.getValueAt(tblRequest.getSelectedRow(), 2).toString()).equals("Denied"))
						Client.client.handleMessageFromClientUI(new Message("update users set status=2 where id="+tblRequest.getValueAt(tblRequest.getSelectedRow(), 1)+";#update request_block set status=1 where id_student="+tblRequest.getValueAt(tblRequest.getSelectedRow(), 0)+" and sem_id="+Client.opnedsem+";",QTypes.updaterequestB));
					else
						Client.client.handleMessageFromClientUI(new Message("update request_block set status=1 where id_student="+tblRequest.getValueAt(tblRequest.getSelectedRow(), 0)+" and sem_id="+Client.opnedsem+";",QTypes.updaterequestB));
				}
				else{
					lblsuc.setText("*Select a row first!");
					lblsuc.setForeground(Color.RED);
					lblsuc.setVisible(true);

				}
				
			}
		});
		btnupdate.setLayout(new BorderLayout());
		btnupdate.add(iconLabelupdate, BorderLayout.WEST);
		btnupdate.add(clickMeupdate, BorderLayout.CENTER);
		btnupdate.setOpaque(false);
		btnupdate.setContentAreaFilled(false);
		btnupdate.setBorderPainted(false);
		btnupdate.setBounds(10, 270, 157, 45);
		add(btnupdate);
		//Cancel Button

		JLabel iconLabelCan = new JLabel(new ImageIcon("img\\Secretary\\CreateSemesterUI\\Button-2-stop-icon.png"));
		JLabel clickMeCan = new JLabel("Cancel", SwingConstants.CENTER);
		btnCan.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				((SecretaryHomeUI)Client.userMenu).ChangeJPanel(new RequestsUI());
				((SecretaryHomeUI)Client.userMenu).setbuttons(5);
			}
		});
		btnCan.setLayout(new BorderLayout());
		btnCan.add(iconLabelCan, BorderLayout.WEST);
		btnCan.add(clickMeCan, BorderLayout.CENTER);
		btnCan.setOpaque(false);
		btnCan.setContentAreaFilled(false);
		btnCan.setBorderPainted(false);
		btnCan.setBounds(254, 270, 137, 45);
		add(btnCan);
		//Student Label
		imgstu.setBounds(10, 5, 20, 20);
		add(imgstu);
		lblstudent.setBounds(32,9, 60, 14);
		add(lblstudent);
		//class Label
		imgcla.setBounds(172, 5, 20, 20);
		add(imgcla);
		lblparent.setBounds(194, 9, 45, 14);
		add(lblparent);
		//Approve Label
		imgapp.setBounds(326, 5, 20, 20);
		add(imgapp);
		lblApprove.setBounds(348, 9, 70, 14);
		add(lblApprove);
		lblsuc.setBounds(20, 247, 445, 14);
		
		add(lblsuc);
		
	}
	/**
	 * Displays a text after a successful insertion to table.
	 */
	public void  success(){
		lblsuc.setText("*Succesfully Updated!Reload Page to update more!");
		lblsuc.setForeground(Color.GREEN);
		lblsuc.setVisible(true);
		tblRequest.setEnabled(false);
		btnupdate.setEnabled(false);
		
	}
	/**
	 * Displays a text after an unsuccessful insertion to table.
	 */
	public void failed(){
		lblsuc.setText("*Unsuccesfully Updated!Reload Page to update more!");
		lblsuc.setForeground(Color.RED);
		lblsuc.setVisible(true);
		tblRequest.setEnabled(false);
		btnupdate.setEnabled(false);
		
	}
}
