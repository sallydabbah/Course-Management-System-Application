package Secretary;

import javax.swing.JPanel;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPopupMenu;
import javax.swing.SwingConstants;

import OurMessage.Message;
import OurMessage.QTypes;
import User.HomeUI;
import chat.Client;
import sysAdmin.sysAdminHomeUI;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JLabel;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Color;
import javax.swing.JSeparator;

public class SecretaryHomeUI extends JPanel {
	private JPanel menubtnspnl;
	private JPanel viewpanel;
	private final JButton btnCreate = new JButton("");
	private JButton btnAssocciate;
	private JButton btnAssocciateTeacher;
	private JButton btnExcep;
	private JButton btnExRes;
	public int page;
	/**
	 * Create the panel.
	 * Secretary Menu Jpanel
	 */
	public SecretaryHomeUI() {
		

		setBackground(Color.WHITE);
		
		setBounds(10, 59, 424, 300);
		setLayout(null);
		menubtnspnl = new JPanel();
		menubtnspnl.setBackground(Color.WHITE);
		menubtnspnl.setBounds(0, 0, 177, 300);
		add(menubtnspnl);
		menubtnspnl.setLayout(null);
		
		
		//Button Items
		//Menu Item 1:
		JLabel iconLabel = new JLabel(new ImageIcon("img\\Secretary\\SecretaryHomeUI\\Add-icon.png"));
		JLabel clickMe = new JLabel("Creating Semester", SwingConstants.CENTER);
		btnCreate.setLayout(new BorderLayout());
		btnCreate.add(iconLabel, BorderLayout.WEST);
		btnCreate.add(clickMe, BorderLayout.CENTER);
		btnCreate.setOpaque(false);
		btnCreate.setContentAreaFilled(false);
		btnCreate.setBorderPainted(false);
		btnCreate.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				//((SecretaryHomeUI)((HomeUI)Client.clientGUI).innerpanel).ChangeSJPanel(new CreatingSemesterUI());
				Client.client.handleMessageFromClientUI(new Message("select * from semster where id=(select max(id) FROM semster);",QTypes.checksemester));
				//ChangeJPanel(new CreatingSemesterUI());
				setbuttons(1);
				//Disable this button and enable the rest
			}
		});
		btnCreate.setBounds(0, 11, 177, 35);
		menubtnspnl.add(btnCreate);
		//Menu Item 2:
		JLabel iconLabelAsc = new JLabel(new ImageIcon("img\\Secretary\\SecretaryHomeUI\\Group-icon.png"));
		JLabel clickMeAsc = new JLabel("Assocciating Class", SwingConstants.CENTER);
		btnAssocciate = new JButton("");
		btnAssocciate.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if(Client.opnedsem.equals("")){
					((SecretaryHomeUI)Client.userMenu).ChangeJPanel(new AssocciateClassUI());
					((AssocciateClassUI)(Client.selectedMenu)).noCurrentSemesterTime();
					
				}
				else	
					Client.client.handleMessageFromClientUI(new Message("SELECT * FROM class_students WHERE sem_id="+Client.opnedsem+";/SELECT id,name FROM users WHERE access=1;",QTypes.getassocciateclass));
				setbuttons(3);

			}
		});
		btnAssocciate.setLayout(new BorderLayout());
		btnAssocciate.add(iconLabelAsc, BorderLayout.WEST);
		btnAssocciate.add(clickMeAsc, BorderLayout.CENTER);
		btnAssocciate.setOpaque(false);
		btnAssocciate.setContentAreaFilled(false);
		btnAssocciate.setBorderPainted(false);
		btnAssocciate.setBounds(0, 46, 177, 35);
		menubtnspnl.add(btnAssocciate);
		//Menu Item 3:
		JLabel iconLabelExc = new JLabel(new ImageIcon("img\\Secretary\\SecretaryHomeUI\\Find-person-icon.png"));
		JLabel clickMeExc = new JLabel("Requests Update", SwingConstants.CENTER);
		btnExcep = new JButton("");
		btnExcep.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				ChangeJPanel(new RequestsUI());
				//
				//Disable this button and enable the rest
				setbuttons(2);
				//ChangeJPanel(new ExceptionStudentsUI());
			}
		});
		btnExcep.setLayout(new BorderLayout());
		btnExcep.add(iconLabelExc, BorderLayout.WEST);
		btnExcep.add(clickMeExc, BorderLayout.CENTER);
		btnExcep.setOpaque(false);
		btnExcep.setContentAreaFilled(false);
		btnExcep.setBorderPainted(false);
		btnExcep.setBounds(0, 81, 177, 35);
		menubtnspnl.add(btnExcep);
		//Menu Item 4:
		
		//Menu Item 5:
		JLabel iconLabelteach = new JLabel(new ImageIcon("img\\Secretary\\SecretaryHomeUI\\Briefcase-icon.png"));
		JLabel clickMeteach = new JLabel("Assocciate Teacher", SwingConstants.CENTER);
		btnAssocciateTeacher = new JButton("");
		btnAssocciateTeacher.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if(Client.opnedsem.equals("")){
					((SecretaryHomeUI)Client.userMenu).ChangeJPanel(new AssocciateTeacherUI());
					((AssocciateTeacherUI)(Client.selectedMenu)).noCurrentSemesterTime();
				}
				else{
					Client.client.handleMessageFromClientUI(new Message("SELECT * FROM class_schedule;/SELECT id,name FROM users WHERE access=2;/SELECT * FROM teaching_unit;/SELECT * FROM courses;/SELECT * FROM pre_courses;/SELECT * FROM teacher_hours WHERE sem_id="+Client.opnedsem+";/SELECT * FROM teacher where sem_id="+Client.opnedsem+";",QTypes.getassocciateteacher));
				}	
				setbuttons(6);
			}
		});
		btnAssocciateTeacher.setLayout(new BorderLayout());
		btnAssocciateTeacher.add(iconLabelteach, BorderLayout.WEST);
		btnAssocciateTeacher.add(clickMeteach, BorderLayout.CENTER);
		btnAssocciateTeacher.setOpaque(false);
		btnAssocciateTeacher.setContentAreaFilled(false);
		btnAssocciateTeacher.setBorderPainted(false);
		btnAssocciateTeacher.setBounds(0, 116, 177, 35);
		menubtnspnl.add(btnAssocciateTeacher);
		
		JSeparator separator = new JSeparator();
		separator.setBackground(Color.LIGHT_GRAY);
		separator.setBounds(10, 11, 157, 2);
		menubtnspnl.add(separator);
		
		JSeparator separator_1 = new JSeparator();
		separator_1.setBackground(Color.LIGHT_GRAY);
		separator_1.setBounds(10, 46, 157, 2);
		menubtnspnl.add(separator_1);
		
		JSeparator separator_2 = new JSeparator();
		separator_2.setBackground(Color.LIGHT_GRAY);
		separator_2.setBounds(10, 79, 157, 2);
		menubtnspnl.add(separator_2);
		
		JSeparator separator_3 = new JSeparator();
		separator_3.setBackground(Color.LIGHT_GRAY);
		separator_3.setBounds(10, 114, 157, 2);
		menubtnspnl.add(separator_3);
		
		JSeparator separator_4 = new JSeparator();
		separator_4.setBackground(Color.LIGHT_GRAY);
		separator_4.setBounds(10, 149, 157, 2);
		menubtnspnl.add(separator_4);
		//===============================
		
		viewpanel = new JPanel();
		viewpanel.setBackground(Color.WHITE);
		viewpanel.setBounds(176, 0, 248, 300);
		add(viewpanel);
		Client.clientGUI.setTitle("Secretary Menu!");
		
	}
	/**
	 * Enable/Disable Menu buttons
	 * num is number of the button(5 to enable all the buttons)
	 * @param num
	 */
	public void setbuttons(int num){
		
		switch(num){
		case 1:
			this.btnCreate.setEnabled(false);
			this.btnExcep.setEnabled(true);
			this.btnAssocciate.setEnabled(true);
			//this.btnExRes.setEnabled(true);
			this.btnAssocciateTeacher.setEnabled(true);
			break;
		case 2:
			this.btnCreate.setEnabled(true);
			this.btnExcep.setEnabled(false);
			this.btnAssocciate.setEnabled(true);
			//this.btnExRes.setEnabled(true);
			this.btnAssocciateTeacher.setEnabled(true);
			break;
		case 3:
			this.btnCreate.setEnabled(true);
			this.btnExcep.setEnabled(true);
			this.btnAssocciate.setEnabled(false);
			//this.btnExRes.setEnabled(true);
			this.btnAssocciateTeacher.setEnabled(true);
			break;
		case 4:
			this.btnCreate.setEnabled(true);
			this.btnExcep.setEnabled(true);
			this.btnAssocciate.setEnabled(true);
			//this.btnExRes.setEnabled(false);
			this.btnAssocciateTeacher.setEnabled(true);
			break;
		case 5:
			this.btnCreate.setEnabled(true);
			this.btnExcep.setEnabled(true);
			this.btnAssocciate.setEnabled(true);
			//this.btnExRes.setEnabled(true);
			this.btnAssocciateTeacher.setEnabled(true);
			break;
		case 6:
			this.btnCreate.setEnabled(true);
			this.btnExcep.setEnabled(true);
			this.btnAssocciate.setEnabled(true);
			//this.btnExRes.setEnabled(true);
			this.btnAssocciateTeacher.setEnabled(false);
			break;
		}
	}
	/**
	 * This funtion recieve the panel which we want to change with the old one.
	 * @param panel
	 */
	public void ChangeJPanel(JPanel panel){
		((SecretaryHomeUI)Client.userMenu).remove(((SecretaryHomeUI)Client.userMenu).viewpanel);
		Client.selectedMenu=panel;
		((SecretaryHomeUI)Client.userMenu).viewpanel=Client.selectedMenu;
		((SecretaryHomeUI)Client.userMenu).add(((SecretaryHomeUI)Client.userMenu).viewpanel);
		menuResize();
	}
	/**
	 * This function resize the JFrame & Jpanel to keep it in range!
	 */
	public void menuResize(){
		int y_offset=48;
		int x_offset=177;
		int y0=Client.userMenu.getHeight();
		int x=Client.selectedMenu.getWidth();
		int y=Client.selectedMenu.getHeight();
		int home_x=Client.clientGUI.getX();
		int home_y=Client.clientGUI.getY();
		int dif_width=(x_offset+x)-(((HomeUI)Client.clientGUI).getbtnX()+30);
		//System.out.println("home_x="+home_x+",home_y="+home_y+",dif_width="+dif_width);
		//System.out.println("y_offset="+y_offset+",x_offset="+x_offset+",y0="+y0+",x="+x+",y="+y);
		switch(page){
		case 0:y=y0=400;break;
		case 1:y=y0=400;break;
		case 2:y=y0=520;break;
		case 3:y=y0=350;break;
		case 4:y=y0=378;break;
		case 5:y=y0=466;break;
		case 6:y=y0=487;break;

		}
		((SecretaryHomeUI)Client.userMenu).viewpanel.setBounds(Client.selectedMenu.getX(), Client.selectedMenu.getY(), x, y);
		//System.out.println(y>y0?y:y0);
		((HomeUI)Client.clientGUI).innerpanel.setBounds(0,y_offset , x_offset+x, y_offset+(y<y0?y:y0));
		((HomeUI)Client.clientGUI).contentPane.setBounds(0, 0, x_offset+x, y_offset+(y<y0?y:y0));
		((HomeUI)Client.clientGUI).setBounds(home_x, home_y, x_offset+x, y_offset+(y<y0?y:y0));
		//Setting Buttons
		((HomeUI)Client.clientGUI).setNewBounds(dif_width-10);
		((HomeUI)Client.clientGUI).repaint();
	}
}
