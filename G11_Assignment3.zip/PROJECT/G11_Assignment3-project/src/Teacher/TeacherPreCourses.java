package Teacher;

import java.awt.Color;

import javax.swing.JPanel;
/**
 * 
 * @author A-Ar1
 *
 */
public class TeacherPreCourses extends JPanel {

	/**
	 * Create the panel.
	 */
	public TeacherPreCourses() {
		setBackground(Color.WHITE);
		setBounds(10, 59, 500, 350);
		setLayout(null);
	}

}
