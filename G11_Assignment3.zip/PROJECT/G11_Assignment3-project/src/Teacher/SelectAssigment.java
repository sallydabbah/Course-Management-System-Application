package Teacher;

import java.awt.Color;

import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.JComboBox;
import javax.swing.JTextField;

import OurMessage.Message;
import OurMessage.QTypes;
import chat.Client;

import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
/**
 * SelectAssigment class for select assigment that student uploaded and check it 
 * @author A-Ar1
 *
 */
public class SelectAssigment extends JPanel {
	private JTextField textgrade;
    public JComboBox combo_assigment = new JComboBox();
    public String  value_student;
    public String value_course;
    public String value_assigment;
	/**
	 * Create the panel.
	 */
	public SelectAssigment() {
		setBackground(Color.WHITE);
		setBounds(10, 59, 500, 350);
		setLayout(null);
		
		JLabel lblSelectAssigment = new JLabel("Select Assigment :");
		lblSelectAssigment.setBounds(26, 24, 126, 14);
		add(lblSelectAssigment);
		
		
		combo_assigment.setBounds(176, 21, 78, 20);
		add(combo_assigment);
		
		JLabel lblGrade = new JLabel("Grade :");
		lblGrade.setBounds(26, 97, 46, 14);
		add(lblGrade);
		
		textgrade = new JTextField();
		textgrade.setBounds(86, 94, 86, 20);
		add(textgrade);
		textgrade.setColumns(10);
		
	
		JButton btnSubmit = new JButton("Submit");
		btnSubmit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String grade = textgrade.getText();
				value_assigment = combo_assigment.getSelectedItem().toString();	
				Client.client.handleMessageFromClientUI(new Message("UPDATE assigment_grades SET grade="+grade+" Where id_student='"+value_student+"' AND course='"+value_course+"'AND id_assigment='"+value_assigment+"'",QTypes.uploadgrade));
			}
		});
		btnSubmit.setBounds(26, 223, 89, 23);
		add(btnSubmit);
		
		JButton btnDownloadAssigment = new JButton("Download Assigment");
		btnDownloadAssigment.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String grade = textgrade.getText();
				value_assigment = combo_assigment.getSelectedItem().toString();	
				Client.client.handleMessageFromClientUI(new Message("SELECT * FROM assigment_grades Where id_student='"+value_student+"' AND course='"+value_course+"'AND id_assigment='"+value_assigment+"'",QTypes.downloadfile));
			}
		});
		btnDownloadAssigment.setBounds(42, 155, 181, 23);
		add(btnDownloadAssigment);
	}

}
