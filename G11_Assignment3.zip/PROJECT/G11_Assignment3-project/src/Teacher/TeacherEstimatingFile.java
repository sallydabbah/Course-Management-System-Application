package Teacher;

import java.awt.Color;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Arrays;

import javax.swing.JPanel;
import javax.swing.JFileChooser;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Choice;
import javax.swing.JButton;
import upload.*;
import javax.swing.JTextField;

import OurMessage.Message;
import OurMessage.QTypes;
import chat.Client;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
/**
 * this class for uploading  the estimating file for each student
 * @author A-Ar1
 *
 */
public class TeacherEstimatingFile extends JPanel {
	static int MAX_FILE_SIZE=16777215;
	   public JFilePicker filePicker;
	   private JTextField txtstuid;
	   
	/**
	 * Create the panel.
	 */
	public TeacherEstimatingFile() {
		setBackground(Color.WHITE);
		setBounds(10, 59, 500, 350);
		setLayout(null);
		JLabel lblEstimatingFile = new JLabel("Estimating File");
		lblEstimatingFile.setBounds(193, 11, 101, 14);
		add(lblEstimatingFile);
		filePicker = new JFilePicker("Choose a file", "Browse...");
		filePicker.setBounds(-91, 102, 591, 52);
		filePicker.setMode(JFilePicker.MODE_SAVE);
		filePicker.addFileTypeFilter(".pdf", "PDF");
		filePicker.addFileTypeFilter(".doc", "Word File");
		filePicker.addFileTypeFilter(".docx", "Word File");
		filePicker.addFileTypeFilter(".xlsx", "excel File");
		filePicker.addFileTypeFilter(".xls", "excel File");
		filePicker.addFileTypeFilter(".jpg", "jpg File");
		JFileChooser fileChooser = filePicker.getFileChooser();
        fileChooser.setCurrentDirectory(new File("C:/"));
        
		
		add(filePicker);
		JLabel lblStudent = new JLabel("Student :");
		lblStudent.setBounds(22, 45, 46, 14);
		add(lblStudent);
		
		txtstuid = new JTextField();
		txtstuid.setBounds(92, 42, 86, 20);
		add(txtstuid);
		txtstuid.setColumns(10);
		
		JButton btnSendFile = new JButton("Send File");
		btnSendFile.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			String id = txtstuid.getText();
				//System.out.print(m);
				String filePath=filePicker.getSelectedFilePath();
				if(filePath.equals(""))
				{
					showerrdilog("You Need to but a file assigment");
					
				}
				else
				{
					if(filePath.endsWith(".doc") || filePath.endsWith(".docx") || filePath.endsWith(".xls")  || filePath.endsWith(".xlsx") || filePath.endsWith(".pdf")||filePath.endsWith(".jpg"))
					{
						filePath=filePath.replace("\\", "/");
						try {
							byte[] myfile = read(new File(filePath));
							String message=Arrays.toString(myfile);
							String fname = filePath.substring(filePath.lastIndexOf('/') +1, filePath.length());
							//System.out.print(f);
							Client.client.handleMessageFromClientUI(new Message(message,"INSERT INTO estimating (student_id,est_file,est_name,sem_id) VALUES ('" +id+ "'"
									+ ", ? , '"+fname+"' ,  "+ Client.client.opnedsem + ")",QTypes.uploadest));
						} catch (IOException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						}
						
					}
					else
					{
						showerrdilog("Your File type is not Supported !!");
					}
				}
				
			}
		});
		btnSendFile.setBounds(157, 214, 89, 23);
		add(btnSendFile);
		
	}
	public byte[] read(File file) throws IOException {
	    if (file.length() > MAX_FILE_SIZE) {
	        System.out.println("error");
	    }

	    byte[] buffer = new byte[(int) file.length()];
	    InputStream ios = null;
	    try {
	        ios = new FileInputStream(file);
	        if (ios.read(buffer) == -1) {
	            throw new IOException(
	                    "EOF reached while trying to read the whole file");
	        }
	    } finally {
	        try {
	            if (ios != null)
	                ios.close();
	        } catch (IOException e) {
	        }
	    }
	    return buffer;
	}
	public static void showerrdilog(String string) {
		JOptionPane.showMessageDialog(null, string,"Invalid Input",JOptionPane.ERROR_MESSAGE);
	} 

	public static void successadd(String string) {
	JOptionPane.showMessageDialog(null, string,"Success",JOptionPane.PLAIN_MESSAGE);
	}
}
