package Teacher;

import java.awt.Color;

import javax.swing.JPanel;

public class ChangingReq extends JPanel {

	/**
	 * Create the panel.
	 */
	public ChangingReq() {
		setBackground(Color.WHITE);
		setBounds(10, 59, 500, 350);
		setLayout(null);
	}

}
