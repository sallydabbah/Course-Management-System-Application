package Teacher;

import java.awt.Color;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Arrays;

import javax.swing.JPanel;

import OurMessage.Message;
import OurMessage.QTypes;
import chat.Client;

import javax.swing.JFileChooser;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Choice;
import javax.swing.JButton;
import upload.*;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class TeacherUploadMat extends JPanel {
   public Choice choice2 = new Choice();
   public JFilePicker filePicker;
   static int MAX_FILE_SIZE=16777215;
	/**
	 * Create the panel.
	 */
	public TeacherUploadMat() {
		setBackground(Color.WHITE);
		setBounds(10, 59, 500, 350);
		setLayout(null);
		
		filePicker = new JFilePicker("Choose a file", "Browse...");
		filePicker.setBounds(-91, 102, 591, 52);
		filePicker.setMode(JFilePicker.MODE_SAVE);
		filePicker.addFileTypeFilter(".pdf", "PDF");
		filePicker.addFileTypeFilter(".doc", "Word File");
		filePicker.addFileTypeFilter(".docx", "Word File");
		filePicker.addFileTypeFilter(".xlsx", "excel File");
		filePicker.addFileTypeFilter(".xls", "excel File");
		filePicker.addFileTypeFilter(".jpg", "jpg File");
		JFileChooser fileChooser = filePicker.getFileChooser();
        fileChooser.setCurrentDirectory(new File("C:/"));
		
		add(filePicker);
		
		JLabel lblUploadMatrial = new JLabel("Upload Materials");
		lblUploadMatrial.setBounds(189, 24, 138, 14);
		add(lblUploadMatrial);
		
		JLabel lblClass = new JLabel("Course:");
		lblClass.setBounds(10, 58, 46, 14);
		add(lblClass);
		
		
		choice2.setBounds(62, 58, 138, 20);
		add(choice2);
		
		JButton btnUpload2 = new JButton("Upload");
		btnUpload2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String m = choice2.getSelectedItem();
				m= m.substring(m.length()-6, m.length()-1);
				//System.out.print(m);
				String filePath=filePicker.getSelectedFilePath();
				if(filePath.equals(""))
				{
					showerrdilog("You Need to but a file assigment");
					
				}
				else
				{
					if(filePath.endsWith(".doc") || filePath.endsWith(".docx") || filePath.endsWith(".xls")  || filePath.endsWith(".xlsx") || filePath.endsWith(".pdf")||filePath.endsWith(".jpg"))
					{
						filePath=filePath.replace("\\", "/");
						try {
							byte[] myfile = read(new File(filePath));
							String message=Arrays.toString(myfile);
							String fname = filePath.substring(filePath.lastIndexOf('/') +1, filePath.length());
							//System.out.print(f);
							Client.client.handleMessageFromClientUI(new Message(message,"INSERT INTO materials (Course_id,sem_id,teacher_id,mat_file,mat_fname) VALUES ('" +m+ "'"
									+ ","+ Client.client.opnedsem + ", '"+Client.client.user.getID() +"' , ? , '"+fname+"')",QTypes.uploadmat));
						} catch (IOException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						}
						
					}
					else
					{
						showerrdilog("Your File type is not Supported !!");
					}
				}
			}
		});
		btnUpload2.setBounds(189, 226, 89, 23);
		add(btnUpload2);
	}
	public byte[] read(File file) throws IOException {
	    if (file.length() > MAX_FILE_SIZE) {
	        System.out.println("error");
	    }

	    byte[] buffer = new byte[(int) file.length()];
	    InputStream ios = null;
	    try {
	        ios = new FileInputStream(file);
	        if (ios.read(buffer) == -1) {
	            throw new IOException(
	                    "EOF reached while trying to read the whole file");
	        }
	    } finally {
	        try {
	            if (ios != null)
	                ios.close();
	        } catch (IOException e) {
	        }
	    }
	    return buffer;
	}
	public static void showerrdilog(String string) {
		JOptionPane.showMessageDialog(null, string,"Invalid Input",JOptionPane.ERROR_MESSAGE);
	} 

	public static void successadd(String string) {
	JOptionPane.showMessageDialog(null, string,"Success",JOptionPane.PLAIN_MESSAGE);
	}
}
