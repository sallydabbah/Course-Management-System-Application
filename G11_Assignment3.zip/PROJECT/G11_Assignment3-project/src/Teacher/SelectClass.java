package Teacher;

import java.awt.Color;

import javax.swing.JPanel;

import OurMessage.Message;
import OurMessage.QTypes;
import User.HomeUI;
import chat.Client;

import javax.swing.JLabel;
import javax.swing.JComboBox;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
/**
 * this class for select class that belongs to the teacher and for choosing the student to download student assignment and set a grade 
 * @author A-Ar1
 *
 */
public class SelectClass extends JPanel {
  public JComboBox combo_Class = new JComboBox();
  public String value_Class;
  public String value_Course;
  //public String 
	/**
	 * Create the panel.
	 */
	public SelectClass() {
		setBackground(Color.WHITE);
		setBounds(10, 59, 500, 350);
		setLayout(null);
		
		JLabel lblSelectClass = new JLabel("Select Class:");
		lblSelectClass.setBounds(37, 77, 81, 14);
		add(lblSelectClass);
		
		
		combo_Class.setBounds(115, 74, 90, 20);
		add(combo_Class);
		
		JButton btnNext = new JButton("Next");
		btnNext.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent arg0) {
			value_Class = combo_Class.getSelectedItem().toString();	
			System.out.println(value_Class);
			
			Client.client.handleMessageFromClientUI(new Message("SELECT student_id FROM class_students WHERE  class_id='"+value_Class+"' AND sem_id="+ Client.client.opnedsem+";",QTypes.SelectStudent));
			
				
				
				
				
				
			}
		});
		btnNext.setBounds(265, 174, 89, 23);
		add(btnNext);
		
		JButton btnBack = new JButton("Back");
		btnBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				((TeacherHomeUI)((HomeUI)Client.client.clientGUI).innerpanel).contentPane.remove(((TeacherHomeUI)((HomeUI)Client.client.clientGUI).innerpanel).innerpanel);
				((SelectClass)((TeacherHomeUI)((HomeUI)Client.client.clientGUI).innerpanel).innerpanel).removeAll();
				((TeacherHomeUI)((HomeUI)Client.client.clientGUI).innerpanel).innerpanel = new SelectCourse();
				((TeacherHomeUI)((HomeUI)Client.client.clientGUI).innerpanel).contentPane.add(((TeacherHomeUI)((HomeUI)Client.client.clientGUI).innerpanel).innerpanel);
				Client.client.handleMessageFromClientUI(new Message("SELECT  distinct* FROM class_schedule WHERE teacher_id="+Client.client.user.getID()+" AND sem_id="+ Client.client.opnedsem+" group by course_id",QTypes.Selectcourse));
				((TeacherHomeUI)((HomeUI)Client.client.clientGUI).innerpanel).resizeteacherhome();
			}
		});
		btnBack.setBounds(103, 174, 89, 23);
		add(btnBack);
		
	}

}
