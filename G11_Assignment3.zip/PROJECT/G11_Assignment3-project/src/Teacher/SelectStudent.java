package Teacher;

import java.awt.Color;

import javax.swing.JPanel;

import OurMessage.Message;
import OurMessage.QTypes;
import User.HomeUI;
import chat.Client;

import javax.swing.JLabel;
import javax.swing.JComboBox;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
/**
 * the class to for choosing student that which associated to the techer 
 * @author A-Ar1
 *
 */
public class SelectStudent extends JPanel {
    public JComboBox combo_student = new JComboBox();
    public  JButton btnNextStu = new JButton("Next");
    public JButton btnBackStu = new JButton("Back");
    public String  value_student;
    public String value_course;
	/**
	 * Create the panel.
	 */
	public SelectStudent() {
		setBackground(Color.WHITE);
		setBounds(10, 59, 500, 350);
		setLayout(null);
		
		JLabel lblSelectStudent = new JLabel("Select Student :");
		lblSelectStudent.setBounds(22, 21, 105, 14);
		add(lblSelectStudent);
		
		
		combo_student.setBounds(137, 18, 105, 20);
		add(combo_student);
		
		
		btnNextStu.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				value_student = combo_student.getSelectedItem().toString();	
				System.out.println(value_student);
				System.out.println(value_course);
				Client.client.handleMessageFromClientUI(new Message("SELECT idAssigment FROM assigment WHERE  Course='"+value_course+"'  AND sem_id="+ Client.client.opnedsem+";",QTypes.SelectAssigment2));
			
			}
		});
		btnNextStu.setBounds(261, 150, 89, 23);
		add(btnNextStu);
		btnBackStu.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
			}
		});
		
		
		btnBackStu.setBounds(94, 150, 89, 23);
		add(btnBackStu);
	}

}
