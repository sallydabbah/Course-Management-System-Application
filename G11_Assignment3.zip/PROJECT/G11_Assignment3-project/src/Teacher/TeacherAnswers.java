package Teacher;

import java.awt.Color;

import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.Choice;
import javax.swing.JComboBox;

public class TeacherAnswers extends JPanel {
	private JTextField textField;
	public JLabel lblUpdateGrades = new JLabel("Update Grades");
	public JLabel lblCourse = new JLabel("Course :");
	public JLabel lblClass = new JLabel("Class :");
	public JLabel lblstu = new JLabel("Student:");
	public JLabel lblGrade = new JLabel("Grade :");
	public Choice choice_class = new Choice();
	public Choice choice_student = new Choice();
	public Choice choice_Ass = new Choice();
	public  JComboBox combo_course = new JComboBox();
	/**
	 * Create the panel.
	 */
	public TeacherAnswers() {
		setBackground(Color.WHITE);
		setBounds(10, 59, 500, 350);
		setLayout(null);
		
		
		
		lblUpdateGrades.setBounds(198, 11, 97, 14);
		add(lblUpdateGrades);
		lblCourse.setBounds(10, 51, 46, 14);
		add(lblCourse);
		lblClass.setBounds(162, 51, 46, 14);
		add(lblClass);
		lblstu.setBounds(329, 51, 46, 14);
		add(lblstu);
		textField = new JTextField();
		textField.setBounds(103, 202, 86, 20);
		add(textField);
		textField.setColumns(10);
		lblGrade.setBounds(47, 205, 46, 14);
		add(lblGrade);
		JButton btnSave = new JButton("Save");
		btnSave.setBounds(47, 279, 89, 23);
		add(btnSave);
		JButton btnBack = new JButton("Back");
		btnBack.setBounds(258, 279, 89, 23);
		add(btnBack);
		choice_class.setBounds(198, 51, 73, 20);
		add(choice_class);
		choice_student.setBounds(378, 51, 73, 20);
		add(choice_student);
		JLabel lblAssigment = new JLabel("Assigment :");
		lblAssigment.setBounds(10, 101, 62, 14);
		add(lblAssigment);
		choice_Ass.setBounds(65, 101, 71, 20);
		add(choice_Ass);
		
	
		combo_course.setBounds(63, 48, 73, 20);
		add(combo_course);
	}
}
