package Teacher;

import java.awt.Color;

import javax.swing.JPanel;

import OurMessage.Message;
import OurMessage.QTypes;
import User.HomeUI;
import chat.Client;

import javax.swing.JLabel;
import javax.swing.JComboBox;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
/**
 * this class for open jpanel to choose course to show student  uploaded assignment 
 * @author A-Ar1
 *
 */
public class SelectCourse extends JPanel {
	 public JComboBox comboBox = new JComboBox();
	 public String value_Course;
	/**
	 * Create the panel.
	 */
	public SelectCourse() {
		setBackground(Color.WHITE);
		setBounds(10, 59, 500, 350);
		setLayout(null);
		
		JLabel lblSelectCourse = new JLabel("Select Course :");
		lblSelectCourse.setBounds(21, 21, 109, 14);
		add(lblSelectCourse);
		
		
		comboBox.setBounds(189, 18, 102, 20);
		comboBox.setSelectedItem(comboBox.getItemAt(0));
		add(comboBox);
		
		
		JButton btnNext = new JButton("Next");
		btnNext.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				((TeacherHomeUI)((HomeUI)Client.client.clientGUI).innerpanel).contentPane.remove(((TeacherHomeUI)((HomeUI)Client.client.clientGUI).innerpanel).innerpanel);
				((SelectCourse)((TeacherHomeUI)((HomeUI)Client.client.clientGUI).innerpanel).innerpanel).removeAll();
				((TeacherHomeUI)((HomeUI)Client.client.clientGUI).innerpanel).innerpanel = new SelectClass();
				((TeacherHomeUI)((HomeUI)Client.client.clientGUI).innerpanel).contentPane.add(((TeacherHomeUI)((HomeUI)Client.client.clientGUI).innerpanel).innerpanel);
				((SelectClass)((TeacherHomeUI)((HomeUI)Client.client.clientGUI).innerpanel).innerpanel).value_Course=comboBox.getSelectedItem().toString();
				((TeacherHomeUI)((HomeUI)Client.client.clientGUI).innerpanel).resizeteacherhome();
				value_Course = comboBox.getSelectedItem().toString();
				Client.client.handleMessageFromClientUI(new Message("SELECT class_id FROM class_schedule WHERE teacher_id="+Client.client.user.getID()+" AND course_id="+value_Course+" AND sem_id="+ Client.client.opnedsem,QTypes.SelectClass));
				
			}
		});
		btnNext.setBounds(243, 245, 89, 23);
		add(btnNext);
	}

}
