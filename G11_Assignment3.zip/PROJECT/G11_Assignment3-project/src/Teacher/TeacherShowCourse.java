package Teacher;

import java.awt.Color;

import javax.swing.JPanel;

public class TeacherShowCourse extends JPanel {

	/**
	 * Create the panel.
	 */
	public TeacherShowCourse() {
		setBackground(Color.WHITE);
		setBounds(10, 59, 500, 350);
		setLayout(null);
	}

}
