package chat;

import java.awt.Color;
import java.awt.Desktop;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.Array;
import java.net.URL;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.HashMap;
import java.awt.Color;

import javax.swing.DefaultListModel;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;
import javax.swing.table.TableModel;

import com.mysql.jdbc.ResultSet;
import Teacher.*;
import ocsf.client.AbstractClient;
import Entities.ClassRoomSchdule;
import Entities.ClassRoomStudent;
import Entities.Course;
import Entities.Semester;
import Entities.StudentName;
import Entities.TeachUnit;
import Entities.TeacherHours;
import Entities.TeacherName;
import Entities.TeacherTU;
import Entities.User;
import Entities.uploadFile;
import OurMessage.*;
import Parent.*;
import User.HomeUI;
import sysAdmin.*;
import User.LoginUI;
import Secretary.*;
import Student.*;
import SchoolAdmin.*;
import User.GetInfo;

//import common.Sys;
/**
 * Client class represents as the user who sends the message to the server and
 * gets the message from the server.
 * 
 * @author 
 *
 */
public class Client extends AbstractClient {

	//Sys clientUI;

	public static JFrame clientGUI;
	public static Client client;
    public static User user;
    public static String opnedsem = "";
    //Get more entities
    public static JPanel userMenu;
    public static JPanel selectedMenu;
	/**
	 * Constructor for creating the client.
	 * 
	 * @param host
	 *            is the host of the server used to connecting to the server.
	 * @param port
	 *            is the port used
	 */
    public Client (String host, int port){
    	super(host, port);
    }
	public Client (String host, int port, JFrame m) throws IOException  {
        super(host, port); //Call the superclass constructor
        //this.id = ID;
        //this.clientUI = clientUI;
        this.clientGUI = m;
       /*try {
            openConnection();
        } catch (IOException e) {
            System.out.println("Error: Can't setup connection! Awaiting command");
            return;
        }
       /*
        try {
            sendToServer("#login " + "id");
        } catch (IOException e) {
            clientUI.display("An error occurred.  Terminating client.");
            quit();
        }
        */
		
	}
	
	public void quit() {
        try {
            closeConnection();
        } catch (IOException e) {
        }
        System.exit(0);
    }
	
	public void SetUser(User n) {
		this.user = n;
    }

	/**
	 * Handles all the different type of messages received from the server and
	 * displays on its ui.
	 * 
	 * @param msg
	 *            is the message received from the server.
	 */
	@Override
	public void handleMessageFromServer(Object msg) {
		System.out.println("I am here HMFS");
		int op = ((Request)msg).getRtype();
		System.out.println("Code: "+op);
		switch(op){
		case 2: 
			((HomeUI)Client.clientGUI).userJPanelchange(new GetInfo());	
			String name=((HomeUI)Client.clientGUI).innerpanel.getClass().getSimpleName();
			switch(name){
			case "sysAdminHomeUI":
				((GetInfo)((sysAdminHomeUI)((HomeUI)Client.clientGUI).innerpanel).innerpanel).info.setModel((TableModel)(((Request)msg).getRequest()));
				break;
			case "TeacherHomeUI":
				((GetInfo)((TeacherHomeUI)((HomeUI)Client.clientGUI).innerpanel).innerpanel).info.setModel((TableModel)(((Request)msg).getRequest()));
				break;
			case "ParentHomeUI":
				//((ParentHomeUI)((HomeUI)Client.client.clientGUI).innerpanel).contentPane.remove(((ParentHomeUI)((HomeUI)Client.client.clientGUI).innerpanel).innerpanel);
	    		//((ParentHomeUI)((HomeUI)Client.client.clientGUI).innerpanel).innerpanel = new ChangePassUI();
	    		//((ParentHomeUI)((HomeUI)Client.client.clientGUI).innerpanel).contentPane.add(((ParentHomeUI)((HomeUI)Client.client.clientGUI).innerpanel).innerpanel);
	    		//((ParentHomeUI)((HomeUI)Client.client.clientGUI).innerpanel).resizeteacherhome();

				break;
			case "SchoolHomeAdminGUI":
				((GetInfo)((SchoolHomeAdminGUI)((HomeUI)Client.clientGUI).innerpanel).tmp_panel).info.setModel((TableModel)(((Request)msg).getRequest()));
				break;
			case "SecretaryHomeUI":
				((GetInfo)Client.selectedMenu).info.setModel((TableModel)(((Request)msg).getRequest()));
				break;
			case "":break;
			}
			
			break;
		case 4:
			if(((Request)msg).getRequest() instanceof Boolean)
			{
				((HomeUI)clientGUI).logout();
			}
			else{
				//System Error
			}
			break;
		case 5://Login Case
			if(((Request)msg).getRequest() instanceof Boolean)
			{
				((LoginUI)clientGUI).lblerr.setForeground(Color.RED);
				Boolean flag = (Boolean)((Request)msg).getRequest();
				if(flag == true)
					((LoginUI)clientGUI).setstatus("Username or password is incorrect. !");
				else
					((LoginUI)clientGUI).setstatus("Your account is not Active !");
			}
			if(((Request)msg).getRequest() instanceof User)
			{ 
				User us=(User)(((Request)msg).getRequest());
				this.user=us;
				((LoginUI)clientGUI).loginsuccess(us.getAccess().getAccess());//Treat Login Case in loginsuccess function
				//clientGUI.setVisible(false);
				System.out.println("I am here Request User");
				
				
			}
			
		case 7://Login Case
			if(((Request)msg).getRequest() instanceof Boolean)
			{
				if(!(Boolean)(((Request)msg).getRequest()))
					System.out.print("There is no Opned semester");

			}
			if(((Request)msg).getRequest() instanceof Integer)
			{ 
				this.opnedsem = ((Integer)((Request)msg).getRequest()).toString();	
			}
			
			break;
			
		case 8:
			// update after click
			((SchoolHomeAdminGUI)((HomeUI)Client.clientGUI).innerpanel).button.doClick();
//			((RequestPanel)((SchoolHomeAdminGUI)((HomeUI)Client.clientGUI).innerpanel).tmp_panel).lblRequestDone.setVisible(true);
			((RequestPanel)((SchoolHomeAdminGUI)((HomeUI)Client.clientGUI).innerpanel).tmp_panel).lblRequestDone.setVisible(true);
		
			break;
		case 9:
			// get blocking requests
			((SchoolHomeAdminGUI)((HomeUI)Client.clientGUI).innerpanel).ChangeJPanel(new RequestPanel());	
			((RequestPanel)((SchoolHomeAdminGUI)((HomeUI)Client.clientGUI).innerpanel).tmp_panel).table.setModel((TableModel)(((Request)msg).getRequest()));
			((RequestPanel)((SchoolHomeAdminGUI)((HomeUI)Client.clientGUI).innerpanel).tmp_panel).tmp = ((SchoolHomeAdminGUI)((HomeUI)Client.clientGUI).innerpanel);
			break;

			
			
		case 10:
		// get registration requests
			((SchoolHomeAdminGUI)((HomeUI)Client.clientGUI).innerpanel).ChangeJPanel(new RequestPanel());	
			((RequestPanel)((SchoolHomeAdminGUI)((HomeUI)Client.clientGUI).innerpanel).tmp_panel).table.setModel((TableModel)(((Request)msg).getRequest()));
			((RequestPanel)((SchoolHomeAdminGUI)((HomeUI)Client.clientGUI).innerpanel).tmp_panel).tmp = ((SchoolHomeAdminGUI)((HomeUI)Client.clientGUI).innerpanel);
			break;
			
		case 11:
			// update 
			((SchoolHomeAdminGUI)((HomeUI)Client.clientGUI).innerpanel).button_1.doClick();
//			((SchoolHomeAdminGUI)((HomeUI)Client.clientGUI).innerpanel).ChangeJPanel(new RequestPanel());	
//			((RequestPanel)((SchoolHomeAdminGUI)((HomeUI)Client.clientGUI).innerpanel).tmp_panel).table.setModel((TableModel)(((Request)msg).getRequest()));
			break;
			
		case 12:
			
		//((ReadOnly)((SchoolHomeAdminGUI)((HomeUI)Client.clientGUI).innerpanel).Read_panel).Read_table.setModel((TableModel)(((Request)msg).getRequest()));
		
			break;
			
			
			
			
			
		case 13://get
			((SchoolHomeAdminGUI)((HomeUI)Client.clientGUI).innerpanel).ChangeJPanel(new RequestPanel());	
			((RequestPanel)((SchoolHomeAdminGUI)((HomeUI)Client.clientGUI).innerpanel).tmp_panel).table.setModel((TableModel)(((Request)msg).getRequest()));
			((RequestPanel)((SchoolHomeAdminGUI)((HomeUI)Client.clientGUI).innerpanel).tmp_panel).tmp = ((SchoolHomeAdminGUI)((HomeUI)Client.clientGUI).innerpanel);
			
			break;
			
		case 14:
			((SchoolHomeAdminGUI)((HomeUI)Client.clientGUI).innerpanel).button_2.doClick();
			break;
			
			
		case 15:
			//TableModel[] staticsTables=new TableModel[((TableModel[])(((Request)msg).getRequest())).length];
			if(((Request)msg).getRequest() instanceof TableModel[])
			{
			((SchoolHomeAdminGUI)((HomeUI)Client.clientGUI).innerpanel).remove(((SchoolHomeAdminGUI)((HomeUI)Client.clientGUI).innerpanel).tmp_panel);
			((SchoolHomeAdminGUI)((HomeUI)Client.clientGUI).innerpanel).ChangeJPanel(new ChartsPresentationUI());
			TableModel[] statistics=new TableModel[((TableModel[])(((Request)msg).getRequest())).length];
			for(int i=0;i<((TableModel[])(((Request)msg).getRequest())).length;i++){
				statistics[i]=((TableModel[])(((Request)msg).getRequest()))[i];
			}
			((ChartsPresentationUI)((SchoolHomeAdminGUI)((HomeUI)Client.clientGUI).innerpanel).tmp_panel).setGrades(statistics[2]);
			((ChartsPresentationUI)((SchoolHomeAdminGUI)((HomeUI)Client.clientGUI).innerpanel).tmp_panel).setTeachers(statistics[0]);
			((ChartsPresentationUI)((SchoolHomeAdminGUI)((HomeUI)Client.clientGUI).innerpanel).tmp_panel).setStudents(statistics[1]);
			((ChartsPresentationUI)((SchoolHomeAdminGUI)((HomeUI)Client.clientGUI).innerpanel).tmp_panel).setTeacherCMB();
			((ChartsPresentationUI)((SchoolHomeAdminGUI)((HomeUI)Client.clientGUI).innerpanel).tmp_panel).setCourseCMB();
			((ChartsPresentationUI)((SchoolHomeAdminGUI)((HomeUI)Client.clientGUI).innerpanel).tmp_panel).setClassCMB();
			((ChartsPresentationUI)((SchoolHomeAdminGUI)((HomeUI)Client.clientGUI).innerpanel).tmp_panel).setClassCoursesCMB();
			((ChartsPresentationUI)((SchoolHomeAdminGUI)((HomeUI)Client.clientGUI).innerpanel).tmp_panel).setClassTeacherCMB();
			((HomeUI)Client.clientGUI).resizeHome();
			}
			break;
			
			
			
			
		/*Secrtery */
			
			
			
			case 101:
				((SecretaryHomeUI)Client.userMenu).ChangeJPanel(new CreatingSemesterUI());
				if(((Request)msg).getRequest() == null)
				{//DB Empty
					((CreatingSemesterUI)Client.selectedMenu).setSemester();
				}
				if(((Request)msg).getRequest() instanceof Semester){
					//semester expired
					Date today=new Date();
					Semester sm=(Semester)(((Request)msg).getRequest());
					if(sm.getEndDate().before(today)){//Current Semester Closed
						((CreatingSemesterUI)Client.selectedMenu).setSemester(sm.getSemester_id(),sm.getSemesterLetter());
					}
					else{
						if(sm.getStartDate().before(today) && sm.getEndDate().after(today)){//Current Semester still on
							((CreatingSemesterUI)Client.selectedMenu).setErrSemester(0);
						}
						else{
							if(sm.getStartDate().after(today)){//The new semester haven't started yet
								((CreatingSemesterUI)Client.selectedMenu).setErrSemester(1);
							}
						}
					}
				}
				break;
				
			case 102:
					((CreatingSemesterUI)Client.selectedMenu).added((Boolean)(((Request)msg).getRequest()));
				break;
			case 103:
				if(((Request)msg).getRequest() instanceof TableModel)
				{
					((SecretaryHomeUI)Client.userMenu).ChangeJPanel(new ExceptionStudentsUI());
				((ExceptionStudentsUI)Client.selectedMenu).tblRequest.setModel((TableModel)(((Request)msg).getRequest()));
				
				}
				break;
				
			case 104:
				if((Boolean)(((Request)msg).getRequest()))
				{
					((ExceptionStudentsUI)Client.selectedMenu).success();
				}else{
					((ExceptionStudentsUI)Client.selectedMenu).failed();
				}
				break;
			case 105:
				if(((Request)msg).getRequest() instanceof TableModel[])
				{
					ArrayList<ClassRoomStudent> classes=new ArrayList<ClassRoomStudent>();
					ArrayList<StudentName> studentlist=new ArrayList<StudentName>();
					TableModel rs1=((TableModel[])(((Request)msg).getRequest()))[1];
					TableModel rs2=((TableModel[])(((Request)msg).getRequest()))[0];
					for(int i=0;i<rs1.getRowCount();i++)
					{//Setting Student List
							studentlist.add(new StudentName(Integer.parseInt(rs1.getValueAt(i, 0).toString()),rs1.getValueAt(i,1).toString()));
					}
					if(rs2!=null){
						for(int i=0;i<rs2.getRowCount();i++){//setting classes list
								classes.add(new ClassRoomStudent(rs2.getValueAt(i,0).toString(),Integer.parseInt(rs2.getValueAt(i, 1).toString())));
						}
					}
					((SecretaryHomeUI)Client.userMenu).ChangeJPanel(new AssocciateClassUI());
					((AssocciateClassUI)Client.selectedMenu).classes=classes;
					((AssocciateClassUI)Client.selectedMenu).StudentsList=studentlist;
					((AssocciateClassUI)Client.selectedMenu).getStudentsforClass();
					}else{
					
				}
				break;
			case 106:
				if((Boolean)(((Request)msg).getRequest()))
				{
					((AssocciateClassUI)Client.selectedMenu).insertionsuccess();
				}else{
					((AssocciateClassUI)Client.selectedMenu).insertionfailed();
				}
				break;
			case 107:
				if(((Request)msg).getRequest() instanceof TableModel[])
				{
					ArrayList<ClassRoomSchdule> classeschdule=new ArrayList<ClassRoomSchdule>();
					ArrayList<TeacherName> teahcerlist=new ArrayList<TeacherName>();
					ArrayList<TeachUnit> TUlist=new ArrayList<TeachUnit>();
					ArrayList<Course> courseslist=new ArrayList<Course>();
					ArrayList<TeacherHours> teacherhourlist=new ArrayList<TeacherHours>();
					ArrayList<TeacherTU> teacherTUlist=new ArrayList<TeacherTU>();

					ArrayList<String> precourses;

					TableModel[] tbls=new TableModel[((TableModel[])(((Request)msg).getRequest())).length];
					for(int i=0;i<((TableModel[])(((Request)msg).getRequest())).length;i++){
						tbls[i]=((TableModel[])(((Request)msg).getRequest()))[i];
					}
					for(int i=0;i<tbls[0].getRowCount();i++){
						classeschdule.add(new ClassRoomSchdule(tbls[0].getValueAt(i, 0).toString(),Integer.parseInt(tbls[0].getValueAt(i, 2).toString()),tbls[0].getValueAt(i, 1).toString(),Integer.parseInt(tbls[0].getValueAt(i, 3).toString())));
					}
					for(int i=0;i<tbls[1].getRowCount();i++){
						teahcerlist.add(new TeacherName(Integer.parseInt(tbls[1].getValueAt(i, 0).toString()),tbls[1].getValueAt(i, 1).toString()));
					}
					for(int i=0;i<tbls[2].getRowCount();i++){
						TUlist.add(new TeachUnit(tbls[2].getValueAt(i, 0).toString(),tbls[2].getValueAt(i, 1).toString()));
					}
					//Courses Left
					for(int i=0;i<tbls[3].getRowCount();i++){
						precourses=new ArrayList<String>();
						for(int j=0;j<tbls[4].getRowCount();j++){
							if((tbls[4].getValueAt(j, 0).toString()).equals(tbls[3].getValueAt(i, 0).toString()))
								precourses.add(new String(tbls[4].getValueAt(j, 1).toString()));
						}
						courseslist.add(new Course(tbls[3].getValueAt(i, 0).toString(),tbls[3].getValueAt(i, 1).toString(),tbls[3].getValueAt(i, 2).toString(),Float.parseFloat(tbls[3].getValueAt(i, 3).toString()),precourses.toArray(new String[precourses.size()])));
					}
					for(int i=0;i<tbls[5].getRowCount();i++){
						teacherhourlist.add(new TeacherHours(Integer.parseInt(tbls[5].getValueAt(i, 0).toString()),Float.parseFloat(tbls[5].getValueAt(i, 1).toString()),Float.parseFloat(tbls[5].getValueAt(i, 2).toString())));
					}
					for(int i=0;i<tbls[6].getRowCount();i++){
						teacherTUlist.add(new TeacherTU(Integer.parseInt(tbls[6].getValueAt(i, 0).toString()),tbls[6].getValueAt(i, 1).toString()));
					}
					((SecretaryHomeUI)Client.userMenu).ChangeJPanel(new AssocciateTeacherUI());
					((AssocciateTeacherUI)Client.selectedMenu).classeschdule=classeschdule;
					((AssocciateTeacherUI)Client.selectedMenu).courseslist=courseslist;
					((AssocciateTeacherUI)Client.selectedMenu).teahcerlist=teahcerlist;
					((AssocciateTeacherUI)Client.selectedMenu).TUlist=TUlist;
					((AssocciateTeacherUI)Client.selectedMenu).teacherhourlist=teacherhourlist;
					((AssocciateTeacherUI)Client.selectedMenu).teacherTUlist=teacherTUlist;
					((AssocciateTeacherUI)Client.selectedMenu).getTUlist();
				}
				break;
			case 108:
				if((Boolean)(((Request)msg).getRequest())){
					((AssocciateTeacherUI)Client.selectedMenu).addedsuccessfully();

				}else{
					((AssocciateTeacherUI)Client.selectedMenu).addedUnsuccessfully();

				}
				break;
			case 109:
				if(((Request)msg).getRequest() instanceof TableModel)
				{
					((SecretaryHomeUI)Client.userMenu).ChangeJPanel(new BlockingParentRUI());
				((BlockingParentRUI)Client.selectedMenu).tblRequest.setModel((TableModel)(((Request)msg).getRequest()));
				
				}
				break;
			case 110:
				if((Boolean)(((Request)msg).getRequest()))
				{
					((BlockingParentRUI)Client.selectedMenu).success();
				}else{
					((BlockingParentRUI)Client.selectedMenu).failed();
				}
				break;
			case 111:
				if(((Request)msg).getRequest() instanceof Integer)
				{
					Client.client.handleMessageFromClientUI(new Message("SELECT course_id,teacher_id,sem_id FROM class_schedule where class_id=(select class_id from class_students where student_id="+(Integer)(((Request)msg).getRequest())+");",QTypes.getAllInfoChild));
				}
				break;
			case 112:
				if(((Request)msg).getRequest() instanceof TableModel)
				{
					((HomeUI)Client.clientGUI).innerpanel=new ParentHomeUI();
		            ((HomeUI)Client.clientGUI).contentPane.add(((HomeUI)Client.clientGUI).innerpanel);
		            ((ParentHomeUI)((HomeUI)Client.clientGUI).innerpanel).tblStudent.setModel((TableModel)(((Request)msg).getRequest()));
				
				}
				break;
			
			
			
		/*Secrtery */
			
			
			
		case 300:
			if(((Request)msg).getRequest() instanceof Integer)
			{
				 //     System.out.println((Integer)((Request)msg).getRequest());
					 ((BlockingParentGui)((HomeStudent)((HomeUI)clientGUI).innerpanel).panel).parent_id=((Integer)((Request)msg).getRequest());
					 //System.out.print(((BlockingParentGui)((HomeStudent)((HomeUI)clientGUI).innerpanel).panel).parent_id);
			}
			else 
			{
				 System.out.println("Error sending parent id case 300");
				
			}
			break; 
			
		case 301:// filling the course comboBox :
			if(((Request)msg).getRequest() instanceof Boolean)
			{
				if(!(Boolean)(((Request)msg).getRequest())){
					//DB is Empty
					System.out.print("empty combo");
				}
			}
			if(((Request)msg).getRequest() instanceof ArrayList<?>)
			{    ((ViewAssignmentGui)((HomeStudent)((HomeUI)clientGUI).innerpanel).panel).coursecombo.removeAllItems();
				ArrayList<Integer> m = ((ArrayList<Integer>)((Request)msg).getRequest());
				for (int i = 0; i < m.size(); i++) {
					((ViewAssignmentGui)((HomeStudent)((HomeUI)clientGUI).innerpanel).panel).coursecombo.addItem(m.get(i));; 
				}
			}
			break; 
		case 302:// filling the course comboBox :
			if(((Request)msg).getRequest() instanceof Boolean)
			{
				if(!(Boolean)(((Request)msg).getRequest())){
					//DB is Empty
					System.out.print("empty assignment combo");
				}
			}
			if(((Request)msg).getRequest() instanceof ArrayList<?>)
			{
				((ViewAssignmentGui)((HomeStudent)((HomeUI)clientGUI).innerpanel).panel).comboassignment.removeAllItems();
				ArrayList<Integer> m = ((ArrayList<Integer>)((Request)msg).getRequest());
				for (int i = 0; i < m.size(); i++) {
					((ViewAssignmentGui)((HomeStudent)((HomeUI)clientGUI).innerpanel).panel).comboassignment.addItem(m.get(i));; 
					((ViewAssignmentGui)((HomeStudent)((HomeUI)clientGUI).innerpanel).panel).repaint();
					
				}
			}
			break; 
		case 303:// filling the course comboBox :
			if(((Request)msg).getRequest() instanceof Boolean)
			{
				if(!(Boolean)(((Request)msg).getRequest())){
					//DB is Empty
					System.out.print("empty assignment combo");
				}
			}
			if(((Request)msg).getRequest() instanceof ArrayList<?>)
			{
				((DownloadAssignment)((HomeStudent)((HomeUI)clientGUI).innerpanel).panel).coursecombo.removeAllItems();
				ArrayList<String> m = ((ArrayList<String>)((Request)msg).getRequest());
				for (int i = 0; i < m.size(); i++) {
					((DownloadAssignment)((HomeStudent)((HomeUI)clientGUI).innerpanel).panel).coursecombo.addItem(m.get(i));; 
				}
			}
			break;
		case 304:// filling the course comboBox :
			if(((Request)msg).getRequest() instanceof Boolean)
			{
				if(!(Boolean)(((Request)msg).getRequest())){
					//DB is Empty
					System.out.print("empty assignment combo");
				}
			}
			if(((Request)msg).getRequest() instanceof ArrayList<?>)
			{
				((DownloadAssignment)((HomeStudent)((HomeUI)clientGUI).innerpanel).panel).assignmentcombo.removeAllItems();
				ArrayList<Integer> m = ((ArrayList<Integer>)((Request)msg).getRequest());
				for (int i = 0; i < m.size(); i++) {
					((DownloadAssignment)((HomeStudent)((HomeUI)clientGUI).innerpanel).panel).assignmentcombo.addItem(m.get(i));; 
				}
			}
			break;
			
		case 305:// filling the course comboBox for material:
			if(((Request)msg).getRequest() instanceof Boolean)
			{
				if(!(Boolean)(((Request)msg).getRequest())){
					//DB is Empty
					System.out.print("empty assignment combo");
				}
			}
			if(((Request)msg).getRequest() instanceof ArrayList<?>)
			{
				((ViewMaterialsGui)((HomeStudent)((HomeUI)clientGUI).innerpanel).panel).Coursecombo.removeAllItems();
				ArrayList<Integer> m = ((ArrayList<Integer>)((Request)msg).getRequest());
				for (int i = 0; i < m.size(); i++) {
					((ViewMaterialsGui)((HomeStudent)((HomeUI)clientGUI).innerpanel).panel).Coursecombo.addItem(m.get(i));; 
				}
			}
			break;
		case 306:// filling the course comboBox for material:
			if(((Request)msg).getRequest() instanceof Boolean)
			{
				if(!(Boolean)(((Request)msg).getRequest())){
					//DB is Empty
					System.out.print("empty assignment combo");
				}
			}
			if(((Request)msg).getRequest() instanceof ArrayList<?>)
			{
				((ViewMaterialsGui)((HomeStudent)((HomeUI)clientGUI).innerpanel).panel).MaterialCombo.removeAllItems();
				ArrayList<Integer> m = ((ArrayList<Integer>)((Request)msg).getRequest());
				for (int i = 0; i < m.size(); i++) {
					((ViewMaterialsGui)((HomeStudent)((HomeUI)clientGUI).innerpanel).panel).MaterialCombo.addItem(m.get(i));; 
				}
			}
			break;
			
		case 307:// filling the course comboBox for material:
			/*if(((Request)msg).getRequest() instanceof Boolean)
			{
				if(!(Boolean)(((Request)msg).getRequest())){
					//DB is Empty
					System.out.print("empty assignment combo");
				}
			}
			if(((Request)msg).getRequest() instanceof ArrayList<?>)
			{
				((DownloadMaterialsGui)((HomeStudent)((HomeUI)clientGUI).innerpanel).panel).coursecombo.removeAllItems();
				ArrayList<Integer> m = ((ArrayList<Integer>)((Request)msg).getRequest());
				for (int i = 0; i < m.size(); i++) {
					((DownloadMaterialsGui)((HomeStudent)((HomeUI)clientGUI).innerpanel).panel).coursecombo.addItem(m.get(i)); 
				}
			}*/
			break;
			
		case 308:
			if(((Request)msg).getRequest() instanceof uploadFile)
			{
			
			uploadFile m1 = ((uploadFile)((Request)msg).getRequest());
			
			  String message = m1.getconvert();
			  String[] byteValues = message.substring(1, message.length() - 1).split(",");
			  byte[] imgInByte = new byte[byteValues.length];
			  for (int i = 0; i < byteValues.length; i++) {
					imgInByte[i] = Byte.parseByte(byteValues[i].trim());
			  }
			  String filedown =m1.getFileName();
			  File filez=new File("src/download/"+filedown);
			  try {
				FileOutputStream fos=new FileOutputStream(filez);
				fos.write(imgInByte);
				fos.close();
				//System.out.println("anaaaaaa");
			  } catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			  } catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			  }
			  if (Desktop.isDesktopSupported()) {
				    try {
				        File myFile = new File("src/download/"+filedown);
				        Desktop.getDesktop().open(myFile);
				    } catch (IOException ex) {
				        // no application registered for PDFs
				    }
				}
			  ((DownloadMaterialsGui)((HomeStudent)((HomeUI)clientGUI).innerpanel).panel).successfileopen();
			}else{
				
				((DownloadMaterialsGui)((HomeStudent)((HomeUI)clientGUI).innerpanel).panel).setCourseCMBERR("An Error accuried!");
			}
			break;
			
		case 319:// filling the course comboBox for material:
			((HomeStudent)((HomeUI)Client.clientGUI).innerpanel).ChangeJPanel(new DownloadAssignment());
			if(((Request)msg).getRequest() instanceof Boolean){
				if((Boolean)(((Request)msg).getRequest())){
				//courses isn't associated to this class.
					((DownloadAssignment)((HomeStudent)((HomeUI)clientGUI).innerpanel).panel).setCourseCMBERR("courses isn't associated to your class.");

				}else{
					  //Student isn't associated to any Class
					((DownloadAssignment)((HomeStudent)((HomeUI)clientGUI).innerpanel).panel).setCourseCMBERR("You aren't associated to any Class");
				}
			}else if(((Request)msg).getRequest() instanceof TableModel[]){
				((DownloadAssignment)((HomeStudent)((HomeUI)clientGUI).innerpanel).panel).setCourseCMB((TableModel[]) ((Request)msg).getRequest());
			}
			/*if(((Request)msg).getRequest() instanceof Boolean)
			{
				if(!(Boolean)(((Request)msg).getRequest())){
					//DB is Empty
					System.out.print("empty assignment combo");
				}
			}
			if(((Request)msg).getRequest() instanceof ArrayList<?>)
			{
				
				ArrayList<String> m = ((ArrayList<String>)((Request)msg).getRequest());
				for(int i=0;i<m.size();i++)
				{
					Client.client.handleMessageFromClientUI(new Message("Select course_id FROM class_schedule where class_id ='"+m.get(i) +"' AND sem_id="+Client.client.opnedsem,QTypes.classandcourse));
				}
			}*/
			break;
			
		case 320:// filling the course comboBox for material:
			if(((Request)msg).getRequest() instanceof Boolean)
			{
				if(!(Boolean)(((Request)msg).getRequest())){
					//DB is Empty
					System.out.print("empty assignment combo");
				}
			}
			if(((Request)msg).getRequest() instanceof ArrayList<?>)
			{
				
				ArrayList<String> m = ((ArrayList<String>)((Request)msg).getRequest());
				for(int i=0;i<m.size();i++)
				{					
					((DownloadAssignment)((HomeStudent)((HomeUI)clientGUI).innerpanel).panel).coursecombo.addItem(m.get(i)); 
					Client.client.handleMessageFromClientUI(new Message("Select idAssigment FROM assigment where Course ="+m.get(i) +" AND sem_id="+Client.client.opnedsem,QTypes.assdownloads));
				}
			}
			break;
			
		case 321:// filling the course comboBox for material:
			if(((Request)msg).getRequest() instanceof Boolean)
			{
				if(!(Boolean)(((Request)msg).getRequest())){
					//DB is Empty
					System.out.print("empty assignment combo");
				}
			}
			if(((Request)msg).getRequest() instanceof ArrayList<?>)
			{
				
				ArrayList<Integer> m = ((ArrayList<Integer>)((Request)msg).getRequest());
				for(int i=0;i<m.size();i++)
				{					
					((DownloadAssignment)((HomeStudent)((HomeUI)clientGUI).innerpanel).panel).assignmentcombo.addItem(m.get(i)); 
				}
			}
			break;
			
		case 322:
			if(((Request)msg).getRequest() instanceof uploadFile)
			{
				
				uploadFile m1 = ((uploadFile)((Request)msg).getRequest());
				
				  String message = m1.getconvert();
				  String[] byteValues = message.substring(1, message.length() - 1).split(",");
				  byte[] imgInByte = new byte[byteValues.length];
				  for (int i = 0; i < byteValues.length; i++) {
						imgInByte[i] = Byte.parseByte(byteValues[i].trim());
				  }
				  String filedown = m1.getFileName();
				  File filez=new File("src/download/"+filedown);
				  try {
					FileOutputStream fos=new FileOutputStream(filez);
					fos.write(imgInByte);
					fos.close();
					//System.out.println("anaaaaaa");
				} catch (FileNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				  if (Desktop.isDesktopSupported()) {
					    try {
					        File myFile = new File("src/download/"+filedown);
					        Desktop.getDesktop().open(myFile);
					    } catch (IOException ex) {
					        // no application registered for PDFs
					    }
					}
			}
			break;
			
		case 323:// filling the course comboBox for material:
			((HomeStudent)((HomeUI)Client.clientGUI).innerpanel).ChangeJPanel(new DownloadMaterialsGui());
			if(((Request)msg).getRequest() instanceof Boolean){
				if((Boolean)(((Request)msg).getRequest())){
				//courses isn't associated to this class.
					((DownloadMaterialsGui)((HomeStudent)((HomeUI)clientGUI).innerpanel).panel).setCourseCMBERR("courses isn't associated to your class.");

				}else{
					  //Student isn't associated to any Class
					((DownloadMaterialsGui)((HomeStudent)((HomeUI)clientGUI).innerpanel).panel).setCourseCMBERR("You aren't associated to any Class");
				}
			}else if(((Request)msg).getRequest() instanceof TableModel[]){
				((DownloadMaterialsGui)((HomeStudent)((HomeUI)clientGUI).innerpanel).panel).setCourseCMB((TableModel[]) ((Request)msg).getRequest());
			}
			break;
			
		case 324:// filling the course comboBox for material:
			if(((Request)msg).getRequest() instanceof Boolean)
			{
				if(!(Boolean)(((Request)msg).getRequest())){
					//DB is Empty
					System.out.print("empty assignment combo");
				}
			}
			if(((Request)msg).getRequest() instanceof ArrayList<?>)
			{
				
				ArrayList<String> m = ((ArrayList<String>)((Request)msg).getRequest());
				for(int i=0;i<m.size();i++)
				{					
					((ViewMaterialsGui)((HomeStudent)((HomeUI)clientGUI).innerpanel).panel).Coursecombo.addItem(m.get(i)); 
					Client.client.handleMessageFromClientUI(new Message("Select idmaterials FROM materials where course_id ="+m.get(i) +" AND sem_id="+Client.client.opnedsem,QTypes.assdownloads1));
				}
			}
			break;
			
		case 325:// filling the course comboBox for material:
			if(((Request)msg).getRequest() instanceof Boolean)
			{
				if(!(Boolean)(((Request)msg).getRequest())){
					//DB is Empty
					System.out.print("empty assignment combo");
				}
			}
			if(((Request)msg).getRequest() instanceof ArrayList<?>)
			{
				
				ArrayList<Integer> m = ((ArrayList<Integer>)((Request)msg).getRequest());
				for(int i=0;i<m.size();i++)
				{					
					((ViewMaterialsGui)((HomeStudent)((HomeUI)clientGUI).innerpanel).panel).MaterialCombo.addItem(m.get(i)); 
				}
			}
			break;
			
		case 309:// filling the course comboBox for material:
			if(((Request)msg).getRequest() instanceof Boolean)
			{
				if(!(Boolean)(((Request)msg).getRequest())){
					//DB is Empty
					System.out.print("Error client parent id case 309");
				}
			}
			if(((Request)msg).getRequest() instanceof Integer)
			{
				((BlockingParentGui)((HomeStudent)((HomeUI)clientGUI).innerpanel).panel).parent_id=(Integer)((Request)msg).getRequest();
			}
			break;
			
			
	case 310:// 
		System.out.println("Client 310");
		if(((Request)msg).getRequest() instanceof Boolean)
		{
			if(!(Boolean)(((Request)msg).getRequest())){
				//DB is Empty
				//System.out.print("Error client parent id case 310");
				((BlockingParentGui)((HomeStudent)((HomeUI)clientGUI).innerpanel).panel).lblMsg.setText("An Error! Your Request failed to save in the server!");
				((BlockingParentGui)((HomeStudent)((HomeUI)clientGUI).innerpanel).panel).lblMsg.setForeground(Color.RED);
				((BlockingParentGui)((HomeStudent)((HomeUI)clientGUI).innerpanel).panel).lblMsg.setVisible(true);
			}
			else 
			{
				//System.out.println("Block parent succedd im client case 310");
				((BlockingParentGui)((HomeStudent)((HomeUI)clientGUI).innerpanel).panel).lblMsg.setText("Your request has been sent successfully");
				((BlockingParentGui)((HomeStudent)((HomeUI)clientGUI).innerpanel).panel).lblMsg.setForeground(Color.GRAY);
				((BlockingParentGui)((HomeStudent)((HomeUI)clientGUI).innerpanel).panel).lblMsg.setVisible(true);
			}
		}
		
		break;
		
	case 311:// getting message id number 
		if(((Request)msg).getRequest() instanceof Boolean)
		{
			if(!(Boolean)(((Request)msg).getRequest())){
				//DB is Empty
				System.out.print("Error client parent id case 311");
			}
		}
		if(((Request)msg).getRequest() instanceof Integer)
		{
			((BlockingParentGui)((HomeStudent)((HomeUI)clientGUI).innerpanel).panel).id_message=(Integer)((Request)msg).getRequest();
		}
		break;
		
	case 313:
		if(((Request)msg).getRequest() instanceof Integer)
		{
			 ((BlockingParentGui)((HomeStudent)((HomeUI)clientGUI).innerpanel).panel).exist=1;
			 ((BlockingParentGui)((HomeStudent)((HomeUI)clientGUI).innerpanel).panel).lblMsg.setText("Your request already saved");
			 ((BlockingParentGui)((HomeStudent)((HomeUI)clientGUI).innerpanel).panel).lblMsg.setForeground(Color.BLUE);
			 ((BlockingParentGui)((HomeStudent)((HomeUI)clientGUI).innerpanel).panel).lblMsg.setVisible(true);
	
		}
		else 
		{
			((BlockingParentGui)((HomeStudent)((HomeUI)clientGUI).innerpanel).panel).exist=0;
			 Message msg3=new Message("INSERT INTO request_block VALUES ('"+Client.client.user.getID()+"', '"+ ((BlockingParentGui)((HomeStudent)((HomeUI)clientGUI).innerpanel).panel).parent_id+"', 'NYD','1','0');",QTypes.blockparent2);
				Client.client.handleMessageFromClientUI(msg3);
			
		}
		/*if(((Request)msg).getRequest() instanceof Integer)
		{
			 ((BlockingParentGui)((HomeStudent)((HomeUI)clientGUI).innerpanel).panel).exist=1;
			 System.out.println(((BlockingParentGui)((HomeStudent)((HomeUI)clientGUI).innerpanel).panel).exist);
			 
		}
		else 
		{
			 System.out.println("exist equals 0");
			
		}*/
		break;
		
	case 314:
		if(((Request)msg).getRequest() instanceof String)
		{
			((HomeStudent)((HomeUI)Client.clientGUI).innerpanel).ChangeJPanel(new SendRequest());
			((SendRequest)((HomeStudent)((HomeUI)clientGUI).innerpanel).panel).setclassFrom((String)((Request)msg).getRequest());
		}
		else 
		{
			 System.out.println("Error sending class id client 314");
			
		}
		break; 
	case 315:
		if(((Request)msg).getRequest() instanceof Boolean)
		{
			if(!(Boolean)(((Request)msg).getRequest())){
				//DB is Empty
				System.out.print("empty class combo");
			}
		}
		if(((Request)msg).getRequest() instanceof ArrayList<?>)
		{
			((SendRequest)((HomeStudent)((HomeUI)clientGUI).innerpanel).panel).comboBox.removeAllItems();
			ArrayList<String> m = ((ArrayList<String>)((Request)msg).getRequest());
			for (int i = 0; i < m.size(); i++) {
				((SendRequest)((HomeStudent)((HomeUI)clientGUI).innerpanel).panel).comboBox.addItem(m.get(i));; 
			}
		}
		break; 
	case 316:
		if(((Request)msg).getRequest() instanceof Integer)
		{
			 //     System.out.println((Integer)((Request)msg).getRequest());
				 ((SendRequest)((HomeStudent)((HomeUI)clientGUI).innerpanel).panel).requestnum=((Integer)((Request)msg).getRequest());
				 ((SendRequest)((HomeStudent)((HomeUI)clientGUI).innerpanel).panel).requestnum++; 
				 System.out.println("Request max : ");
				 System.out.println(((SendRequest)((HomeStudent)((HomeUI)clientGUI).innerpanel).panel).requestnum);
		}
		else 
		{
			 System.out.println("Error sending request max num case 316");
			
		}
		break;
	
	case 317:
		if(((Request)msg).getRequest() instanceof Boolean)
		{
			if(!(Boolean)(((Request)msg).getRequest())){
				//DB is Empty
				System.out.print("Error client 317 saving request ");
			}
			else 
			{
				System.out.println("request update succedd im client case 317");
				((SendRequest)((HomeStudent)((HomeUI)clientGUI).innerpanel).panel).lblMsg.setText("Your request has been sent successfully");
				((SendRequest)((HomeStudent)((HomeUI)clientGUI).innerpanel).panel).lblMsg.setForeground(Color.GRAY);
				((SendRequest)((HomeStudent)((HomeUI)clientGUI).innerpanel).panel).lblMsg.setVisible(true);
			}
		}
		break;
	case 318:
		if(((Request)msg).getRequest() instanceof Integer){
			((SendRequest)((HomeStudent)((HomeUI)clientGUI).innerpanel).panel).insertunSuc(0);
		}else{
			if((Boolean)((Request)msg).getRequest())
			{
				((SendRequest)((HomeStudent)((HomeUI)clientGUI).innerpanel).panel).insretSuc();
			}
			else 
			{  
				((SendRequest)((HomeStudent)((HomeUI)clientGUI).innerpanel).panel).insertunSuc(1);

			}
		}
		break; 
			
	case 326:
		if((Boolean)(((Request)msg).getRequest())){
			((UploadAssignment)((HomeStudent)((HomeUI)clientGUI).innerpanel).panel).successadd("The File been Submited Successfully!");
		}else{
			((UploadAssignment)((HomeStudent)((HomeUI)clientGUI).innerpanel).panel).showerrdilog("The File been Already Submited!");
		}
		break;
	case 327:
		((HomeStudent)((HomeUI)Client.clientGUI).innerpanel).ChangeJPanel(new UploadAssignment());
		if(((Request)msg).getRequest() instanceof Boolean){
			if((Boolean)(((Request)msg).getRequest())){
			//courses isn't associated to this class.
				((UploadAssignment)((HomeStudent)((HomeUI)clientGUI).innerpanel).panel).setCourseCMBERR("courses isn't associated to your class.");

			}else{
				  //Student isn't associated to any Class
				((UploadAssignment)((HomeStudent)((HomeUI)clientGUI).innerpanel).panel).setCourseCMBERR("You aren't associated to any Class");
			}
		}else if(((Request)msg).getRequest() instanceof TableModel[]){
			((UploadAssignment)((HomeStudent)((HomeUI)clientGUI).innerpanel).panel).setCourseCMB((TableModel[]) ((Request)msg).getRequest());
		}
		break;
/* Sys Admin */
			
		case 200:
			if(((Request)msg).getRequest() instanceof Boolean)
			{
				if(!(Boolean)(((Request)msg).getRequest())){
					//DB is Empty
					System.out.print("empty");
				}
			}
			if(((Request)msg).getRequest() instanceof ArrayList<?>)
			{
				if(((ArrayList<?>)((Request)msg).getRequest()).get(0) instanceof TeachUnit)
				{
					ArrayList<TeachUnit> m = ((ArrayList<TeachUnit>)((Request)msg).getRequest());
					for (int i = 0; i < m.size(); i++) {
						((AddCourseUI)((sysAdminHomeUI)((HomeUI)clientGUI).innerpanel).innerpanel).teacunit_choice.add(m.get(i).getTeachUnit_Name() + " '" + m.get(i).getTeachUnit_ID() +"'");
					}
					((AddCourseUI)((sysAdminHomeUI)((HomeUI)clientGUI).innerpanel).innerpanel).txtfirstid.setText(m.get(0).getTeachUnit_ID());
				}
			}
			break;
			
		case 201:
			if(((Request)msg).getRequest() instanceof Boolean)
			{
				if(!(Boolean)(((Request)msg).getRequest())){
					//DB is Empty
					System.out.print("empty");
				}
			}
			if(((Request)msg).getRequest() instanceof ArrayList<?>)
			{
				if(((ArrayList<?>)((Request)msg).getRequest()).get(0) instanceof String)
				{
					ArrayList<String> m = ((ArrayList<String>)((Request)msg).getRequest());
					DefaultListModel lmdlEjemplo=new DefaultListModel();
					for (int i = 0; i < m.size(); i++)
						lmdlEjemplo.addElement(m.get(i));
					((AddCourseUI)((sysAdminHomeUI)((HomeUI)clientGUI).innerpanel).innerpanel).list1.setModel(lmdlEjemplo);
					
					//JCheckBox[] myList;
					
					/*DefaultListModel model = ((DefaultListModel)((AddCourseUI)((sysAdminHomeUI)((HomeUI)clientGUI).innerpanel).innerpanel).list1.getModel());
					
					for (int i = 0; i < m.size(); i++)
					{
						model.addElement(new CheckBoxListEntry(m.get(i),false));
					}
					((AddCourseUI)((sysAdminHomeUI)((HomeUI)clientGUI).innerpanel).innerpanel).list1.setModel(model);
					//((AddCourseUI)((sysAdminHomeUI)((HomeUI)clientGUI).innerpanel).innerpanel).txtfirstid.setText(m.get(0).getTeachUnit_ID());
					 * 
					 */
				}
			}
			break;
			
		case 202:
			if(((Request)msg).getRequest() instanceof Boolean)
			{
				if(!(Boolean)(((Request)msg).getRequest())){
					//DB is Empty
					((AddCourseUI)((sysAdminHomeUI)((HomeUI)clientGUI).innerpanel).innerpanel).showerrdilog("The Course id is not available");
				}
			}
			if(((Request)msg).getRequest() instanceof String)
			{
				
				((AddCourseUI)((sysAdminHomeUI)((HomeUI)clientGUI).innerpanel).innerpanel).list1.addCheckBoxListSelectedValue(((Request)msg).getRequest(), false);
				//((AddCourseUI)((sysAdminHomeUI)((HomeUI)clientGUI).innerpanel).innerpanel).list1.updateUI();
					
			}
			break;
			
		case 203:
			if(((Request)msg).getRequest() instanceof Boolean)
			{
				if(!(Boolean)(((Request)msg).getRequest()))
					((AddCourseUI)((sysAdminHomeUI)((HomeUI)clientGUI).innerpanel).innerpanel).showerrdilog("The course id is already exists in DataBase !");
				else
				{
					((AddCourseUI)((sysAdminHomeUI)((HomeUI)clientGUI).innerpanel).innerpanel).successadd("The Course has been added Successfully");
					((sysAdminHomeUI)((HomeUI)clientGUI).innerpanel).contentPane.remove(((sysAdminHomeUI)((HomeUI)clientGUI).innerpanel).innerpanel);
					((AddCourseUI)((sysAdminHomeUI)((HomeUI)clientGUI).innerpanel).innerpanel).removeAll();
					((sysAdminHomeUI)((HomeUI)clientGUI).innerpanel).innerpanel = new AddCourseUI();
					((sysAdminHomeUI)((HomeUI)clientGUI).innerpanel).contentPane.remove(((sysAdminHomeUI)((HomeUI)clientGUI).innerpanel).innerpanel);
					((sysAdminHomeUI)((HomeUI)clientGUI).innerpanel).contentPane.add(((sysAdminHomeUI)((HomeUI)clientGUI).innerpanel).innerpanel);
					Client.client.handleMessageFromClientUI(new Message("SELECT * FROM teaching_unit",QTypes.GetTeachunits));
	    			Client.client.handleMessageFromClientUI(new Message("SELECT course_id, course_name FROM courses",QTypes.GetAllCoursesids));
	    			((sysAdminHomeUI)((HomeUI)clientGUI).innerpanel).resizesysAdminHome();
				}
			}
			break;
			
		case 204:
			if(((Request)msg).getRequest() instanceof Boolean)
			{
				if(!(Boolean)(((Request)msg).getRequest()))
					((AddCourseUI)((sysAdminHomeUI)((HomeUI)clientGUI).innerpanel).innerpanel).showerrdilog("There is something wrong happened with Database");
				/*else
				{
					((AddCourseUI)((sysAdminHomeUI)((HomeUI)clientGUI).innerpanel).innerpanel).successadd("The Course has been added Successfully");
					((sysAdminHomeUI)((HomeUI)clientGUI).innerpanel).contentPane.remove(((sysAdminHomeUI)((HomeUI)clientGUI).innerpanel).innerpanel);
					((sysAdminHomeUI)((HomeUI)clientGUI).innerpanel).contentPane.add(((sysAdminHomeUI)((HomeUI)clientGUI).innerpanel).innerpanel);
					Client.client.handleMessageFromClientUI(new Message("SELECT * FROM teaching_unit",QTypes.GetTeachunits));
	    			Client.client.handleMessageFromClientUI(new Message("SELECT course_id, course_name FROM courses",QTypes.GetAllCoursesids));
	    			((sysAdminHomeUI)((HomeUI)clientGUI).innerpanel).resizesysAdminHome();
				}*/
			}
			break;
			
		case 206:
			if(((Request)msg).getRequest() instanceof Boolean)
			{
				if(!(Boolean)(((Request)msg).getRequest()))
					System.out.print("medo");
			}
			if(((Request)msg).getRequest() instanceof ArrayList<?>)
			{
				if(((ArrayList<?>)((Request)msg).getRequest()).get(0) instanceof Course)
				{
					((ShowAllCoursesFieldsUI)((sysAdminHomeUI)((HomeUI)clientGUI).innerpanel).innerpanel).allcourses = ((ArrayList<Course>)((Request)msg).getRequest()) ;
					//((ShowAllCoursesFieldsUI)((sysAdminHomeUI)((HomeUI)clientGUI).innerpanel).innerpanel).index = 0;
					((ShowAllCoursesFieldsUI)((sysAdminHomeUI)((HomeUI)clientGUI).innerpanel).innerpanel).StartmyUI( ((ShowAllCoursesFieldsUI)((sysAdminHomeUI)((HomeUI)clientGUI).innerpanel).innerpanel).allcourses);
				}
			}
			
			break;
			
			
		case 207:
			if(((Request)msg).getRequest() instanceof Boolean)
			{
				if(!(Boolean)(((Request)msg).getRequest())){
					//DB is Empty
					((EditCourseUI)((sysAdminHomeUI)((HomeUI)clientGUI).innerpanel).innerpanel).lblstatus.setVisible(true);
				}
			}
			if(((Request)msg).getRequest() instanceof ArrayList<?>)
			{
				if(((ArrayList<?>)((Request)msg).getRequest()).get(0) instanceof String)
				{
					((EditCourseUI)((sysAdminHomeUI)((HomeUI)clientGUI).innerpanel).innerpanel).btnnext.setVisible(true);
					ArrayList<String> m = ((ArrayList<String>)((Request)msg).getRequest());
					DefaultListModel lmdlEjemplo=new DefaultListModel();
					for (int i = 0; i < m.size(); i++)
						lmdlEjemplo.addElement(m.get(i));
					((EditCourseUI)((sysAdminHomeUI)((HomeUI)clientGUI).innerpanel).innerpanel).list1.setModel(lmdlEjemplo);
				}
			}
			break;
			
		case 208:
			if(((Request)msg).getRequest() instanceof Boolean)
			{
				if(!(Boolean)(((Request)msg).getRequest())){
					//DB is Empty
					((EditCourseUI)((sysAdminHomeUI)((HomeUI)clientGUI).innerpanel).innerpanel).showerrdilog("The Course id is not available");
				}
			}
			if(((Request)msg).getRequest() instanceof String)
			{
				
				((EditCourseUI)((sysAdminHomeUI)((HomeUI)clientGUI).innerpanel).innerpanel).list1.addCheckBoxListSelectedValue(((Request)msg).getRequest(), false);
				((EditCourseUI)((sysAdminHomeUI)((HomeUI)clientGUI).innerpanel).innerpanel).list1.updateUI();
					
			}
			break;
			
			
		case 209:
			if(((Request)msg).getRequest() instanceof Boolean)
			{
				if(!(Boolean)(((Request)msg).getRequest()))
					System.out.print("medo");
			}
			if(((Request)msg).getRequest() instanceof Course)
			{

					((EditCourseNextUI)((sysAdminHomeUI)((HomeUI)clientGUI).innerpanel).innerpanel).coursesedit.add( (Course)(((Request)msg).getRequest()) ) ;
					if (   ((EditCourseNextUI)((sysAdminHomeUI)((HomeUI)clientGUI).innerpanel).innerpanel).coursesedit.size() == ((EditCourseNextUI)((sysAdminHomeUI)((HomeUI)clientGUI).innerpanel).innerpanel).size  )
					{
						//((ShowAllCoursesFieldsUI)((sysAdminHomeUI)((HomeUI)clientGUI).innerpanel).innerpanel).index = 0;
						((EditCourseNextUI)((sysAdminHomeUI)((HomeUI)clientGUI).innerpanel).innerpanel).StartmyUI();
					}
			}
			
			break;
			
			
		case 210:
			if(((Request)msg).getRequest() instanceof Boolean)
			{
				if(!(Boolean)(((Request)msg).getRequest())){
					//DB is Empty
					System.out.print("empty");
				}
			}
			if(((Request)msg).getRequest() instanceof ArrayList<?>)
			{
				if(((ArrayList<?>)((Request)msg).getRequest()).get(0) instanceof TeachUnit)
				{
					ArrayList<TeachUnit> m = ((ArrayList<TeachUnit>)((Request)msg).getRequest());
					((EditCourseNextUI)((sysAdminHomeUI)((HomeUI)clientGUI).innerpanel).innerpanel).TU = ((ArrayList<TeachUnit>)((Request)msg).getRequest());
					for (int i = 0; i < m.size(); i++) {
						((EditCourseNextUI)((sysAdminHomeUI)((HomeUI)clientGUI).innerpanel).innerpanel).teacunit_choice.add(m.get(i).getTeachUnit_Name() + " '" + m.get(i).getTeachUnit_ID() +"'");
					}
					//((EditCourseNextUI)((sysAdminHomeUI)((HomeUI)clientGUI).innerpanel).innerpanel).txtfirstid.setText(m.get(0).getTeachUnit_ID());
				}
			}
			break;
			
			
		case 211:
			if(((Request)msg).getRequest() instanceof Boolean)
			{
				if(!(Boolean)(((Request)msg).getRequest())){
					//DB is Empty
					System.out.print("empty");
				}
			}
			if(((Request)msg).getRequest() instanceof ArrayList<?>)
			{
				if(((ArrayList<?>)((Request)msg).getRequest()).get(0) instanceof String)
				{
					ArrayList<String> m = ((ArrayList<String>)((Request)msg).getRequest());
					DefaultListModel lmdlEjemplo=new DefaultListModel();
					for (int i = 0; i < m.size(); i++)
						lmdlEjemplo.addElement(m.get(i));
					((EditCourseNextUI)((sysAdminHomeUI)((HomeUI)clientGUI).innerpanel).innerpanel).list1.setModel(lmdlEjemplo);
					//((EditCourseNextUI)((sysAdminHomeUI)((HomeUI)clientGUI).innerpanel).innerpanel).list1.ref
					//((EditCourseNextUI)((sysAdminHomeUI)((HomeUI)clientGUI).innerpanel).innerpanel).scrollPane.setViewportView(((EditCourseNextUI)((sysAdminHomeUI)((HomeUI)clientGUI).innerpanel).innerpanel).list1);
				}
			}
			break;
			
			
		case 212:
			if(((Request)msg).getRequest() instanceof Boolean)
			{
				if(!(Boolean)(((Request)msg).getRequest())){
					//DB is Empty
					((EditCourseNextUI)((sysAdminHomeUI)((HomeUI)clientGUI).innerpanel).innerpanel).showerrdilog("The Course id is not available");
				}
			}
			if(((Request)msg).getRequest() instanceof String)
			{
				
				((EditCourseNextUI)((sysAdminHomeUI)((HomeUI)clientGUI).innerpanel).innerpanel).list1.addCheckBoxListSelectedValue(((Request)msg).getRequest(), false);
				//((EditCourseNextUI)((sysAdminHomeUI)((HomeUI)clientGUI).innerpanel).innerpanel).list1.updateUI();
					
			}
			break;
			
		case 213:
			if(((Request)msg).getRequest() instanceof Boolean)
			{
				if(!(Boolean)(((Request)msg).getRequest()))
					((EditCourseNextUI)((sysAdminHomeUI)((HomeUI)clientGUI).innerpanel).innerpanel).showerrdilog("The course id is already exists in DataBase !");
				else
				{
					((EditCourseNextUI)((sysAdminHomeUI)((HomeUI)clientGUI).innerpanel).innerpanel).successadd("The Course has been edited Successfully");
					((EditCourseNextUI)((sysAdminHomeUI)((HomeUI)clientGUI).innerpanel).innerpanel).Removeonefromcoursesedit();
				}
			}
			break;
			
		/*case 214:
			if(((Request)msg).getRequest() instanceof Boolean)
			{
				if(!(Boolean)(((Request)msg).getRequest())){
					//DB is Empty
					((EditCourseNextUI)((sysAdminHomeUI)((HomeUI)clientGUI).innerpanel).innerpanel).showerrdilog("The Course id is not available");
				}
				else
				{
					
				}
			}
			break;
			*/
			
			
		case 215:
			if(((Request)msg).getRequest() instanceof Boolean)
			{
				if(!(Boolean)(((Request)msg).getRequest())){
					//DB is Empty
					//System.out.print("empty");
					((ShowTeachUnitUI)((sysAdminHomeUI)((HomeUI)clientGUI).innerpanel).innerpanel).lblstatus.setVisible(true);
				}
			}
			if(((Request)msg).getRequest() instanceof ArrayList<?>)
			{
				if(((ArrayList<?>)((Request)msg).getRequest()).get(0) instanceof TeachUnit)
				{
					((ShowTeachUnitUI)((sysAdminHomeUI)((HomeUI)clientGUI).innerpanel).innerpanel).TU = ((ArrayList<TeachUnit>)((Request)msg).getRequest());
					((ShowTeachUnitUI)((sysAdminHomeUI)((HomeUI)clientGUI).innerpanel).innerpanel).index = 0;
					((ShowTeachUnitUI)((sysAdminHomeUI)((HomeUI)clientGUI).innerpanel).innerpanel).startmyUI();
				}
			}
			break;
			
			/* Sys Admin */
			/// teacher
			
					case 700:
						if(((Request)msg).getRequest() instanceof Boolean)
						{
							if(!(Boolean)(((Request)msg).getRequest())){
								//DB is Empty
								System.out.print("empty");
							}
						}
						if(((Request)msg).getRequest() instanceof ArrayList<?>)
						{
							if(((ArrayList<?>)((Request)msg).getRequest()).get(0) instanceof Integer)
							{
								ArrayList<Integer> m = ((ArrayList<Integer>)((Request)msg).getRequest());
								((TeacherEnteringHours)((TeacherHomeUI)((HomeUI)clientGUI).innerpanel).innerpanel).lblchours.setText(""+m.get(1));
								((TeacherEnteringHours)((TeacherHomeUI)((HomeUI)clientGUI).innerpanel).innerpanel).maxhours = m.get(0);
							}
						}
						break;
						
					case 701:
						if(((Request)msg).getRequest() instanceof Boolean)
						{
							if(!(Boolean)(((Request)msg).getRequest())){
								//DB is Empty
								System.out.print("empty");
							}
							else
							{
								((TeacherEnteringHours)((TeacherHomeUI)((HomeUI)clientGUI).innerpanel).innerpanel).successadd("The hours has been added successfully");
								float res = Float.parseFloat(((TeacherEnteringHours)((TeacherHomeUI)((HomeUI)clientGUI).innerpanel).innerpanel).textHours.getText());
								res += Integer.parseInt(((TeacherEnteringHours)((TeacherHomeUI)((HomeUI)clientGUI).innerpanel).innerpanel).lblchours.getText());
								((TeacherEnteringHours)((TeacherHomeUI)((HomeUI)clientGUI).innerpanel).innerpanel).lblchours.setText(""+res);
								((TeacherEnteringHours)((TeacherHomeUI)((HomeUI)clientGUI).innerpanel).innerpanel).textHours.setText("");
							}
						}
						
						break;
						
					case 702:
						if(((Request)msg).getRequest() instanceof Boolean)
						{
							if(!(Boolean)(((Request)msg).getRequest())){
								//DB is Empty
								System.out.print("empty");
							}
						}
						if(((Request)msg).getRequest() instanceof ArrayList<?>)
						{
							if(((ArrayList<?>)((Request)msg).getRequest()).get(0) instanceof TeachUnit)
							{
								ArrayList<TeachUnit> m = ((ArrayList<TeachUnit>)((Request)msg).getRequest());
								for (int i = 0; i < m.size(); i++) {
									((TU_newRequest)((TeacherHomeUI)((HomeUI)clientGUI).innerpanel).innerpanel).teacunit_choice.add(m.get(i).getTeachUnit_Name() + " '" + m.get(i).getTeachUnit_ID() +"'");
								}
							}
						}
						break;
						
					case 703:
						if(((Request)msg).getRequest() instanceof Boolean)
						{
							if(!(Boolean)(((Request)msg).getRequest()))
								System.out.print("asd");
						}
						if(((Request)msg).getRequest() instanceof ArrayList<?>)
						{
							if(((ArrayList<?>)((Request)msg).getRequest()).get(0) instanceof Course)
							{
								((TeacherShowCFields)((TeacherHomeUI)((HomeUI)clientGUI).innerpanel).innerpanel).allcourses = ((ArrayList<Course>)((Request)msg).getRequest()) ;
								//((TeacherShowCFields)((TeacherHomeUI)((HomeUI)clientGUI).innerpanel).innerpanel).index = 0;
								((TeacherShowCFields)((TeacherHomeUI)((HomeUI)clientGUI).innerpanel).innerpanel).StartmyUI(((TeacherShowCFields)((TeacherHomeUI)((HomeUI)clientGUI).innerpanel).innerpanel).allcourses);
							}
						}
						
						break;
						
					case 704:
						if(((Request)msg).getRequest() instanceof TableModel)
						{
							
						//((SecretaryHomeUI)Client.userMenu).ChangeJPanel(new ExceptionStudentsUI());
							((TU_requestUI)((TeacherHomeUI)((HomeUI)clientGUI).innerpanel).innerpanel).tblTrequest.setModel((TableModel)(((Request)msg).getRequest()));
						
						}
						break;
						
					case 705:
						if(((Request)msg).getRequest() instanceof Boolean)
						{
							if(!(Boolean)(((Request)msg).getRequest())){
								//DB is Empty
								System.out.print("empty");
							}
						}
						if(((Request)msg).getRequest() instanceof ArrayList<?>)
						{
							if(((ArrayList<?>)((Request)msg).getRequest()).get(0) instanceof Course)
							{
								ArrayList<Course> m = ((ArrayList<Course>)((Request)msg).getRequest());
								for (int i = 0; i < m.size(); i++) {
									((TeacherUplaodAss)((TeacherHomeUI)((HomeUI)clientGUI).innerpanel).innerpanel).choice.add(m.get(i).getCourse_Name() + " '" + m.get(i).getCourse_ID() +"'");
									//((TeacherUploadMat)((TeacherHomeUI)((HomeUI)clientGUI).innerpanel).innerpanel).choice2.add(m.get(i).getCourse_Name() + " '" + m.get(i).getCourse_ID() +"'");
									
								}
							}
						}
						break;
					case 706:
						if(((Request)msg).getRequest() instanceof Boolean)
						{
							if(!(Boolean)(((Request)msg).getRequest())){
								//DB is Empty
								System.out.print("empty");
							}
						}
						if(((Request)msg).getRequest() instanceof ArrayList<?>)
						{
							if(((ArrayList<?>)((Request)msg).getRequest()).get(0) instanceof Course)
							{
								ArrayList<Course> m = ((ArrayList<Course>)((Request)msg).getRequest());
								for (int i = 0; i < m.size(); i++) {
									//((TeacherUplaodAss)((TeacherHomeUI)((HomeUI)clientGUI).innerpanel).innerpanel).choice.add(m.get(i).getCourse_Name() + " '" + m.get(i).getCourse_ID() +"'");
									((TeacherUploadMat)((TeacherHomeUI)((HomeUI)clientGUI).innerpanel).innerpanel).choice2.add(m.get(i).getCourse_Name() + " '" + m.get(i).getCourse_ID() +"'");
									
								}
							}
						}
						break;
						
					case 710:
						if(((Request)msg).getRequest() instanceof Boolean)
						{
							if(!(Boolean)(((Request)msg).getRequest())){
								//DB is Empty
								System.out.print("empty");
							}
						}
						if(((Request)msg).getRequest() instanceof ArrayList<?>)
						{
							if(((ArrayList<?>)((Request)msg).getRequest()).get(0) instanceof Course)
							{
								ArrayList<Course> m = ((ArrayList<Course>)((Request)msg).getRequest());
								for (int i = 0; i < m.size(); i++) {
									//((TeacherUplaodAss)((TeacherHomeUI)((HomeUI)clientGUI).innerpanel).innerpanel).choice.add(m.get(i).getCourse_Name() + " '" + m.get(i).getCourse_ID() +"'");
									((SelectCourse)((TeacherHomeUI)((HomeUI)clientGUI).innerpanel).innerpanel).comboBox.addItem(( m.get(i).getCourse_ID() ));
									
								}
							}
						}
						break;
				
					case 711:
						if(((Request)msg).getRequest() instanceof Boolean)
						{
							if(!(Boolean)(((Request)msg).getRequest())){
								//DB is Empty
								System.out.print("empty");
							}
						}
						if(((Request)msg).getRequest() instanceof ArrayList<?>)
						{
							if(((ArrayList<?>)((Request)msg).getRequest()).get(0) instanceof String)
							{
								
								ArrayList<String> m1 = ((ArrayList<String>)((Request)msg).getRequest());
								for (int i = 0; i < m1.size(); i++) {
									//((TeacherUplaodAss)((TeacherHomeUI)((HomeUI)clientGUI).innerpanel).innerpanel).choice.add(m.get(i).getCourse_Name() + " '" + m.get(i).getCourse_ID() +"'");
									
									((SelectClass)((TeacherHomeUI)((HomeUI)clientGUI).innerpanel).innerpanel).combo_Class.addItem(( m1.get(i) ));
					    		
									
								}
								
							}
						}
						break;
					
					case 712:
						
						if(((Request)msg).getRequest() instanceof Boolean)
						{
							if(!(Boolean)(((Request)msg).getRequest())){
								//DB is Empty
								System.out.print("empty");
							}
						}
						if(((Request)msg).getRequest() instanceof ArrayList<?>)
						{
							if(((ArrayList<?>)((Request)msg).getRequest()).get(0) instanceof Integer)
							{
								
								ArrayList<Integer> m3 = ((ArrayList<Integer>)((Request)msg).getRequest());
								String mmm="";
								mmm = ((SelectClass)((TeacherHomeUI)((HomeUI)Client.client.clientGUI).innerpanel).innerpanel).value_Course;
								((TeacherHomeUI)((HomeUI)Client.client.clientGUI).innerpanel).contentPane.remove(((TeacherHomeUI)((HomeUI)Client.client.clientGUI).innerpanel).innerpanel);
								((SelectClass)((TeacherHomeUI)((HomeUI)Client.client.clientGUI).innerpanel).innerpanel).removeAll();
								((TeacherHomeUI)((HomeUI)Client.client.clientGUI).innerpanel).innerpanel = new SelectStudent();
								((TeacherHomeUI)((HomeUI)Client.client.clientGUI).innerpanel).contentPane.add(((TeacherHomeUI)((HomeUI)Client.client.clientGUI).innerpanel).innerpanel);
								((SelectStudent)((TeacherHomeUI)((HomeUI)Client.client.clientGUI).innerpanel).innerpanel).value_course= mmm;
								for (int i = 0; i < m3.size(); i++) {
									//((TeacherUplaodAss)((TeacherHomeUI)((HomeUI)clientGUI).innerpanel).innerpanel).choice.add(m.get(i).getCourse_Name() + " '" + m.get(i).getCourse_ID() +"'");
									
									((SelectStudent)((TeacherHomeUI)((HomeUI)clientGUI).innerpanel).innerpanel).combo_student.addItem(( m3.get(i) ));
					    		
									
								}
								((TeacherHomeUI)((HomeUI)Client.client.clientGUI).innerpanel).resizeteacherhome();
								
							}
						}
						break;
					case 713:
						
						if(((Request)msg).getRequest() instanceof Boolean)
						{
							if(!(Boolean)(((Request)msg).getRequest())){
								//DB is Empty
								System.out.print("empty");
							}
						}
						if(((Request)msg).getRequest() instanceof ArrayList<?>)
						{
							if(((ArrayList<?>)((Request)msg).getRequest()).get(0) instanceof Integer)
							{
								String mmmm="";
								String aa="";
								mmmm=((SelectStudent)((TeacherHomeUI)((HomeUI)Client.client.clientGUI).innerpanel).innerpanel).value_student;
								aa=((SelectStudent)((TeacherHomeUI)((HomeUI)Client.client.clientGUI).innerpanel).innerpanel).value_course;
								ArrayList<Integer> m4 = ((ArrayList<Integer>)((Request)msg).getRequest());
								((TeacherHomeUI)((HomeUI)Client.client.clientGUI).innerpanel).contentPane.remove(((TeacherHomeUI)((HomeUI)Client.client.clientGUI).innerpanel).innerpanel);
								((SelectStudent)((TeacherHomeUI)((HomeUI)Client.client.clientGUI).innerpanel).innerpanel).removeAll();
								((TeacherHomeUI)((HomeUI)Client.client.clientGUI).innerpanel).innerpanel = new SelectAssigment();
								
								((TeacherHomeUI)((HomeUI)Client.client.clientGUI).innerpanel).contentPane.add(((TeacherHomeUI)((HomeUI)Client.client.clientGUI).innerpanel).innerpanel);
								((SelectAssigment)((TeacherHomeUI)((HomeUI)Client.client.clientGUI).innerpanel).innerpanel).value_student=mmmm;
								((SelectAssigment)((TeacherHomeUI)((HomeUI)Client.client.clientGUI).innerpanel).innerpanel).value_course=aa;
								for (int i = 0; i < m4.size(); i++) {
									//((TeacherUplaodAss)((TeacherHomeUI)((HomeUI)clientGUI).innerpanel).innerpanel).choice.add(m.get(i).getCourse_Name() + " '" + m.get(i).getCourse_ID() +"'");
									
									((SelectAssigment)((TeacherHomeUI)((HomeUI)clientGUI).innerpanel).innerpanel).combo_assigment.addItem(( m4.get(i) ));
					    		
									
								}
								((TeacherHomeUI)((HomeUI)Client.client.clientGUI).innerpanel).resizeteacherhome();
								
							}
						}
						break;
					case 714:
						if(((Request)msg).getRequest() instanceof Boolean)
						{
							System.out.print("Updated");	
						}
						else{
							//System Error
							System.out.print("not Updated");	
						}
						break;
					case 715:
						if(((Request)msg).getRequest() instanceof Boolean)
						{
							if(!(Boolean)(((Request)msg).getRequest())){
								//DB is Empty
								
								System.out.print("empty");
							}
						}
						break;
					case 716:
						if(((Request)msg).getRequest() instanceof uploadFile)
						{
							
							uploadFile m1 = ((uploadFile)((Request)msg).getRequest());
							
							  String message = m1.getconvert();
							  String[] byteValues = message.substring(1, message.length() - 1).split(",");
							  byte[] imgInByte = new byte[byteValues.length];
							  for (int i = 0; i < byteValues.length; i++) {
									imgInByte[i] = Byte.parseByte(byteValues[i].trim());
							  }
							  String filedown =m1.getFileName();
							  File filez=new File("src/download/"+filedown);
							  try {
								FileOutputStream fos=new FileOutputStream(filez);
								fos.write(imgInByte);
								fos.close();
								//System.out.println("anaaaaaa");
							} catch (FileNotFoundException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							} catch (IOException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
							  if (Desktop.isDesktopSupported()) {
								    try {
								        File myFile = new File("src/download/"+filedown);
								        Desktop.getDesktop().open(myFile);
								    } catch (IOException ex) {
								        // no application registered for PDFs
								    }
								}
						}
						break;
						
					case 717:
						if(((Request)msg).getRequest() instanceof Boolean)
						{
							if((Boolean)(((Request)msg).getRequest())){
								((TeacherUplaodAss)((TeacherHomeUI)((HomeUI)Client.client.clientGUI).innerpanel).innerpanel).successadd("The assigment has been uploaded sucessfully");
								((TeacherUplaodAss)((TeacherHomeUI)((HomeUI)Client.client.clientGUI).innerpanel).innerpanel).filePicker.SetEmptytextfiled();
							}
						}
						break;
						case 718:
							if(((Request)msg).getRequest() instanceof Boolean)
							{
								if((Boolean)(((Request)msg).getRequest())){
									((TeacherUploadMat)((TeacherHomeUI)((HomeUI)Client.client.clientGUI).innerpanel).innerpanel).successadd("The assigment has been uploaded sucessfully");
									((TeacherUploadMat)((TeacherHomeUI)((HomeUI)Client.client.clientGUI).innerpanel).innerpanel).filePicker.SetEmptytextfiled();
								}
							}
							break;
						case 719:
							if(((Request)msg).getRequest() instanceof Boolean)
							{
								if((Boolean)(((Request)msg).getRequest())){
									((TeacherEstimatingFile)((TeacherHomeUI)((HomeUI)Client.client.clientGUI).innerpanel).innerpanel).successadd("The assigment has been uploaded sucessfully");
									((TeacherEstimatingFile)((TeacherHomeUI)((HomeUI)Client.client.clientGUI).innerpanel).innerpanel).filePicker.SetEmptytextfiled();
								}
							}
							break;
						//teacher
						
						
						
			
		}
	}
	
    /**
     * This method handles all data coming from the UI
     *
     * @param message The message from the UI.
     */
    public void handleMessageFromClientUI(Message msg) {
    	if (!isConnected()) {
            //((LoginUI) clientGUI.setst("Could not send message to server. Terminating client.");
        } else {
        	try {
				sendToServer(msg);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
        }
    	
    }

    public byte[] readFile(String file) {
    	ByteArrayOutputStream bos = null;
        try {
            File f = new File(file);
            FileInputStream fis = new FileInputStream(f);
            byte[] buffer = new byte[1024];
            bos = new ByteArrayOutputStream();
            for (int len; (len = fis.read(buffer)) != -1;) {
                bos.write(buffer, 0, len);
            }
        } catch (FileNotFoundException e) {
            System.err.println(e.getMessage());
        } catch (IOException e2) {
            System.err.println(e2.getMessage());
        }
        return bos != null ? bos.toByteArray() : null;
    }
    

    public void handleCommand(String command) throws IOException {
    	if(command.equals("#Checklogin"))
    	{
    		try {
                openConnection();
                sendToServer(command);
                System.out.println("Connected to server!");
            } catch (IOException e) {
            }
    	}
        /*if (command.equals("#quit")) {
            quit();
        } else if (command.equals("#logoff")) {
            try {
                closeConnection();
            } catch (IOException e) {
            }
        } else if (command.contains("#sethost")) {
            if (!isConnected()) {
                String newHost = command.substring(9);
                setHost(newHost);
                System.out.println("Changed host to " + newHost);
            } else {
                System.out.println("Already connected!");
            }
        } else if (command.contains("#setport")) {
            if (!isConnected()) {
                int newPort = Integer.parseInt(command.substring(9));
                setPort(newPort);
                System.out.println("Changed port to " + newPort);
            } else {
                System.out.println("Already connected!");
            }
        } else if (command.contains("#login")) {
            if (!isConnected()) {
                try {
                    openConnection();
                    sendToServer(command);
                    System.out.println("Connected to server!");
                } catch (IOException e) {
                }
            } else {
                System.out.println("Already connected!");
            }
        } else if (command.equals("#gethost")) {
            System.out.println("Host: " + getHost());
        } else if (command.equals("#getport")) {
            System.out.println("Port: " + getPort());
        } else if (command.equals("#1")) {
            sendToServer("#1");
        } else if (command.equals("#2")) {
            sendToServer("#2");
        } else if (command.equals("#3")) {
            sendToServer("#3");
        } else if (command.equals("#4")) {
            sendToServer("#4");
        } else if (command.equals("#5")) {
            sendToServer("#5");
        } else if (command.equals("#6")) {
            sendToServer("#6");
        } else if (command.equals("#7")) {
            sendToServer("#7");
        } else if (command.equals("#8")) {
            sendToServer("#8");
        } else if (command.equals("#9")) {
            sendToServer("#9");
        } else if (command.equals("#createGame")) {
            sendToServer("#createGame");
        } else if (command.equals("#getGameList")) {
            sendToServer("#getGameList");
        } else {
            System.out.println("Command not recognized!");
        }
        */
    }
	
}
