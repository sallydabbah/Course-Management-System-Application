package Parent;

import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.ListSelectionModel;
import javax.swing.border.MatteBorder;

import java.awt.Color;

import javax.swing.JLabel;

public class ParentHomeUI extends JPanel {
	public final JTable tblStudent;
	/**
	 * Create the panel.
	 */
	public ParentHomeUI() {
		setLayout(null);
		tblStudent= new JTable(){public boolean isCellEditable(int row,int column){Object o = getValueAt(row,column);if(o!=null) return false;return true;}};
		tblStudent.setBorder(new MatteBorder(1, 1, 1, 1, Color.BLACK));
		tblStudent.setSelectionMode(ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);
		tblStudent.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
		tblStudent.setEnabled(false);
		JScrollPane jspane=new JScrollPane(tblStudent, JScrollPane.VERTICAL_SCROLLBAR_NEVER, JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
		jspane.setBounds(72, 77, 308, 250);
		add(jspane);

	}
}
