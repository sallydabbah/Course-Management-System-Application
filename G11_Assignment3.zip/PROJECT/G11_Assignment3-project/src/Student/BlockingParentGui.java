package Student;

import javax.swing.JPanel;



import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.JTextField;

import Entities.*; 

import OurMessage.Message;
import OurMessage.QTypes;
import User.HomeUI;
import chat.Client;

import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.sql.Date;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.awt.event.ActionEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.TextArea;
import java.awt.Color;

public class BlockingParentGui extends JPanel {
    private String pid; 
   public JLabel lblMsg;
   public  int count;
   public int parent_id;
   public int exist=0; // for checking if request already saved in db
   public int id_message; 
   private final JLabel lbltoday = new JLabel("");
   public JLabel newpan=new JLabel(); 
    /**
	 * Create the panel.
	 */
	public BlockingParentGui() {
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd");
		LocalDateTime now = LocalDateTime.now();
		newpan.setBounds(135, 0, 289, 300);
		setBounds(135, 0, 289, 300);
		setLayout(null); 
		JPanel newpan=new JPanel(); // Creating an Empty Jpanel for the Cancel Button .
		newpan.setBounds(135, 0, 289, 300);
		JLabel lblParentsBlocking = new JLabel("Parents Blocking : ");
		lblParentsBlocking.setBounds(10, 11, 155, 31);
		add(lblParentsBlocking);
	      
		//System.out.printf("test date",date);
		 lblMsg = new JLabel("New label");
		
		lblMsg.setEnabled(false);
		lblMsg.setVisible(false);
		lblMsg.setBounds(10, 103, 252, 28);
		add(lblMsg);
		JButton btnBlockParent = new JButton("Block parent"); // i should do request
		btnBlockParent.addMouseListener(new MouseAdapter() {
			/**
			 * create_instance
			 * @param MouseEvent e  
			 * @return true/false statement 
			 */
			@Override
			public void mouseClicked(MouseEvent e) {	
				 Message msg8=new Message(" select id_student from request_block where id_student="+Client.client.user.getID()+";",QTypes.checkrequestsally);
					Client.client.handleMessageFromClientUI(msg8);
				
			}
		});
		/*
		btnBlockParent.addActionListener(new ActionListener() {
		
			public void actionPerformed(ActionEvent e) {
			
			}
		});*/
		btnBlockParent.setBounds(10, 154, 107, 31);
		add(btnBlockParent);
		
		JLabel lblMessageContent = new JLabel("Press Block for blocking your parents");
		lblMessageContent.setBounds(10, 53, 252, 41);
		add(lblMessageContent);
		JButton btnCancel = new JButton("Cancel");
		btnCancel.addActionListener(new ActionListener() {
			/**
			 * create_instance
			 * @param ActionEvent object listener 
			 * @return update the panel in BlockingParentGui
			 */
			public void actionPerformed(ActionEvent arg0) {
				((HomeStudent)((HomeUI)Client.clientGUI).innerpanel).remove(((HomeStudent)((HomeUI)Client.clientGUI).innerpanel).panel);
		((HomeUI)Client.clientGUI).resizeHome();
		((HomeStudent)((HomeUI)Client.clientGUI).innerpanel).panel=newpan;
			}
		});
	
		
		btnCancel.setBounds(153, 156, 102, 27);
		add(btnCancel);
		
		JLabel lblDate = new JLabel("Date:");
		lblDate.setBounds(175, 19, 34, 14);
		add(lblDate);
		
		lbltoday.setBounds(205, 19, 74, 14);
		lbltoday.setText(dtf.format(now));
		add(lbltoday);

	}/*
	public void setexit()
	{
		 Message msg8=new Message(" select id_student from request_block where id_student="+Client.client.user.getID()+";",QTypes.checkrequestsally);
			Client.client.handleMessageFromClientUI(msg8);
	}*/
	
}
