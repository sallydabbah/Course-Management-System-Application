package Student;

import javax.swing.JPanel;
import javax.swing.table.TableModel;

import OurMessage.Message;
import OurMessage.QTypes;
import User.HomeUI;
import chat.Client;
import upload.JFilePicker;

import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Color;
import java.awt.Font;
import javax.swing.JComboBox;
import javax.swing.JFileChooser;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.ActionEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.File;

public class DownloadMaterialsGui extends JPanel {

	private JComboBox coursecombo;
	private JComboBox assignmentcombo;
	private TableModel[] tableCourses;
	private JButton btnNewButton = new JButton("Download");
	private JLabel lblstar = new JLabel("");


	JPanel newpan=new JPanel();
	/**
	 * Create the panel.
	 */
	public DownloadMaterialsGui() {
		setBounds(135, 0, 253, 235);
		setLayout(null);
		
		newpan.setBounds(135, 0, 289, 300);
		JLabel lblDownloadMaterials = new JLabel("Download Materials :");
		lblDownloadMaterials.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblDownloadMaterials.setBounds(43, 11, 142, 34);
		add(lblDownloadMaterials);
		
		JLabel lblCourseName = new JLabel("Course ID:");
		lblCourseName.setBounds(20, 56, 77, 26);
		add(lblCourseName);
		assignmentcombo = new JComboBox();
		 coursecombo = new JComboBox();
		coursecombo.setBounds(87, 56, 126, 26);
		add(coursecombo);
		
		JLabel lblMaterial = new JLabel("Material :");
		lblMaterial.setBounds(20, 103, 61, 26);
		add(lblMaterial);
		
	
	
		assignmentcombo.setBounds(87, 103, 126, 26);
		add(assignmentcombo);
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String course=coursecombo.getSelectedItem().toString();
				String teacher=tableCourses[0].getValueAt(coursecombo.getSelectedIndex(), 1).toString();
				String mat=assignmentcombo.getSelectedItem().toString();
				if(!mat.equals("")){
					lblstar.setVisible(false);
					Client.client.handleMessageFromClientUI(new Message("SELECT * FROM materials WHERE course_id='"+course+"' AND teacher_id="+teacher+" AND sem_id="+Client.opnedsem+" AND idmaterials="+mat+";",QTypes.materialcombodownload)); 
				}else{
					lblstar.setText("*");
					lblstar.setForeground(Color.RED);
					lblstar.setVisible(true);
				}
			}
		});
		
		
		btnNewButton.setBounds(20, 173, 89, 23);
		add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("Cancel");
		btnNewButton_1.addActionListener(new ActionListener() {
			/**
			 * create_instance
			 * @param ActionEvent object listener 
			 * @return update the panel in DownloadMaterialsGui to new panel.
			 */
			public void actionPerformed(ActionEvent e) {
				((HomeStudent)((HomeUI)Client.clientGUI).innerpanel).remove(((HomeStudent)((HomeUI)Client.clientGUI).innerpanel).panel);
				((HomeUI)Client.clientGUI).resizeHome();
				((HomeStudent)((HomeUI)Client.clientGUI).innerpanel).panel=newpan; 
			}
		});
		btnNewButton_1.setBounds(124, 173, 89, 23);
		add(btnNewButton_1);
		
		lblstar.setBounds(223, 109, 30, 14);
		add(lblstar);
		
	}
	public void setCourseCMB(TableModel[] table){
		DefaultComboBoxModel model=new DefaultComboBoxModel();
		tableCourses=table;
		for(int i=0;i<table[0].getRowCount();i++){
			model.addElement((table[0].getValueAt(i,0)).toString());
		}
		coursecombo.setModel(model);
		coursecombo.setSelectedIndex(0);
		coursecombo.addItemListener(new ItemListener(){
			@Override
			public void itemStateChanged(ItemEvent e) {
				if(e.getStateChange() == ItemEvent.SELECTED){
					  DefaultComboBoxModel model2=new DefaultComboBoxModel();
					  assignmentcombo.removeAll();
	                  int index=coursecombo.getSelectedIndex()+1;
	                  for(int i=0;i<table[index].getRowCount();i++){
	                	  model2.addElement(table[index].getValueAt(i, 0).toString());
	                  }
	                  assignmentcombo.setModel(model2);
	            }  
				
			}
        });
		DefaultComboBoxModel model2=new DefaultComboBoxModel();
		assignmentcombo.removeAll();
        for(int i=0;i<table[1].getRowCount();i++){
      	  model2.addElement(table[1].getValueAt(i, 0).toString());
        }
        assignmentcombo.setModel(model2);
	}
	public  void showerrdilog(String string) {
		JOptionPane.showMessageDialog(null, string,"Invalid Input",JOptionPane.ERROR_MESSAGE);
	} 

	public  void successadd(String string) {
	JOptionPane.showMessageDialog(null, string,"Success",JOptionPane.PLAIN_MESSAGE);
	}
	public void setCourseCMBERR(String txt){
		showerrdilog(txt);
		coursecombo.setEnabled(false);
		assignmentcombo.setEnabled(false);
		btnNewButton.setEnabled(false);
	}
	public void successfileopen(){
		successadd("File opened!");
		coursecombo.setEnabled(false);
		assignmentcombo.setEnabled(false);
		btnNewButton.setEnabled(false);
	}

}
