package Student;

import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JTextField;
import javax.swing.table.TableModel;

import Entities.ClassRoomTeacher;
import OurMessage.Message;
import OurMessage.QTypes;

import javax.swing.JFileChooser;
import User.HomeUI;
import chat.Client;
import upload.JFilePicker;

import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Arrays;
import java.awt.event.ActionEvent;
import java.awt.*;

public class UploadAssignment extends JPanel {
	private final JLabel lblCourseNumber = new JLabel("Course Number : ");
	private JComboBox coursecombo = new JComboBox();
	private final JLabel lblAssignment = new JLabel("Assignment:");
	private final JComboBox assignmentcombo = new JComboBox();
	private final JButton Submit = new JButton("Submitt");
	private final JButton Cancel = new JButton("Cancel");
	private TableModel[] tableCourses;
	JLabel lblstar = new JLabel("");
    static int MAX_FILE_SIZE=16777215;
	public JFilePicker filePicker;
	JPanel newpan=new JPanel();
	private final JLabel lblmsg = new JLabel("");
	/**
	 * Create the panel.
	 */
	public UploadAssignment() {
		((HomeStudent)((HomeUI)Client.clientGUI).innerpanel).page=3;
		setBackground(Color.WHITE);
		setBounds(135, 0, 502, 300);
		setLayout(null);
		
		filePicker = new JFilePicker("Choose a file", "Browse...");
		filePicker.setBounds(0, 70, 502, 52);
		filePicker.setMode(JFilePicker.MODE_SAVE);
		filePicker.addFileTypeFilter(".pdf", "PDF");
		filePicker.addFileTypeFilter(".doc", "Word File");
		filePicker.addFileTypeFilter(".docx", "Word File");
		filePicker.addFileTypeFilter(".xlsx", "excel File");
		filePicker.addFileTypeFilter(".xls", "excel File");
		filePicker.addFileTypeFilter(".jpg", "jpg File");
		JFileChooser fileChooser = filePicker.getFileChooser();
        fileChooser.setCurrentDirectory(new File("C:/"));
		
		add(filePicker);
		
		newpan.setBounds(135, 0, 289, 300);
		lblCourseNumber.setBounds(36, 30, 89, 23);
		
		add(lblCourseNumber);
		coursecombo.setBounds(125, 30, 122, 22);
		
		add(coursecombo);
		lblAssignment.setBounds(267, 30, 82, 23);
		
		add(lblAssignment);
		assignmentcombo.setBounds(338, 30, 122, 23);
		
		add(assignmentcombo);
		Submit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				String filePath=filePicker.getSelectedFilePath();
				if(filePath.equals(""))
				{
					showerrdilog("You Need to but a file assigment");
					
				}
				else
				{
					if(filePath.endsWith(".doc") || filePath.endsWith(".docx") || filePath.endsWith(".xls")  || filePath.endsWith(".xlsx") || filePath.endsWith(".pdf")||filePath.endsWith(".jpg"))
					{
						filePath=filePath.replace("\\", "/");
						if(assignmentcombo.getSelectedIndex()==-1){
							lblstar.setText("*");
							lblstar.setForeground(Color.RED);
							lblstar.setVisible(true);
						}else{
							lblstar.setVisible(false);
							try {
								String course=coursecombo.getSelectedItem().toString(),assigment=assignmentcombo.getSelectedItem().toString();
								byte[] myfile = read(new File(filePath));
								String message=Arrays.toString(myfile);
								String fname = filePath.substring(filePath.lastIndexOf('/') +1, filePath.length());
								//System.out.print(f);
								Client.client.handleMessageFromClientUI(new Message(message,"INSERT INTO assigment_grades (id_student,course,id_assigment,sem_id,ans_file,ans_name) VALUES (" 
									+Client.user.getID()+",'"+course+"',"+assigment+","+ Client.client.opnedsem + ",?,'"+fname+"');",QTypes.uploadassigment));
							} catch (IOException e1) {
								// TODO Auto-generated catch block
								e1.printStackTrace();
							}
					    }	
					}
					else
					{
						showerrdilog("Your File type is not Supported !!");
					}
				}
			}
		});
		Submit.setBounds(36, 253, 89, 23);
		
		add(Submit);
		Cancel.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				((HomeStudent)((HomeUI)Client.clientGUI).innerpanel).remove(((HomeStudent)((HomeUI)Client.clientGUI).innerpanel).panel);
				((HomeUI)Client.clientGUI).resizeHome();
				((HomeStudent)((HomeUI)Client.clientGUI).innerpanel).panel=newpan; 
			}
		});
		Cancel.setBounds(381, 253, 89, 23);
		
		add(Cancel);
		lblmsg.setBounds(36, 136, 424, 14);
		
		add(lblmsg);
		
		
		lblstar.setBounds(470, 34, 22, 14);
		add(lblstar);
	}
	public byte[] read(File file) throws IOException {
	    if (file.length() > MAX_FILE_SIZE) {
	        System.out.println("error");
	    }

	    byte[] buffer = new byte[(int) file.length()];
	    InputStream ios = null;
	    try {
	        ios = new FileInputStream(file);
	        if (ios.read(buffer) == -1) {
	            throw new IOException(
	                    "EOF reached while trying to read the whole file");
	        }
	    } finally {
	        try {
	            if (ios != null)
	                ios.close();
	        } catch (IOException e) {
	        }
	    }
	    return buffer;
	}
	public  void showerrdilog(String string) {
		JOptionPane.showMessageDialog(null, string,"Invalid Input",JOptionPane.ERROR_MESSAGE);
	} 

	public  void successadd(String string) {
	JOptionPane.showMessageDialog(null, string,"Success",JOptionPane.PLAIN_MESSAGE);
	}
	public void setCourseCMBERR(String txt){
		showerrdilog(txt);
		coursecombo.setEnabled(false);
		assignmentcombo.setEnabled(false);
		Submit.setEnabled(false);
	}
	public void setCourseCMB(TableModel[] table){
		DefaultComboBoxModel model=new DefaultComboBoxModel();
		tableCourses=table;
		for(int i=0;i<table[0].getRowCount();i++){
			model.addElement((table[0].getValueAt(i,0)).toString());
		}
		coursecombo.setModel(model);
		coursecombo.setSelectedIndex(0);
		coursecombo.addItemListener(new ItemListener(){
			@Override
			public void itemStateChanged(ItemEvent e) {
				if(e.getStateChange() == ItemEvent.SELECTED){
					  DefaultComboBoxModel model2=new DefaultComboBoxModel();
					  assignmentcombo.removeAll();
	                  int index=coursecombo.getSelectedIndex()+1;
	                  for(int i=0;i<table[index].getRowCount();i++){
	                	  model2.addElement(i+1);
	                  }
	                  assignmentcombo.setModel(model2);
	            }  
				
			}
        });
		DefaultComboBoxModel model2=new DefaultComboBoxModel();
		assignmentcombo.removeAll();
        for(int i=0;i<table[1].getRowCount();i++){
      	  model2.addElement(i+1);
        }
        assignmentcombo.setModel(model2);
	}
}
