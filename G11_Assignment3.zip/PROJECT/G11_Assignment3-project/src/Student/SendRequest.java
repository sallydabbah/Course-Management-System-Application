package Student;

import javax.swing.JPanel;

import OurMessage.Message;
import OurMessage.QTypes;
import User.HomeUI;
import chat.Client;

import javax.swing.JLabel;

import java.awt.Color;
import java.awt.Font;
import javax.swing.JComboBox;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class SendRequest extends JPanel {

	public JPanel newpan=new JPanel();
	public final JLabel lblRequestMoving = new JLabel("Request : Moving Class");
	public final JLabel lblClass = new JLabel("Moving to class:");
	public final JComboBox comboBox;
	public final JButton btnSendRequest = new JButton("Send Request");
	public final JButton btnNewButton = new JButton("Cancel");
	public final JLabel lblMsg = new JLabel("");
	public String classstudent;
	public int exist=0; 
	public int idclass; 
	public int course_id; 
	public int requestnum; 
	private final JLabel lblFromClass = new JLabel("From Class: ");
	private final JLabel lblclassfrom = new JLabel("");
	
	/**
	 * Create the panel.
	 */
	public SendRequest() {
		setBounds(135, 0, 289, 300);
		setLayout(null);
		newpan.setBounds(135, 0, 289, 300);
		lblRequestMoving.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblRequestMoving.setBounds(10, 11, 179, 31);
		lblMsg.setVisible(false);
		add(lblRequestMoving);
		lblClass.setFont(new Font("Tahoma", Font.PLAIN, 13));
		lblClass.setBounds(20, 90, 115, 27);
		comboBox=new JComboBox();
		add(lblClass);
		comboBox.setBounds(136, 91, 85, 27);
		
		add(comboBox);
		btnSendRequest.addActionListener(new ActionListener() {
			/**
			 * create_instance
			 * @param ActionEvent arg0
			 * the function checks what is the max value for requests saved in data base and execute an insert instruction accordingly.
			 * @return updates the Number of maximum request id saved in DB -request table.
			 */
			public void actionPerformed(ActionEvent arg0) {
				//"Select idRequests from requests where idStudent="+Client.client.user.getID()+";"
			 Message msg=new Message("SELECT idStudent FROM requests WHERE idStudent="+Client.user.getID()+";#INSERT INTO requests values ("+Client.user.getID()+",'"+comboBox.getSelectedItem().toString()+"','NYD',"+Client.opnedsem+",0);",QTypes.exitrequest);
			 Client.client.handleMessageFromClientUI(msg);
				
			}
		});
		btnSendRequest.setBounds(10, 193, 104, 29);
		
		add(btnSendRequest);
		btnNewButton.addActionListener(new ActionListener() {
			/**
			 * create_instance
			 * @param ActionEvent object listener
			 * the function updates the innerpanel to new panel when cancel is pressed . 
			 * @return update the panel in SendRequest
			 */
			public void actionPerformed(ActionEvent arg0) {
				((HomeStudent)((HomeUI)Client.clientGUI).innerpanel).remove(((HomeStudent)((HomeUI)Client.clientGUI).innerpanel).panel);
				((HomeUI)Client.clientGUI).resizeHome();
				((HomeStudent)((HomeUI)Client.clientGUI).innerpanel).panel=newpan;
			}
		});
		btnNewButton.setBounds(151, 194, 99, 27);
		
		add(btnNewButton);
		lblMsg.setBounds(10, 129, 256, 53);
		
		add(lblMsg);
		lblFromClass.setFont(new Font("Tahoma", Font.PLAIN, 13));
		lblFromClass.setBounds(20, 53, 94, 14);
		
		add(lblFromClass);
		lblclassfrom.setFont(new Font("Tahoma", Font.PLAIN, 13));
		lblclassfrom.setBounds(100, 53, 46, 14);
		
		add(lblclassfrom);

	}
	public void insretSuc(){
		lblMsg.setText("Your Request Sent Successfully!");
		lblMsg.setForeground(Color.GREEN);
		lblMsg.setVisible(true);
		btnSendRequest.setEnabled(false);
		comboBox.setEnabled(false);
	}
	public void insertunSuc(int op){
		if(op==0)
			lblMsg.setText("An Request already exist in the DataBase!");
		else
			lblMsg.setText("An Error accuried while writing to DataBase!");
		lblMsg.setForeground(Color.RED);
		lblMsg.setVisible(true);
		btnSendRequest.setEnabled(false);
		comboBox.setEnabled(false);
	}
	public void setclassFrom(String cl){
		lblclassfrom.setText(cl);
		String[] parts=cl.split("/");
		for(int i=1;i<6;i++){
			if(!parts[1].equals(""+i))
				comboBox.addItem(parts[0]+"/"+i);
		}
	}
}
