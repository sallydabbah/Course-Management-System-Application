package Student;

import javax.swing.JPanel;
import javax.swing.*;
import java.awt.List;
import javax.swing.event.ListSelectionListener;

import OurMessage.Message;
import OurMessage.QTypes;
import SchoolAdmin.SchoolHomeAdminGUI;
import User.HomeUI;
import chat.Client;

import javax.swing.event.ListSelectionEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionAdapter;
import chat.Client;
import java.awt.Color;
public class HomeStudent extends JPanel {
	/**
	 * Create the panel.
	 */
	 public JPanel panel;
	 public int page;
	 // in the constructor we added values to the list.
	public HomeStudent() {
		setBackground(Color.WHITE);
			setBounds(10, 59, 424, 300);
		setLayout(null);
		panel=new JPanel();
		panel.setLayout(null);
	      int value=0; 
		DefaultListModel <String>model = new DefaultListModel<String>();
		model.addElement("View Report");
		model.addElement("Download Assignment");
		model.addElement("Blocking parent");
		model.addElement("Download Materials");
		model.addElement("Upload Assignment");
		model.addElement("Moving class Request");
		JList list = new JList(model);
		list.addMouseListener(new MouseAdapter() {
			/**
			 * create_instance
			 * @param MouseEvent e 
			 * the function updates the innerpanel accordingly for each item selected in the list. 
			 * @return nothing - void 
			 */
			@Override
			public void mousePressed(MouseEvent e) {
				  Object Res=list.getSelectedValue();
					switch((String)Res)
					{
					case "View Report": 
						((HomeStudent)((HomeUI)Client.clientGUI).innerpanel).panel.repaint();
						((HomeStudent)((HomeUI)Client.clientGUI).innerpanel).remove(panel);
						((HomeUI)Client.clientGUI).resizeHome();
						((HomeStudent)((HomeUI)Client.clientGUI).innerpanel).panel=new ViewReportGui(); 
						//((HomeStudent)((HomeUI)Client.clientGUI).innerpanel).panel.repaint();
							break;
					case "Download Assignment":
						Client.client.handleMessageFromClientUI(new Message(""+Client.user.getID()+"/"+Client.opnedsem,QTypes.getclassesstu)); 

						//((HomeStudent)((HomeUI)Client.clientGUI).innerpanel).panel.repaint();
						//((HomeStudent)((HomeUI)Client.clientGUI).innerpanel).remove(panel);
						//((HomeUI)Client.clientGUI).resizeHome();
						//((HomeStudent)((HomeUI)Client.clientGUI).innerpanel).panel=new DownloadAssignment(); 
						//Message msg1=new Message("select * from class_students where student_id ="+Client.client.user.getID() +" AND sem_id="+Client.client.opnedsem,QTypes.getclassesstu); 
						//Message msg3=new Message("select distinct Course from assigment Group by Course;",QTypes.coursedownload); 
						
				         //Client.client.handleMessageFromClientUI(msg1);
				         //((HomeStudent)((HomeUI)Client.clientGUI).innerpanel).panel.repaint();
				         break; 
					case "Blocking parent":
						((HomeStudent)((HomeUI)Client.clientGUI).innerpanel).remove(panel);
						((HomeStudent)((HomeUI)Client.clientGUI).innerpanel).panel.repaint();
						((HomeUI)Client.clientGUI).resizeHome();
						((HomeStudent)((HomeUI)Client.clientGUI).innerpanel).panel=new BlockingParentGui(); 
						 Message msg=new Message(" SELECT parent_id from student_parent where student_id="+Client.client.user.getID()+";",QTypes.blockparent);
							Client.client.handleMessageFromClientUI(msg);
					       ((HomeStudent)((HomeUI)Client.clientGUI).innerpanel).panel.repaint();
						//System.out.print("Blockparentpanel");
						break; 
					case "Download Materials":
						Client.client.handleMessageFromClientUI(new Message(""+Client.user.getID()+"/"+Client.opnedsem,QTypes.getclassesstu1)); 
						break;
					case "Upload Assignment":
						Client.client.handleMessageFromClientUI(new Message(""+Client.user.getID()+"/"+Client.opnedsem,QTypes.setupuploadassigment));
						break; 
					case "Moving class Request":
						
						
						Message msg11=new Message("SELECT class_id FROM class_students where student_id="+Client.client.user.getID()+" AND sem_id="+Client.opnedsem+";",QTypes.getstudentclass);    
				         Client.client.handleMessageFromClientUI(msg11);
						
						default:
							break;
						}
					add(panel);
			}
		});
	
		list.setBounds(0, 0, 134, 300);
		add(list);
		panel.setBounds(135, 0, 289, 300);
		
	}
	public void ChangeJPanel(JPanel panel){
		((HomeUI)Client.clientGUI).innerpanel.remove(((HomeStudent)((HomeUI)Client.clientGUI).innerpanel).panel);
		((HomeStudent)((HomeUI)Client.clientGUI).innerpanel).panel=panel;
		((HomeUI)Client.clientGUI).innerpanel.add(((HomeStudent)((HomeUI)Client.clientGUI).innerpanel).panel);
		menuResize();
	}
	
	
	public void menuResize(){
		int y_offset=48;
		int x_offset=177;
		int y0=((HomeUI)Client.clientGUI).innerpanel.getHeight();
		int x=((HomeStudent)((HomeUI)Client.clientGUI).innerpanel).panel.getWidth();
		int y=((HomeStudent)((HomeUI)Client.clientGUI).innerpanel).panel.getHeight();
		int home_x=Client.clientGUI.getX();
		int home_y=Client.clientGUI.getY();
		int dif_width=(x_offset+x)-(((HomeUI)Client.clientGUI).getbtnX()+30);
		if(page==3){y=y0=330;x=502;}
		if(page==2){y=y0=350;}
		((HomeUI)Client.clientGUI).innerpanel.setBounds(0,y_offset , x_offset+x, y_offset+(y>y0?y:y0));
		((HomeUI)Client.clientGUI).contentPane.setBounds(0, 0, x_offset+x, y_offset+(y>y0?y:y0));
		((HomeUI)Client.clientGUI).setBounds(home_x, home_y, x_offset+x, y_offset+(y>y0?y:y0));
		((HomeUI)Client.clientGUI).setNewBounds(dif_width-10);
		((HomeUI)Client.clientGUI).repaint();
	}
	
}
