package Student;

import javax.swing.JPanel;
import javax.swing.table.TableModel;

import OurMessage.Message;
import OurMessage.QTypes;
import User.HomeUI;
import chat.Client;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.ActionEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class DownloadAssignment extends JPanel {
 
	JPanel newpan=new JPanel();
	public JComboBox coursecombo;
	public JComboBox assignmentcombo;
	private TableModel[] tableCourses;
	private JButton btnDownload = new JButton("Download");
	private JLabel lblstar = new JLabel("");


	/**
	 * Create the panel.
	 */
	public DownloadAssignment() {
		
		setBounds(135, 0, 289, 300);
		setLayout(null);
		newpan.setBounds(135, 0, 289, 300);
		JLabel lblCourseName = new JLabel("Course ID");
		lblCourseName.setBounds(10, 63, 109, 21);
		add(lblCourseName);
		
		coursecombo = new JComboBox();
		coursecombo.setBounds(129, 63, 108, 21);
		add(coursecombo);
		
		JLabel lblAssignment = new JLabel("Assignment:");
		lblAssignment.setBounds(10, 143, 109, 22);
		add(lblAssignment);
		
		assignmentcombo = new JComboBox();
		
		assignmentcombo.setBounds(129, 145, 108, 20);
		add(assignmentcombo);
		
		btnDownload.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if(assignmentcombo.getSelectedIndex()==-1){
					lblstar.setText("*");
					lblstar.setForeground(Color.RED);
					lblstar.setVisible(true);
					
				}else{
					lblstar.setVisible(false);
				String ass = assignmentcombo.getSelectedItem().toString();
				String css = coursecombo.getSelectedItem().toString();
				 Message msg=new Message("Select * from assigment where idAssigment="+ass+" AND Course="+css,QTypes.activeadownload);    
				 Client.client.handleMessageFromClientUI(msg);
				 }
			}
		});
		btnDownload.setBounds(10, 226, 94, 23);
		add(btnDownload);
		
		JButton btnCancel = new JButton("Cancel");
		btnCancel.addActionListener(new ActionListener() {
			/**
			 * create_instance
			 * @param ActionEvent object listener 
			 * @return update the panel in DownloadAssignment page
			 */
			public void actionPerformed(ActionEvent arg0) {
				((HomeStudent)((HomeUI)Client.clientGUI).innerpanel).remove(((HomeStudent)((HomeUI)Client.clientGUI).innerpanel).panel);
				((HomeUI)Client.clientGUI).resizeHome();
				((HomeStudent)((HomeUI)Client.clientGUI).innerpanel).panel=newpan; 
			}
		});
		btnCancel.setBounds(148, 226, 89, 23);
		add(btnCancel);
		
		JLabel lblDownloadAssignment = new JLabel("Download Assignment :");
		lblDownloadAssignment.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblDownloadAssignment.setBounds(10, 11, 168, 21);
		add(lblDownloadAssignment);
		

	}	
	public  void showerrdilog(String string) {
		JOptionPane.showMessageDialog(null, string,"Invalid Input",JOptionPane.ERROR_MESSAGE);
	} 

	public  void successadd(String string) {
	JOptionPane.showMessageDialog(null, string,"Success",JOptionPane.PLAIN_MESSAGE);
	}
	public void setCourseCMBERR(String txt){
		showerrdilog(txt);
		coursecombo.setEnabled(false);
		assignmentcombo.setEnabled(false);
		btnDownload.setEnabled(false);
	}
	public void setCourseCMB(TableModel[] table){
		DefaultComboBoxModel model=new DefaultComboBoxModel();
		tableCourses=table;
		for(int i=0;i<table[0].getRowCount();i++){
			model.addElement((table[0].getValueAt(i,0)).toString());
		}
		coursecombo.setModel(model);
		coursecombo.setSelectedIndex(0);
		coursecombo.addItemListener(new ItemListener(){
			@Override
			public void itemStateChanged(ItemEvent e) {
				if(e.getStateChange() == ItemEvent.SELECTED){
					  DefaultComboBoxModel model2=new DefaultComboBoxModel();
					  assignmentcombo.removeAll();
	                  int index=coursecombo.getSelectedIndex()+1;
	                  for(int i=0;i<table[index].getRowCount();i++){
	                	  model2.addElement(i+1);
	                  }
	                  assignmentcombo.setModel(model2);
	            }  
				
			}
        });
		DefaultComboBoxModel model2=new DefaultComboBoxModel();
		assignmentcombo.removeAll();
        for(int i=0;i<table[1].getRowCount();i++){
      	  model2.addElement(i+1);
        }
        assignmentcombo.setModel(model2);
	}
}
