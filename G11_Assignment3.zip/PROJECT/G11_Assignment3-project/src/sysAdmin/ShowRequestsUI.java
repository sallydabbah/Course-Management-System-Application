package sysAdmin;

import java.awt.Color;

import javax.swing.JPanel;

public class ShowRequestsUI extends JPanel {

	/**
	 * Create the panel.
	 */
	public ShowRequestsUI() {
		setBackground(Color.WHITE);
		setBounds(10, 59, 600, 350);
		setLayout(null);

	}

}
