package Entities;

import java.util.Arrays;
import java.io.Serializable;
public class uploadFile implements Serializable {
	private String FileName;
	private int UserID;
	private String convert;
	
	public uploadFile(String filename,int userid,String convert){
		setFileName(filename);
		setUserID(userid);
		setconvert(convert);
	}
	
	
			
	private void setconvert(String convert) {
		// TODO Auto-generated method stub
		this.convert = convert;
	}

	public String getconvert(){
		return convert;
	}
	

	public String getFileName() {
		return FileName;
	}
	public void setFileName(String fileName) {
		this.FileName = fileName;
	}
	public int getUserID() {
		return UserID;
	}
	public void setUserID(int userID) {
		UserID = userID;
	}
}