package Entities;

public class SystemAdmin extends User {

	public SystemAdmin(int ID, String Name, String Password, String Email, int Status, AccessProfiles Access) {
		super(ID, Name, Password, Email, Status, Access);
		// TODO Auto-generated constructor stub
	}

}
