package Entities;

public class Secretary extends User {

	public Secretary(int ID, String Name, String Password, String Email, int Status, AccessProfiles Access) {
		super(ID, Name, Password, Email, Status, Access);
		// TODO Auto-generated constructor stub
	}

}
