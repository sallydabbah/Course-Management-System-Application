package Entities;

public class StudentGrade {

	private int student_id;
	private float grade;
	private String course;
	private int assignment;
	public StudentGrade(int student,float gradeN,String courseID,int assignmentID){
		setGrade(gradeN);
		setStudent_id(student);
		setCourse(courseID);
		setAssignment(assignmentID);
	}
	public float getGrade() {
		return grade;
	}
	public void setGrade(float grade) {
		this.grade = grade;
	}
	public int getStudent_id() {
		return student_id;
	}
	public void setStudent_id(int student_id) {
		this.student_id = student_id;
	}
	public int getAssignment() {
		return assignment;
	}
	public void setAssignment(int assignment) {
		this.assignment = assignment;
	}
	public String getCourse() {
		return course;
	}
	public void setCourse(String course) {
		this.course = course;
	}
	
	
	
}
