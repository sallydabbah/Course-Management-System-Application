package Entities;

public class Student {

	private Parent parent[];
	

	public Parent[] getParent() {return parent;}
	public void setParent(Parent parent[]) {this.parent = parent;}
}
