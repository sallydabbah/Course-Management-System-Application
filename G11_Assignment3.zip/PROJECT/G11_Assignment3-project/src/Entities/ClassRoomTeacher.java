package Entities;



public class ClassRoomTeacher{
	
		private String Class_id;
		private String course_id;
		private int teacher_id;
		public ClassRoomTeacher(String classID,String courseID,int teacherID){
			setClass_id(classID);
			setTeacher_id(teacherID);
			setCourse_id(courseID);
		}
		public String getClass_id() {
			return Class_id;
		}
		public void setClass_id(String class_id) {
			Class_id = class_id;
		}
		public int getTeacher_id() {
			return teacher_id;
		}
		public void setTeacher_id(int teacher_id) {
			this.teacher_id = teacher_id;
		}
		public String getCourse_id() {
			return course_id;
		}
		public void setCourse_id(String course_id) {
			this.course_id = course_id;
		}
		
		
}
