package Entities;

public class TeacherHours {

	private int id;
	private float maxhours;
	private float currenthours;
	public TeacherHours(int ID,float Max,float Current){
		setId(ID);
		setMaxhours(Max);
		setCurrenthours(Current);
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public float getMaxhours() {
		return maxhours;
	}
	public void setMaxhours(float maxhours) {
		this.maxhours = maxhours;
	}
	public float getCurrenthours() {
		return currenthours;
	}
	public void setCurrenthours(float currenthours) {
		this.currenthours = currenthours;
	}
}
