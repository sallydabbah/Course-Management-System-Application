package Entities;

public class TeacherTU {
	private int id;
	private String tu;
	public TeacherTU(int ID,String TU)
	{
		setId(ID);
		setTu(TU);
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getTu() {
		return tu;
	}
	public void setTu(String tu) {
		this.tu = tu;
	}
	
}
