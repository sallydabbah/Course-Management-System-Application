package Entities;

public class TeacherName {

	
	private int id;
	private String name;
	public TeacherName(int ID,String Name){
		setId(ID);
		setName(Name);
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
}
