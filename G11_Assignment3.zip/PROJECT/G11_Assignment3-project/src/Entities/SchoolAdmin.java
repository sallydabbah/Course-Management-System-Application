package Entities;

public class SchoolAdmin extends User {

	public SchoolAdmin(int ID, String Name, String Password, String Email, int Status, AccessProfiles Access) {
		super(ID, Name, Password, Email, Status, Access);
		// TODO Auto-generated constructor stub
	}

}
