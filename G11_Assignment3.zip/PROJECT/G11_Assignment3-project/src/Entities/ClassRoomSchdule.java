package Entities;

public class ClassRoomSchdule {
	
		private String Class_id;
		private int teacherid;
		private String course;
		private int sem_id;
		//Check with DataBase Serialization Numbering
		public ClassRoomSchdule(String class_id,int teacherId,String courseId,int sem_id){
			setClass_id(class_id);
			setTeacherid(teacherId);
			setCourse(courseId);
			setSem_id(sem_id);
		}
		
		public String getClass_id() {
			return Class_id;
		}
		public void setClass_id(String class_id) {
			Class_id = class_id;
		}
		public int getTeacherid() {
			return teacherid;
		}

		public void setTeacherid(int teacherid) {
			this.teacherid = teacherid;
		}

		public String getCourse() {
			return course;
		}

		public void setCourse(String course) {
			this.course = course;
		}

		public int getSem_id() {
			return sem_id;
		}

		public void setSem_id(int sem_id) {
			this.sem_id = sem_id;
		}
		
}
