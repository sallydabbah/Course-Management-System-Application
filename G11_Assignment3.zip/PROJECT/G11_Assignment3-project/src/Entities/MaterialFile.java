package Entities;

public class MaterialFile extends File {

	public MaterialFile(String filename, int userid, int courseid) {
		super(filename, userid, courseid);
		// TODO Auto-generated constructor stub
	}

}
