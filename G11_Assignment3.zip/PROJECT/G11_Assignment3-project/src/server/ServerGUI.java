package server;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JLabel;
import server.Server;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;

import javax.swing.JTextField;
import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.Color;


import javax.swing.border.MatteBorder;

import javafx.scene.layout.Border;

public class ServerGUI extends JFrame {

	private final JLabel imgdb = new JLabel(new ImageIcon("img\\ServerGUI\\Analytics-2-icon.png"));
	private final JLabel imguser = new JLabel(new ImageIcon("img\\ServerGUI\\Addressbook-3-icon.png"));
	private final JLabel imgport = new JLabel(new ImageIcon("img\\ServerGUI\\Browser-icon.png"));
	private final JLabel imgpass = new JLabel(new ImageIcon("img\\ServerGUI\\Message-icon.png"));
	private final JLabel imgconnect = new JLabel(new ImageIcon("img\\ServerGUI\\Share-2-icon.png"));
	private final JLabel imgip = new JLabel(new ImageIcon("img\\ServerGUI\\Shield-icon.png"));

	private JPanel contentPane;
	private JTextArea serverConsole;
	private JLabel lblDbName;
	private JTextField textFieldDBName;
	private JLabel lblPort;
	private JTextField textFieldPort;
	private JButton btnConnect;
	private JTextField textFieldUser;
	private JLabel lblUsername;
	private JLabel lblPassword;
	private JPasswordField textFieldPass;
    public Server server;
	public static JLabel lblNewLabel;
	private static final long serialVersionUID = 1L;
	/**
	 * Launch the application.
	 */

	/**
	 * Create the frame.
	 */
	public ServerGUI() {
		 javax.swing.border.Border border = BorderFactory.createLineBorder(Color.DARK_GRAY, 1);
		setResizable(false);
		setBackground(Color.DARK_GRAY);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 527, 505);
		setTitle("SchoolBook-Server");
		contentPane = new JPanel();
		contentPane.setBackground(Color.GRAY);
		contentPane.setLayout(null);
		setContentPane(contentPane);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setViewportBorder(new MatteBorder(1, 1, 1, 1,Color.WHITE));
		scrollPane.setBounds(0, 171, 521, 305);
		contentPane.add(scrollPane);
		
		lblDbName = new JLabel("DB Name:");
		lblDbName.setForeground(new Color(255, 255, 255));
		lblDbName.setFont(new Font("Calibri",Font.PLAIN, 16));
		lblDbName.setBounds(40, 45, 72, 14);
		contentPane.add(lblDbName);
		
		textFieldDBName = new JTextField();
		textFieldDBName.setBackground(Color.DARK_GRAY);
		textFieldDBName.setForeground(new Color(255, 255, 255));
		textFieldDBName.setBorder(border);
		textFieldDBName.setCaretColor(Color.WHITE);
		textFieldDBName.setFont(new Font("Calibri", Font.BOLD | Font.ITALIC, 13));
		textFieldDBName.setBounds(110, 42, 125, 20);
		contentPane.add(textFieldDBName);
		textFieldDBName.setColumns(10);
		
		lblPort = new JLabel("Port:");
		lblPort.setForeground(new Color(255, 255, 255));
		lblPort.setFont(new Font("Calibri", Font.PLAIN, 16));
		lblPort.setBounds(40, 83, 64, 14);
		contentPane.add(lblPort);
		
		textFieldPort = new JTextField();
		textFieldPort.setBackground(Color.DARK_GRAY);
		textFieldPort.setText("5555");
		textFieldPort.setFont(new Font("Calibri", Font.BOLD | Font.ITALIC, 12));
		textFieldPort.setForeground(new Color(255, 255, 255));
		textFieldPort.setBorder(border);
		textFieldPort.setCaretColor(Color.WHITE);
		textFieldPort.setBounds(110, 81, 125, 20);
		contentPane.add(textFieldPort);
		textFieldPort.setColumns(10);
		
		btnConnect = new JButton("Connect to DB");
		btnConnect.setBackground(Color.DARK_GRAY);
		btnConnect.setForeground(new Color(255, 255, 255));
		btnConnect.setFont(new Font("Calibri", Font.PLAIN, 13));
		btnConnect.setBounds(40, 121, 195, 23);
		btnConnect.setBorder(border);
		btnConnect.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String dbname, portid , usrname , pass;
					try{
					
							//Getting Current Date time
						  	DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");
						  	LocalDateTime now = LocalDateTime.now();
				            dbname = textFieldDBName.getText();
				            portid = textFieldPort.getText();
				            usrname = textFieldUser.getText();
				            pass = new String (textFieldPass.getPassword());
				            if(!(dbname.isEmpty() || portid.isEmpty() || usrname.isEmpty() || pass.isEmpty()))
				            {
				            	if(server.initDBConnection(dbname,usrname, pass))
				            	{
				            		server.setPort(Integer.valueOf(textFieldPort.getText()));
				            		display("["+dtf.format(now)+"] SQL connection succeed");	
				            		try{
				            			server.listen(); //Start listening for connections
				            			display("["+dtf.format(now)+"] Server is listening on port " + textFieldPort.getText());
				            			textFieldDBName.setForeground(Color.GREEN);
				            			textFieldDBName.setEnabled(false);
				            			textFieldPort.setForeground(Color.GREEN);
				            			textFieldPort.setEnabled(false);
				            			textFieldUser.setForeground(Color.GREEN);
				            			textFieldUser.setEnabled(false);
				            			textFieldPass.setForeground(Color.GREEN);
				            			textFieldPass.setEnabled(false);
				            			btnConnect.setEnabled(false);
				            			}catch(Exception ex){display("["+dtf.format(now)+"] ERROR - Could not listen for clients!");}
				            	}
				        		else 
				        			display("["+dtf.format(now)+"] SQL connection failed.");
				            }
				            else
				            	display("You must Fill all the fields");
					}catch(Exception ex1){e.toString();};
			}
		});
		contentPane.add(btnConnect);
		
		textFieldUser = new JTextField();
		textFieldUser.setBackground(Color.DARK_GRAY);
		textFieldUser.setText("root");
		textFieldUser.setForeground(new Color(255, 255, 255));
		textFieldUser.setFont(new Font("Calibri", Font.BOLD | Font.ITALIC, 13));
		textFieldUser.setBorder(border);
		textFieldUser.setCaretColor(Color.WHITE);
		textFieldUser.setBounds(360, 39, 130, 20);
		contentPane.add(textFieldUser);
		textFieldUser.setColumns(10);
		
		lblUsername = new JLabel("Username:");
		lblUsername.setForeground(new Color(255, 255, 255));
		lblUsername.setFont(new Font("Calibri", Font.PLAIN, 16));
		lblUsername.setBounds(286, 42, 80, 14);
		contentPane.add(lblUsername);
		
		lblPassword = new JLabel("Password:");
		lblPassword.setForeground(new Color(255, 255, 255));
		lblPassword.setFont(new Font("Calibri", Font.PLAIN, 16));
		lblPassword.setBounds(286, 84, 66, 14);
		contentPane.add(lblPassword);
		
		textFieldPass = new JPasswordField();
		textFieldPass.setBackground(Color.DARK_GRAY);
		textFieldPass.setForeground(new Color(255, 255, 255));
		textFieldPass.setBorder(border);
		textFieldPass.setCaretColor(Color.WHITE);
		textFieldPass.setFont(new Font("Calibri", Font.BOLD | Font.ITALIC, 13));
		textFieldPass.setBounds(360, 81, 130, 20);
		contentPane.add(textFieldPass);
		textFieldPass.setColumns(10);
		
		lblNewLabel = new JLabel("");
		lblNewLabel.setFont(new Font("Calibri", Font.PLAIN, 11));
		lblNewLabel.setForeground(new Color(165, 42, 42));
		lblNewLabel.setBounds(77, 153, 385, 20);
		contentPane.add(lblNewLabel);
		//Adding Images
		imgdb.setBounds(10,32,30,30);
		contentPane.add(imgdb);
		imguser.setBounds(256,32,30,30);
		contentPane.add(imguser);
		imgpass.setBounds(253,75,30,30);
		contentPane.add(imgpass);
		imgport.setBounds(10,75,30,30);
		contentPane.add(imgport);
		imgconnect.setBounds(10,116,30,30);
		contentPane.add(imgconnect);
		imgip.setBounds(253,116,30,30);
		contentPane.add(imgip);
		
		JLabel lblIp = new JLabel("IP:");
		lblIp.setForeground(new Color(255, 255, 255));
		lblIp.setFont(new Font("Tahoma", Font.BOLD, 16));
		lblIp.setBounds(286, 123, 49, 14);
		contentPane.add(lblIp);
		
		InetAddress ip;
		  try {

			ip = InetAddress.getLocalHost();
			JLabel lblnumber = new JLabel(ip.getHostAddress());
			lblnumber.setForeground(new Color(255, 255, 255));
			lblnumber.setFont(new Font("Tahoma", Font.BOLD, 16));
			lblnumber.setBounds(318, 123, 169, 14);
			contentPane.add(lblnumber);
			
			serverConsole = new JTextArea();
			serverConsole.setBackground(Color.DARK_GRAY);
			serverConsole.setForeground(new Color(255, 255, 255));
			serverConsole.setBounds(10, 116, 414, 284);
			serverConsole.setBorder(border);
			///contentPane.add(serverConsole);
			scrollPane.setViewportView(serverConsole);
			serverConsole.setEditable(false);

		  } catch (UnknownHostException e) {

			e.printStackTrace();

		  }
		
		
	}
	
	public  void display(String s)
	{
		serverConsole.append(s + "\n");
	}
	
	
	public Server getserver()
	{return this.server;}
	public static void main(String[] args) {
	    
	    ServerGUI servergui = new ServerGUI();
	    Server server = new Server(servergui,5555);
	    servergui.server = server;
	}
}
