package OurMessage;


public class QTypes {


	public static int insert = 1;
	public static int select = 2; 
	public static int display= 3;
	public static int update = 4;//Logout Button
	public static int getuser=5;//Login Button
	public static int updateonX=6;//HomeUI Clicking on X then Yes
	public static int GetOpenedSem=7;
	public static int updateBlockRequest=8;
	public static int getblockrequests=9;//RequestPanel Block Request School Admin
	public static int getReq=10;
	public static int updateReq=11;
	public static int readOnly=12;
	public  static int getReqTeacher=13;
	public static int updateReqTeacher=14;
	public static int getgrades=15;
	public static int secretaryStudents = 100;
	public static int checksemester=101;//check semester duration
	public static int addnewsemester=102;//adding new semester
	public static int getrequests=103;//Getting all the requests from DBs
	public static int updaterequestM=104;//Updating data base acroding to the request
	public static int getassocciateclass=105;//Getting all classes and student list
	public static int insertnewstudents=106;//Insert new students to table class_students
	public static int getassocciateteacher=107;
	public static int insertnewteacher=108;
	public static int getblockrequest=109;
	public static int updaterequestB=110;
	public static int getChildinfo=111;
	public static int getAllInfoChild=112;
	public static int blockparent=300; // getting parenr id 
	public static int courseassignment=301;// for view assignment combo
	public static int assignmentcombo=302; // filling assignment combo request
	public static int coursedownload=303; // filling combo for course download assignment 
	public static int assignmentcombodownload=304;// filling assignment downlaod
	public static int coursecombomaterial=305; // filling combo in view/download material per course
	public static int materialcourse=306; // filling material combo for view material 
	public static int materialcoursedownload=307;// combo material download
	public static int materialcombodownload=308;  
	public static int blockparent2=310;// updating DB message for blocking parent  
	public static int getidmessage=311;
	public static int uploadassignmnet=312;
	public static int checkrequestsally=313; // checking if block request already exists in DB
	public static int getstudentclass=314;//for send request
	public static int moveclasscombo=315; // updating combo box in send request page
	public static int getrequestnum=316; 
	public static int updaterequeststudent=317; 
	public static int exitrequest=318; 
	public static int getclassesstu=319; 
	public static int classandcourse=320; 
	public static int assdownloads=321; 
	public static int activeadownload=322;
	public static int getclassesstu1=323; 
	public static int classandcourse1=324;
	public static int assdownloads1=325;
	//Student Files Manegment
	public static int uploadassigment=326;
	public static int setupuploadassigment=327;
	
	
	public static int GetTeachunits = 200;
	public static int GetAllCoursesids = 201;
	public static int Getspaceficcoursename = 202;
	public static int AddnewCourse = 203;
	public static int AddnewPreCourse = 204;
	public static int ShowinTXTallCourses = 206;
	public static int GetAllCoursesids1 = 207;
	public static int Getspaceficcoursename1 = 208;
	public static int GetspaceficcourseDetails = 209;
	public static int GetTeachunits2 = 210;
	public static int GetAllCoursestoButinChechboxlist = 211;
	public static int Getspaceficcoursenameforedit = 212;
	public static int updateCourse = 213;
	public static int deletepreCourses = 214;
	public static int GetTeachunitsUI = 215;
	public static int getcurrenthours=700;
	public static int EnteringHours=701;
	public static int GetTeachunits1 = 702;
	public static int showCoursesT = 703;
	public static int tu_request = 704;
	public static int TeacherUploadAss = 705;
	public static int TeacherUploadMat = 706;
	public static int TeacherEstimating = 707;
	public static int UploadAss = 708;
	public static int TeacherAnswers = 709;
	public static int Selectcourse = 710;
	public static int SelectClass = 711;
	public static int SelectStudent = 712;
	public static int SelectAssigment2 = 713;
	public static int uploadgrade = 714;
	public static int uploadfile = 715;
	public static int downloadfile = 716;
	public static int uploadass = 717;
	public static int uploadmat = 718;
	public static int uploadest = 719;
}
